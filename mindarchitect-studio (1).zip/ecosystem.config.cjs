module.exports = {
  apps: [
    {
      name: 'evalionmind-app',
      script: 'server.ts',
      interpreter: 'tsx',
      watch: false,
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
    },
  ],
};
