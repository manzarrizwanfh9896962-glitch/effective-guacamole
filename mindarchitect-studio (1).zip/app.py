from flask import Flask, jsonify, request
from flask_cors import CORS
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

PORT = int(os.environ.get('PORT', 3000))

# Mock Database
MOCK_CANDIDATES = [
    { "id": 1, "name": "Alex Rivera", "role": "Senior Backend", "status": "IN_PROGRESS", "score": 88 },
    { "id": 2, "name": "Sarah Chen", "role": "Frontend Lead", "status": "COMPLETED", "score": 94 },
    { "id": 3, "name": "Marcus Johnson", "role": "DevOps Engineer", "status": "PENDING", "score": None },
    { "id": 4, "name": "Elena Rodriguez", "role": "System Architect", "status": "COMPLETED", "score": 91 }
]

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        "status": "STABLE",
        "kernel": "V1.0.24",
        "timestamp": "2026-02-24T09:00:23-08:00"
    })

@app.route('/api/candidates', methods=['GET'])
def get_candidates():
    return jsonify(MOCK_CANDIDATES)

@app.route('/api/evaluate', methods=['POST'])
def evaluate_candidate():
    data = request.json
    # In a real Python backend, you would call the Gemini API here.
    # For this platform, the Gemini API is called from the frontend.
    return jsonify({"status": "EVALUATED", "result": "Success"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=PORT)
