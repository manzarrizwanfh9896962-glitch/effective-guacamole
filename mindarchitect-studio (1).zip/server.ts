import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import dotenv from "dotenv";
import postgres from "postgres";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import session from 'express-session';
import { 
  generateRegistrationOptions, 
  verifyRegistrationResponse, 
  generateAuthenticationOptions, 
  verifyAuthenticationResponse,
} from '@simplewebauthn/server';
import { isoBase64URL } from '@simplewebauthn/server/helpers';
import rateLimit from 'express-rate-limit';
import * as Sentry from '@sentry/node';
import swaggerUi from 'swagger-ui-express';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';

// Extend express-session to include our custom properties
declare module 'express-session' {
  interface SessionData {
    currentChallenge?: string;
  }
}

dotenv.config();

// Initialize Gemini API
let genAI: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
} else {
  console.warn("WARNING: GEMINI_API_KEY not provided. AI services will be unavailable.");
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database connection setup with graceful fallback
let sql: any;
let useMockDb = false;

// In-memory fallback database
const mockDb = {
  users: [] as any[],
  refreshTokens: [] as string[],
  nodes: [
    { id: '1', name: 'Kernel-Alpha', region: 'US-EAST-1', status: 'OPTIMAL', latency: 12 },
    { id: '2', name: 'Kernel-Beta', region: 'EU-WEST-2', status: 'OPTIMAL', latency: 24 },
    { id: '3', name: 'Kernel-Gamma', region: 'AP-NORTHEAST-1', status: 'STABLE', latency: 145 },
    { id: '4', name: 'Kernel-Delta', region: 'SA-EAST-1', status: 'OPTIMAL', latency: 45 }
  ],
  candidates: [
    { 
      id: "1", 
      name: "Alex Rivera", 
      role: "Senior Backend", 
      status: "IN_PROGRESS", 
      score: 88,
      id_code: "cand_8842_ax",
      metrics: { algorithmic: 92, systemDesign: 85, communication: 89 },
      transcript: [
        { time: "00:14:22", speaker: "AI_AGENT", text: "Can you explain how you would scale the database layer to handle 10x traffic?" },
        { time: "00:14:35", speaker: "CANDIDATE", text: "I would start by implementing read replicas to offload the read queries. If write throughput becomes a bottleneck, I'd look into sharding the database based on a consistent hash of the user ID.", verification: "VERIFIED_CONCEPT: SHARDING, READ_REPLICAS" },
        { time: "00:15:10", speaker: "AI_AGENT", text: "How would you handle cross-shard transactions in that scenario?" }
      ],
      biometrics: { stressLevel: 42, cognitiveLoad: 68, focusScore: 94 },
      feedback: "Strong grasp of distributed systems. Candidate demonstrated clear understanding of horizontal scaling trade-offs."
    },
    { 
      id: "2", 
      name: "Sarah Chen", 
      role: "Frontend Lead", 
      status: "COMPLETED", 
      score: 94,
      id_code: "cand_9412_sc",
      metrics: { algorithmic: 88, systemDesign: 96, communication: 98 },
      transcript: [
        { time: "00:08:12", speaker: "AI_AGENT", text: "How do you approach state management in large-scale React applications?" },
        { time: "00:08:45", speaker: "CANDIDATE", text: "I prefer a modular approach. For global UI state, I use lightweight solutions like Zustand. For server state, React Query is essential for caching and synchronization.", verification: "VERIFIED_CONCEPT: STATE_MANAGEMENT, SERVER_STATE" },
        { time: "00:09:30", speaker: "AI_AGENT", text: "What are the performance implications of using Context API for frequently changing values?" }
      ],
      biometrics: { stressLevel: 28, cognitiveLoad: 45, focusScore: 98 },
      feedback: "Exceptional frontend architect. Deep knowledge of modern ecosystem and performance optimization patterns."
    }
  ],
  tasks: [] as any[],
  parties: [
    { id: 1, name: "Direct Client", type: "INDIVIDUAL" },
    { id: 2, name: "Global Travels", type: "AGENCY" }
  ],
  categories: [
    { id: 1, name: "Work Visa" },
    { id: 2, name: "Visit Visa" },
    { id: 3, name: "Student Visa" }
  ],
  agents: [
    { id: 1, name: "John Agent", phone: "123456789" },
    { id: 2, name: "Sarah Broker", phone: "987654321" }
  ],
  cities: [
    { id: 1, name: "Riyadh" },
    { id: 2, name: "Dubai" },
    { id: 3, name: "Muscat" }
  ],
  medicalCenters: [
    { id: 1, name: "Al-Shifa Medical", city: "Riyadh" },
    { id: 2, name: "Gulf Health Center", city: "Dubai" }
  ],
  embassies: [
    { id: 1, name: "Saudi Embassy", city: "Islamabad" },
    { id: 2, name: "UAE Embassy", city: "Karachi" }
  ],
  receipts: [] as any[],
  passportReceivings: [] as any[],
  passports: [] as any[],
  settings: {
    companyName: "MindArchitect Studio",
    address: "Tech Hub, Silicon Valley",
    phone: "+1-555-0199",
    email: "kernel@mindarchitect.studio"
  }
};

if (process.env.DATABASE_URL) {
  sql = postgres(process.env.DATABASE_URL, {
    ssl: "require",
  });
} else {
  console.warn("WARNING: DATABASE_URL not provided. Using in-memory mock database for development.");
  useMockDb = true;
}

// Connection Test
async function testConnection() {
  if (useMockDb) return;
  try {
    await sql`SELECT 1`;
    console.log("DATABASE_HANDSHAKE_SUCCESSFUL: Connection to PostgreSQL verified.");
    
    // Initialize users table
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        credential_id TEXT UNIQUE,
        credential_public_key TEXT,
        counter BIGINT DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;
    
    // Initialize refresh_tokens table
    await sql`
      CREATE TABLE IF NOT EXISTS refresh_tokens (
        id SERIAL PRIMARY KEY,
        token TEXT NOT NULL,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Initialize nodes table
    await sql`
      CREATE TABLE IF NOT EXISTS nodes (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        status VARCHAR(50) NOT NULL,
        latency INTEGER NOT NULL,
        region VARCHAR(50) NOT NULL
      )
    `;

    // Initialize candidates table
    await sql`
      CREATE TABLE IF NOT EXISTS candidates (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(255) NOT NULL,
        status VARCHAR(50) NOT NULL,
        score INTEGER,
        id_code VARCHAR(50) UNIQUE,
        metrics JSONB,
        transcript JSONB,
        biometrics JSONB,
        feedback TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Initialize tasks table
    await sql`
      CREATE TABLE IF NOT EXISTS tasks (
        id SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        status VARCHAR(50) DEFAULT 'PENDING',
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Initialize Passport Management tables
    await sql`
      CREATE TABLE IF NOT EXISTS parties (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS agents (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(50)
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS cities (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS medical_centers (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        city VARCHAR(255)
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS embassies (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        city VARCHAR(255)
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS receipts (
        id SERIAL PRIMARY KEY,
        file_no VARCHAR(50) UNIQUE NOT NULL,
        party_id INTEGER REFERENCES parties(id),
        agent_id INTEGER REFERENCES agents(id),
        category_id INTEGER REFERENCES categories(id),
        city_id INTEGER REFERENCES cities(id),
        medical_center_id INTEGER REFERENCES medical_centers(id),
        embassy_id INTEGER REFERENCES embassies(id),
        total_amount DECIMAL(10, 2),
        paid_amount DECIMAL(10, 2),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS passport_receivings (
        id SERIAL PRIMARY KEY,
        receipt_id INTEGER REFERENCES receipts(id),
        receiving_date DATE NOT NULL,
        remarks TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS passports (
        id SERIAL PRIMARY KEY,
        receipt_id INTEGER REFERENCES receipts(id),
        passport_no VARCHAR(50) NOT NULL,
        candidate_name VARCHAR(255) NOT NULL,
        status VARCHAR(50) DEFAULT 'RECEIVED',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `;

    await sql`
      CREATE TABLE IF NOT EXISTS settings (
        id SERIAL PRIMARY KEY,
        key VARCHAR(255) UNIQUE NOT NULL,
        value TEXT NOT NULL
      )
    `;

    // Seed initial data if tables are empty
    const nodeCount = await sql`SELECT count(*) FROM nodes`;
    if (parseInt(nodeCount[0].count) === 0) {
      await sql`
        INSERT INTO nodes (name, status, latency, region) VALUES
        ('Kernel-Alpha', 'OPTIMAL', 12, 'US-EAST-1'),
        ('Kernel-Beta', 'OPTIMAL', 24, 'EU-WEST-2'),
        ('Kernel-Gamma', 'STABLE', 145, 'AP-NORTHEAST-1'),
        ('Kernel-Delta', 'OPTIMAL', 45, 'SA-EAST-1')
      `;
    }

    const candidateCount = await sql`SELECT count(*) FROM candidates`;
    if (parseInt(candidateCount[0].count) === 0) {
      for (const cand of mockDb.candidates) {
        await sql`
          INSERT INTO candidates (name, role, status, score, id_code, metrics, transcript, biometrics, feedback)
          VALUES (${cand.name}, ${cand.role}, ${cand.status}, ${cand.score}, ${cand.id_code}, ${JSON.stringify(cand.metrics)}, ${JSON.stringify(cand.transcript)}, ${JSON.stringify(cand.biometrics)}, ${cand.feedback})
        `;
      }
    }

    console.log("DATABASE_SCHEMA_VERIFIED: tables ready.");
  } catch (err: any) {
    const isDnsError = err.code === 'ENOTFOUND' || (err.message && err.message.includes('ENOTFOUND'));
    const isConnRefused = err.code === 'ECONNREFUSED' || (err.message && err.message.includes('ECONNREFUSED'));

    if (isDnsError || isConnRefused) {
      console.warn("DATABASE_CONNECTION_UNAVAILABLE: Could not resolve or connect to database host.");
      console.warn(`Host: ${process.env.DATABASE_URL?.split('@')[1]?.split(':')[0] || 'unknown'}`);
      console.warn("This is likely due to an incorrect DATABASE_URL, a paused Supabase project, or network issues.");
      console.warn("TIP: If using Supabase, ensure your project is active and the URL is correct (usually ends in .supabase.co or .supabase.com).");
    } else {
      console.error("DATABASE_HANDSHAKE_FAILED:", err);
    }
    console.warn("Falling back to in-memory mock database for this session.");
    useMockDb = true;
  }
}

// Removed top-level call to testConnection() as it is now called inside startServer()

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });
  const PORT = 3000;

  // Sentry Initialization
  if (process.env.SENTRY_DSN) {
    Sentry.init({
      dsn: process.env.SENTRY_DSN,
      tracesSampleRate: 1.0,
    });
  }

  // Middleware
  app.set('trust proxy', 1);
  app.use(express.json());
  app.use(cors());

  // Rate limiting
  const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
  });
  app.use('/api/', apiLimiter);

  // API Docs
  try {
    const swaggerPath = path.join(__dirname, "public", "openapi.json");
    if (fs.existsSync(swaggerPath)) {
      const swaggerDocument = JSON.parse(fs.readFileSync(swaggerPath, 'utf8'));
      app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
    }
  } catch (err) {
    console.error("Failed to load Swagger documentation:", err);
  }

  app.use(session({
    secret: process.env.SESSION_SECRET || 'super_secret_dev_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: process.env.NODE_ENV === 'production' }
  }));

  const JWT_SECRET = process.env.JWT_SECRET || "fallback_secret_for_dev_only";
  const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET || "fallback_refresh_secret_for_dev_only";

  // Helper to generate tokens
  const generateAccessToken = (user: any) => {
    return jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "15m" });
  };

  const generateRefreshToken = (user: any) => {
    return jwt.sign({ userId: user.id, email: user.email }, REFRESH_TOKEN_SECRET);
  };

  // Middleware to protect routes
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: No token provided" });
    }

    const token = authHeader.split(" ")[1];
    jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
      if (err) {
        if (err.name === 'TokenExpiredError') {
          return res.status(401).json({ error: "Unauthorized: Token expired", code: "TOKEN_EXPIRED" });
        }
        return res.status(403).json({ error: "Forbidden: Invalid token" });
      }
      req.user = user;
      next();
    });
  };

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({
      status: "STABLE",
      kernel: "V1.0.24",
      uptime: process.uptime(),
      timestamp: new Date().toISOString(),
      db_connected: !useMockDb,
    });
  });

  // Auth Routes
  app.post("/api/auth/signup", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "Email and password required" });

    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      let user;
      if (useMockDb) {
        if (mockDb.users.find(u => u.email === email)) return res.status(409).json({ error: "User exists" });
        user = { id: mockDb.users.length + 1, email, password: hashedPassword };
        mockDb.users.push(user);
      } else {
        const existing = await sql`SELECT id FROM users WHERE email = ${email}`;
        if (existing.length > 0) return res.status(409).json({ error: "User exists" });
        const [inserted] = await sql`INSERT INTO users (email, password) VALUES (${email}, ${hashedPassword}) RETURNING id, email`;
        user = inserted;
      }

      const accessToken = generateAccessToken(user);
      const refreshToken = generateRefreshToken(user);

      if (useMockDb) {
        mockDb.refreshTokens.push(refreshToken);
      } else {
        await sql`INSERT INTO refresh_tokens (token, user_id) VALUES (${refreshToken}, ${user.id})`;
      }

      res.status(201).json({ user: { id: user.id, email: user.email }, accessToken, refreshToken });
    } catch (err) {
      res.status(500).json({ error: "Signup failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    try {
      let user;
      if (useMockDb) {
        user = mockDb.users.find(u => u.email === email);
      } else {
        const users = await sql`SELECT * FROM users WHERE email = ${email}`;
        user = users[0];
      }

      if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const accessToken = generateAccessToken(user);
      const refreshToken = generateRefreshToken(user);

      if (useMockDb) {
        mockDb.refreshTokens.push(refreshToken);
      } else {
        await sql`INSERT INTO refresh_tokens (token, user_id) VALUES (${refreshToken}, ${user.id})`;
      }

      res.json({ user: { id: user.id, email: user.email }, accessToken, refreshToken });
    } catch (err) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/auth/refresh-token", async (req, res) => {
    const { token } = req.body;
    if (!token) return res.status(401).json({ error: "Refresh token required" });

    try {
      let exists;
      if (useMockDb) {
        exists = mockDb.refreshTokens.includes(token);
      } else {
        const results = await sql`SELECT id FROM refresh_tokens WHERE token = ${token}`;
        exists = results.length > 0;
      }

      if (!exists) return res.status(403).json({ error: "Invalid refresh token" });

      jwt.verify(token, REFRESH_TOKEN_SECRET, (err: any, user: any) => {
        if (err) return res.status(403).json({ error: "Invalid refresh token" });
        const accessToken = generateAccessToken({ id: user.userId, email: user.email });
        res.json({ accessToken });
      });
    } catch (err) {
      res.status(500).json({ error: "Token refresh failed" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    const { token } = req.body;
    if (useMockDb) {
      mockDb.refreshTokens = mockDb.refreshTokens.filter(t => t !== token);
    } else {
      await sql`DELETE FROM refresh_tokens WHERE token = ${token}`;
    }
    res.sendStatus(204);
  });

  // Passport Management API Routes
  app.get("/api/dashboard", authenticateToken, async (req, res) => {
    try {
      if (useMockDb) {
        return res.json({
          totalReceipts: mockDb.receipts.length,
          totalPassports: mockDb.passports.length,
          recentReceipts: mockDb.receipts.slice(-5),
          stats: {
            received: mockDb.passports.filter(p => p.status === 'RECEIVED').length,
            processing: mockDb.passports.filter(p => p.status === 'PROCESSING').length,
            completed: mockDb.passports.filter(p => p.status === 'COMPLETED').length
          }
        });
      }
      const [receiptCount] = await sql`SELECT count(*) FROM receipts`;
      const [passportCount] = await sql`SELECT count(*) FROM passports`;
      const recentReceipts = await sql`SELECT * FROM receipts ORDER BY created_at DESC LIMIT 5`;
      const stats = await sql`
        SELECT status, count(*) FROM passports GROUP BY status
      `;
      res.json({
        totalReceipts: parseInt(receiptCount.count),
        totalPassports: parseInt(passportCount.count),
        recentReceipts,
        stats: stats.reduce((acc: any, curr: any) => {
          acc[curr.status.toLowerCase()] = parseInt(curr.count);
          return acc;
        }, {})
      });
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch dashboard data" });
    }
  });

  app.get("/api/parties", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.parties : await sql`SELECT * FROM parties`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch parties" });
    }
  });

  app.get("/api/categories", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.categories : await sql`SELECT * FROM categories`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch categories" });
    }
  });

  app.get("/api/agents", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.agents : await sql`SELECT * FROM agents`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch agents" });
    }
  });

  app.get("/api/cities", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.cities : await sql`SELECT * FROM cities`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch cities" });
    }
  });

  app.get("/api/medical-centers", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.medicalCenters : await sql`SELECT * FROM medical_centers`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch medical centers" });
    }
  });

  app.get("/api/embassies", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.embassies : await sql`SELECT * FROM embassies`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch embassies" });
    }
  });

  app.get("/api/receipts/next-file-no", authenticateToken, async (req, res) => {
    try {
      if (useMockDb) {
        const nextNo = mockDb.receipts.length + 1;
        return res.json({ nextFileNo: `FILE-${nextNo.toString().padStart(4, '0')}` });
      }
      const [lastReceipt] = await sql`SELECT file_no FROM receipts ORDER BY id DESC LIMIT 1`;
      let nextNo = 1;
      if (lastReceipt) {
        const match = lastReceipt.file_no.match(/\d+/);
        if (match) nextNo = parseInt(match[0]) + 1;
      }
      res.json({ nextFileNo: `FILE-${nextNo.toString().padStart(4, '0')}` });
    } catch (err) {
      res.status(500).json({ error: "Failed to generate next file number" });
    }
  });

  app.get("/api/receipts/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      if (useMockDb) {
        const receipt = mockDb.receipts.find(r => r.id === parseInt(id));
        return receipt ? res.json(receipt) : res.status(404).json({ error: "Receipt not found" });
      }
      const [receipt] = await sql`SELECT * FROM receipts WHERE id = ${id}`;
      res.json(receipt);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch receipt" });
    }
  });

  app.post("/api/receipts", authenticateToken, async (req, res) => {
    try {
      const data = req.body;
      if (useMockDb) {
        const newReceipt = { id: mockDb.receipts.length + 1, ...data, created_at: new Date().toISOString() };
        mockDb.receipts.push(newReceipt);
        return res.status(201).json(newReceipt);
      }
      const [inserted] = await sql`
        INSERT INTO receipts (file_no, party_id, agent_id, category_id, city_id, medical_center_id, embassy_id, total_amount, paid_amount)
        VALUES (${data.file_no}, ${data.party_id}, ${data.agent_id}, ${data.category_id}, ${data.city_id}, ${data.medical_center_id}, ${data.embassy_id}, ${data.total_amount}, ${data.paid_amount})
        RETURNING *
      `;
      res.status(201).json(inserted);
    } catch (err) {
      res.status(500).json({ error: "Failed to create receipt" });
    }
  });

  app.get("/api/passport-receivings", authenticateToken, async (req, res) => {
    try {
      const data = useMockDb ? mockDb.passportReceivings : await sql`SELECT * FROM passport_receivings`;
      res.json(data);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch passport receivings" });
    }
  });

  app.get("/api/passports/by-receipt/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      if (useMockDb) {
        const passports = mockDb.passports.filter(p => p.receipt_id === parseInt(id));
        return res.json(passports);
      }
      const passports = await sql`SELECT * FROM passports WHERE receipt_id = ${id}`;
      res.json(passports);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch passports" });
    }
  });

  app.post("/api/passports", authenticateToken, async (req, res) => {
    try {
      const data = req.body;
      if (useMockDb) {
        const newPassport = { id: mockDb.passports.length + 1, ...data, created_at: new Date().toISOString() };
        mockDb.passports.push(newPassport);
        return res.status(201).json(newPassport);
      }
      const [inserted] = await sql`
        INSERT INTO passports (receipt_id, passport_no, candidate_name, status)
        VALUES (${data.receipt_id}, ${data.passport_no}, ${data.candidate_name}, ${data.status || 'RECEIVED'})
        RETURNING *
      `;
      res.status(201).json(inserted);
    } catch (err) {
      res.status(500).json({ error: "Failed to create passport" });
    }
  });

  app.get("/api/settings", authenticateToken, async (req, res) => {
    try {
      if (useMockDb) {
        return res.json(mockDb.settings);
      }
      const settings = await sql`SELECT * FROM settings`;
      const settingsObj = settings.reduce((acc: any, curr: any) => {
        acc[curr.key] = curr.value;
        return acc;
      }, {});
      res.json(settingsObj);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  // Biometric Auth Endpoints
  app.post("/api/auth/biometric/register/start", async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: "Email required" });

    try {
      let user;
      if (useMockDb) {
        user = mockDb.users.find(u => u.email === email);
      } else {
        const users = await sql`SELECT * FROM users WHERE email = ${email}`;
        user = users[0];
      }

      if (!user) return res.status(404).json({ error: "User not found. Register with password first." });

      const options = await generateRegistrationOptions({
        rpName: 'MindArchitect Studio',
        rpID: 'localhost',
        userID: user.id.toString(),
        userName: user.email,
        attestationType: 'none',
        authenticatorSelection: {
          residentKey: 'preferred',
          userVerification: 'preferred',
        },
      });

      req.session.currentChallenge = options.challenge;
      res.json(options);
    } catch (err) {
      res.status(500).json({ error: "Biometric registration start failed" });
    }
  });

  app.post("/api/auth/biometric/register/finish", async (req, res) => {
    const { email, response } = req.body;
    const expectedChallenge = req.session.currentChallenge || '';

    try {
      const verification = await verifyRegistrationResponse({
        response,
        expectedChallenge,
        expectedOrigin: 'http://localhost:3000',
        expectedRPID: 'localhost',
      });

      if (verification.verified && verification.registrationInfo) {
        const { credential } = verification.registrationInfo as any;
        const credIdBase64 = isoBase64URL.fromBuffer(credential.id);
        const credPubKeyBase64 = isoBase64URL.fromBuffer(credential.publicKey);
        const counter = credential.counter;

        if (useMockDb) {
          const user = mockDb.users.find(u => u.email === email);
          if (user) {
            user.credential_id = credIdBase64;
            user.credential_public_key = credPubKeyBase64;
            user.counter = counter;
          }
        } else {
          await sql`
            UPDATE users 
            SET credential_id = ${credIdBase64}, 
                credential_public_key = ${credPubKeyBase64}, 
                counter = ${counter} 
            WHERE email = ${email}
          `;
        }
        res.json({ verified: true });
      } else {
        res.status(400).json({ error: "Verification failed" });
      }
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Biometric registration finish failed" });
    }
  });

  app.post("/api/auth/biometric/login/start", async (req, res) => {
    const { email } = req.body;
    try {
      let user;
      if (useMockDb) {
        user = mockDb.users.find(u => u.email === email);
      } else {
        const users = await sql`SELECT * FROM users WHERE email = ${email}`;
        user = users[0];
      }

      if (!user || !user.credential_id) return res.status(404).json({ error: "Biometrics not registered for this user" });

      const options = await generateAuthenticationOptions({
        rpID: 'localhost',
        allowCredentials: [{
          id: user.credential_id,
          transports: ['internal'],
        }],
        userVerification: 'preferred',
      });

      req.session.currentChallenge = options.challenge;
      res.json(options);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Biometric login start failed" });
    }
  });

  app.post("/api/auth/biometric/login/finish", async (req, res) => {
    const { email, response } = req.body;
    const expectedChallenge = req.session.currentChallenge || '';

    try {
      let user;
      if (useMockDb) {
        user = mockDb.users.find(u => u.email === email);
      } else {
        const users = await sql`SELECT * FROM users WHERE email = ${email}`;
        user = users[0];
      }

      if (!user) return res.status(404).json({ error: "User not found" });

      const verification = await verifyAuthenticationResponse({
        response,
        expectedChallenge,
        expectedOrigin: 'http://localhost:3000',
        expectedRPID: 'localhost',
        credential: {
          id: user.credential_id,
          publicKey: isoBase64URL.toBuffer(user.credential_public_key),
          counter: parseInt(user.counter),
        },
      });

      if (verification.verified && verification.authenticationInfo) {
        const { newCounter } = verification.authenticationInfo;
        if (useMockDb) {
          user.counter = newCounter;
        } else {
          await sql`UPDATE users SET counter = ${newCounter} WHERE id = ${user.id}`;
        }

        const accessToken = generateAccessToken(user);
        const refreshToken = generateRefreshToken(user);

        if (useMockDb) {
          mockDb.refreshTokens.push(refreshToken);
        } else {
          await sql`INSERT INTO refresh_tokens (token, user_id) VALUES (${refreshToken}, ${user.id})`;
        }

        res.json({ verified: true, user: { id: user.id, email: user.email }, accessToken, refreshToken });
      } else {
        res.status(400).json({ error: "Verification failed" });
      }
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Biometric login finish failed" });
    }
  });

  // Biometric Enrollment for Authenticated Users
  app.post("/api/auth/biometric/enroll/start", authenticateToken, async (req: any, res: any) => {
    try {
      let user;
      if (useMockDb) {
        user = mockDb.users.find(u => u.id === req.user.userId);
      } else {
        const users = await sql`SELECT * FROM users WHERE id = ${req.user.userId}`;
        user = users[0];
      }

      if (!user) return res.status(404).json({ error: "User not found" });

      const options = await generateRegistrationOptions({
        rpName: 'MindArchitect Studio',
        rpID: 'localhost',
        userID: user.id.toString(),
        userName: user.email,
        attestationType: 'none',
        authenticatorSelection: {
          residentKey: 'preferred',
          userVerification: 'preferred',
        },
      });

      req.session.currentChallenge = options.challenge;
      res.json(options);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Enrollment start failed" });
    }
  });

  app.post("/api/auth/biometric/enroll/finish", authenticateToken, async (req: any, res: any) => {
    const { response } = req.body;
    const expectedChallenge = req.session.currentChallenge || '';

    try {
      const verification = await verifyRegistrationResponse({
        response,
        expectedChallenge,
        expectedOrigin: 'http://localhost:3000',
        expectedRPID: 'localhost',
      });

      if (verification.verified && verification.registrationInfo) {
        const { credential } = verification.registrationInfo as any;
        const credIdBase64 = isoBase64URL.fromBuffer(credential.id);
        const credPubKeyBase64 = isoBase64URL.fromBuffer(credential.publicKey);
        const counter = credential.counter;

        if (useMockDb) {
          const user = mockDb.users.find(u => u.id === req.user.userId);
          if (user) {
            user.credential_id = credIdBase64;
            user.credential_public_key = credPubKeyBase64;
            user.counter = counter;
          }
        } else {
          await sql`
            UPDATE users 
            SET credential_id = ${credIdBase64}, 
                credential_public_key = ${credPubKeyBase64}, 
                counter = ${counter} 
            WHERE id = ${req.user.userId}
          `;
        }
        res.json({ verified: true });
      } else {
        res.status(400).json({ error: "Enrollment verification failed" });
      }
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "Enrollment finish failed" });
    }
  });

  // Tasks API
  app.get("/api/tasks", authenticateToken, async (req: any, res: any) => {
    try {
      let tasks;
      if (useMockDb) {
        tasks = mockDb.tasks.filter(t => t.user_id === req.user.userId);
      } else {
        tasks = await sql`SELECT * FROM tasks WHERE user_id = ${req.user.userId} ORDER BY created_at DESC`;
      }
      res.json(tasks);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", authenticateToken, async (req: any, res: any) => {
    const { title, description } = req.body;
    if (!title) return res.status(400).json({ error: "Title required" });
    try {
      let task;
      if (useMockDb) {
        task = { id: mockDb.tasks.length + 1, title, description, status: 'PENDING', user_id: req.user.userId, created_at: new Date() };
        mockDb.tasks.push(task);
      } else {
        const [inserted] = await sql`INSERT INTO tasks (title, description, user_id) VALUES (${title}, ${description}, ${req.user.userId}) RETURNING *`;
        task = inserted;
      }
      res.status(201).json(task);
    } catch (err) {
      res.status(500).json({ error: "Failed to create task" });
    }
  });

  app.patch("/api/tasks/:id", authenticateToken, async (req: any, res: any) => {
    const { title, description, status } = req.body;
    const { id } = req.params;
    try {
      let task;
      if (useMockDb) {
        task = mockDb.tasks.find(t => t.id === parseInt(id) && t.user_id === req.user.userId);
        if (!task) return res.status(404).json({ error: "Task not found" });
        if (title !== undefined) task.title = title;
        if (description !== undefined) task.description = description;
        if (status !== undefined) task.status = status;
      } else {
        const results = await sql`
          UPDATE tasks 
          SET title = COALESCE(${title}, title), 
              description = COALESCE(${description}, description), 
              status = COALESCE(${status}, status)
          WHERE id = ${id} AND user_id = ${req.user.userId}
          RETURNING *
        `;
        if (results.length === 0) return res.status(404).json({ error: "Task not found" });
        task = results[0];
      }
      res.json(task);
    } catch (err) {
      res.status(500).json({ error: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", authenticateToken, async (req: any, res: any) => {
    const { id } = req.params;
    try {
      if (useMockDb) {
        const index = mockDb.tasks.findIndex(t => t.id === parseInt(id) && t.user_id === req.user.userId);
        if (index === -1) return res.status(404).json({ error: "Task not found" });
        mockDb.tasks.splice(index, 1);
      } else {
        const result = await sql`DELETE FROM tasks WHERE id = ${id} AND user_id = ${req.user.userId}`;
        if (result.count === 0) return res.status(404).json({ error: "Task not found" });
      }
      res.sendStatus(204);
    } catch (err) {
      res.status(500).json({ error: "Failed to delete task" });
    }
  });

  // Candidates API
  app.get("/api/candidates", authenticateToken, async (req, res) => {
    try {
      let results;
      if (useMockDb) {
        results = mockDb.candidates;
      } else {
        results = await sql`SELECT * FROM candidates ORDER BY created_at DESC`;
      }
      res.json(results);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch candidates" });
    }
  });

  app.get("/api/candidates/search", authenticateToken, async (req: any, res: any) => {
    const { q } = req.query;
    if (!q) return res.redirect("/api/candidates");
    const query = `%${q.toString().toLowerCase()}%`;
    try {
      let results;
      if (useMockDb) {
        results = mockDb.candidates.filter(c => 
          c.name.toLowerCase().includes(q.toLowerCase()) || 
          c.role.toLowerCase().includes(q.toLowerCase())
        );
      } else {
        results = await sql`
          SELECT * FROM candidates 
          WHERE LOWER(name) LIKE ${query} 
             OR LOWER(role) LIKE ${query}
             OR LOWER(status) LIKE ${query}
             OR LOWER(id_code) LIKE ${query}
        `;
      }
      res.json(results);
    } catch (err) {
      res.status(500).json({ error: "Search failed" });
    }
  });

  app.get("/api/candidates/:id", authenticateToken, async (req: any, res: any) => {
    try {
      let candidate;
      if (useMockDb) {
        candidate = mockDb.candidates.find(c => c.id === req.params.id);
      } else {
        const results = await sql`SELECT * FROM candidates WHERE id = ${req.params.id}`;
        candidate = results[0];
      }
      if (!candidate) return res.status(404).json({ error: "Candidate not found" });
      res.json(candidate);
    } catch (err) {
      res.status(500).json({ error: "Failed to fetch candidate" });
    }
  });

  // Nodes API
  app.get("/api/nodes", authenticateToken, async (req: any, res: any) => {
    try {
      let nodes;
      if (useMockDb) {
        nodes = mockDb.nodes;
      } else {
        nodes = await sql`SELECT id, name, region, status, latency FROM nodes ORDER BY region`;
      }
      const updatedNodes = nodes.map((node: any) => {
        const jitter = Math.floor(Math.random() * 10) - 5;
        let currentLatency = parseInt(node.latency) + jitter;
        if (currentLatency < 1) currentLatency = 1;
        let currentStatus = 'OPTIMAL';
        if (currentLatency > 100) currentStatus = 'STABLE';
        if (currentLatency > 300) currentStatus = 'DEGRADED';
        if (currentLatency > 500) currentStatus = 'CRITICAL';
        return { ...node, latency: `${currentLatency}ms`, status: currentStatus };
      });
      res.json(updatedNodes);
    } catch (err) {
      res.status(500).json({ error: "Database error" });
    }
  });

  // AI Chat Endpoint
  app.post("/api/chat", authenticateToken, async (req: any, res: any) => {
    if (!genAI) return res.status(503).json({ error: "AI service unavailable" });
    const { message, history, persona } = req.body;
    
    let systemInstruction = "You are the MindArchitect Studio Kernel Assistant.";
    if (persona === 'Interrogator') {
      systemInstruction = "You are an Interrogator persona. You are direct, probing, and focus on uncovering deep insights or potential issues in candidate responses.";
    } else if (persona === 'Analyst') {
      systemInstruction = "You are an Analyst persona. You are methodical, data-driven, and focus on objective metrics and logical consistency in candidate responses.";
    } else if (persona === 'Mentor') {
      systemInstruction = "You are a Mentor persona. You are supportive, constructive, and focus on candidate development and potential.";
    }

    try {
      const chat = genAI.chats.create({
        model: "gemini-2.0-flash",
        config: {
          systemInstruction: systemInstruction
        },
        history: history || [],
      });
      const result = await chat.sendMessage({ message });
      res.json({ response: result.text });
    } catch (error: any) {
      console.error("Chat error:", error);
      res.status(500).json({ error: "Failed to process AI request" });
    }
  });
  
  // WebSocket Logic
  io.on("connection", (socket) => {
    console.log("CLIENT_CONNECTED:", socket.id);

    socket.on("join-room", (roomId) => {
      socket.join(roomId);
      console.log(`CLIENT_${socket.id}_JOINED_ROOM_${roomId}`);
      socket.to(roomId).emit("user-joined", socket.id);
    });

    socket.on("send-message", ({ roomId, message }) => {
      io.to(roomId).emit("new-message", { from: socket.id, text: message });
    });

    socket.on("cursor-move", ({ roomId, position }) => {
      socket.to(roomId).emit("user-cursor-move", { userId: socket.id, position });
    });

    // WebRTC Signaling
    socket.on("webrtc-signal", ({ roomId, signal, to }) => {
      if (to) {
        io.to(to).emit("webrtc-signal", { signal, from: socket.id });
      } else {
        socket.to(roomId).emit("webrtc-signal", { signal, from: socket.id });
      }
    });

    socket.on("disconnect", () => {
      console.log("CLIENT_DISCONNECTED:", socket.id);
      io.emit("user-left", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Await database connection before starting server
  await testConnection();

  // Sentry error handler
  if (process.env.SENTRY_DSN) {
    Sentry.setupExpressErrorHandler(app);
  }

  // Global Error Handler
  app.use((err: any, req: any, res: any, next: any) => {
    console.error("Global Error Handler:", err);
    if (res.headersSent) return next(err);
    res.status(500).json({ error: "Internal Server Error" });
  });

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`MINDARCHITECT STUDIO OS KERNEL ACTIVE ON PORT ${PORT}`);
  });
}

startServer();
