import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';
import { nodePolyfills } from 'vite-plugin-node-polyfills';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [
      react(), 
      tailwindcss(),
      nodePolyfills({
        include: ['events', 'util', 'process', 'buffer'],
        globals: {
          Buffer: true,
          global: false,
          process: true,
        },
      }),
    ],
    define: {
      // 'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY), // REMOVED: Do not expose API keys to client
      'process.env.SUPABASE_URL': JSON.stringify(env.SUPABASE_URL),
      // 'process.env.SUPABASE_KEY': JSON.stringify(env.SUPABASE_KEY), // REMOVED: Do not expose service role keys
      'process.env.PROJECT_URL': JSON.stringify(env.PROJECT_URL),
      'process.env.PUBLISHABLE_KEY': JSON.stringify(env.PUBLISHABLE_KEY),
      'process.env.ANON_KEY': JSON.stringify(env.ANON_KEY),
      'global': 'globalThis',
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
