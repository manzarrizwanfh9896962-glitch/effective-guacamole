class HybridAIService {
  private localNodeUrl: string = "http://localhost:11434/api/generate"; // Default Ollama port

  async generateResponse(prompt: string, persona: 'INTERROGATOR' | 'ANALYST' | 'MENTOR' = 'ANALYST'): Promise<string> {
    const systemInstructions = {
      INTERROGATOR: "You are a strict technical interrogator. Focus on finding flaws in the candidate's logic. Be direct and challenging.",
      ANALYST: "You are a neutral technical analyst. Evaluate the candidate's answers based on industry standards and best practices.",
      MENTOR: "You are a supportive technical mentor. Guide the candidate towards the right answer while assessing their learning capacity."
    };

    const fullPrompt = `Candidate Input: ${prompt}`;
    const systemInstruction = systemInstructions[persona];

    // 1. Try Local Node (Ollama) first for privacy and speed
    try {
      const response = await fetch(this.localNodeUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: "llama3", // or any other local model
          prompt: `${systemInstruction}\n\n${fullPrompt}`,
          stream: false
        })
      });

      if (response.ok) {
        const data = await response.json();
        return data.response;
      }
    } catch (error) {
      console.warn("Local Node (Ollama) unreachable. Switching to Cloud Uplink (Gemini).");
    }

    // 2. Fallback to Cloud Uplink (Gemini via Backend)
    try {
      const token = localStorage.getItem('mindarchitect_token');
      if (!token) {
        return "Error: Authentication required for Cloud Uplink.";
      }

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ 
          message: fullPrompt,
          systemInstruction: systemInstruction
        })
      });

      if (!response.ok) {
        throw new Error(`Cloud Uplink failed: ${response.statusText}`);
      }

      const data = await response.json();
      return data.response || "Error: No response from Cloud Uplink.";
    } catch (error) {
      console.error("Cloud Uplink failed:", error);
      return "Error: All AI nodes are unresponsive. Protocol 0x00_FAIL initiated.";
    }
  }
}

export const geminiService = new HybridAIService();
