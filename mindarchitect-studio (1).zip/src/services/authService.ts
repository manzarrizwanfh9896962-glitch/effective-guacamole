import axios from 'axios';

const API_URL = '/api';

// Create an axios instance for API calls
const apiClient = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add the access token to headers
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('mindarchitect_access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle token refresh
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    // If the error is 401 and we haven't retried yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('mindarchitect_refresh_token');
        if (!refreshToken) {
          throw new Error('No refresh token available');
        }

        // Call the refresh token endpoint
        const response = await axios.post(`${API_URL}/auth/refresh-token`, {
          token: refreshToken,
        });

        const { accessToken } = response.data;

        // Store the new access token
        localStorage.setItem('mindarchitect_access_token', accessToken);

        // Update the original request header and retry
        originalRequest.headers.Authorization = `Bearer ${accessToken}`;
        return apiClient(originalRequest);
      } catch (refreshError) {
        // If refresh fails, clear tokens and redirect to login
        localStorage.removeItem('mindarchitect_access_token');
        localStorage.removeItem('mindarchitect_refresh_token');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export const authService = {
  async signup(email, password) {
    const response = await apiClient.post('/auth/signup', { email, password });
    const { accessToken, refreshToken, user } = response.data;
    localStorage.setItem('mindarchitect_access_token', accessToken);
    localStorage.setItem('mindarchitect_refresh_token', refreshToken);
    localStorage.setItem('mindarchitect_user', JSON.stringify(user));
    return { user };
  },

  async login(email, password) {
    const response = await apiClient.post('/auth/login', { email, password });
    const { accessToken, refreshToken, user } = response.data;
    localStorage.setItem('mindarchitect_access_token', accessToken);
    localStorage.setItem('mindarchitect_refresh_token', refreshToken);
    localStorage.setItem('mindarchitect_user', JSON.stringify(user));
    return { user };
  },

  async logout() {
    const refreshToken = localStorage.getItem('mindarchitect_refresh_token');
    if (refreshToken) {
      try {
        await apiClient.post('/auth/logout', { token: refreshToken });
      } catch (err) {
        console.error('Logout API call failed:', err);
      }
    }
    localStorage.removeItem('mindarchitect_access_token');
    localStorage.removeItem('mindarchitect_refresh_token');
    localStorage.removeItem('mindarchitect_user');
    window.location.href = '/login';
  },

  isAuthenticated() {
    return !!localStorage.getItem('mindarchitect_access_token');
  },

  getAccessToken() {
    return localStorage.getItem('mindarchitect_access_token');
  },

  getCurrentUser() {
    const userStr = localStorage.getItem('mindarchitect_user');
    return userStr ? JSON.parse(userStr) : null;
  }
};

export default apiClient;
