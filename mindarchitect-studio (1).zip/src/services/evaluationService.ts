export interface EvaluationResult {
  synthesisIndex: number; // 0-100
  technicalBenchmarks: {
    logic: number;
    architecture: number;
    security: number;
    performance: number;
  };
  protocolStatus: string;
  signature: string;
}

class EvaluationService {
  async calculateSynthesisIndex(transcript: string): Promise<EvaluationResult> {
    const token = localStorage.getItem('mindarchitect_token');
    if (!token) {
      throw new Error("Authentication required for evaluation");
    }

    console.log("Initiating evaluation via backend...");

    try {
      const response = await fetch('/api/evaluate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ transcript })
      });

      if (!response.ok) {
        throw new Error(`Evaluation failed: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("Evaluation received from backend:", data);
      return data as EvaluationResult;
    } catch (error) {
      console.error("Evaluation Service Error:", error);
      throw error; // Propagate error to UI instead of returning mock data
    }
  }
}

export const evaluationService = new EvaluationService();
