export interface Question {
  id: string;
  text: string;
  category: 'ALGORITHMIC' | 'SYSTEM_DESIGN' | 'BEHAVIORAL' | 'ARCHITECTURE';
  difficulty: 'EASY' | 'MEDIUM' | 'HARD' | 'EXPERT';
}

class ProtocolService {
  private currentRole: string = "Senior Fullstack Architect";
  private syncStatus: 'IDLE' | 'SYNCING' | 'READY' = 'IDLE';

  async initializeNeuralSync(): Promise<boolean> {
    this.syncStatus = 'SYNCING';
    // Simulate Neural Sync Protocol alignment
    await new Promise(resolve => setTimeout(resolve, 2000));
    this.syncStatus = 'READY';
    return true;
  }

  generateStrategicQuestions(role: string): Question[] {
    this.currentRole = role;
    // In a real app, this would call an AI or a database
    // For now, providing a tactical set based on the role
    return [
      {
        id: 'q1',
        category: 'ARCHITECTURE',
        difficulty: 'EXPERT',
        text: "Explain the trade-offs between Event Sourcing and traditional CRUD in a high-throughput financial system."
      },
      {
        id: 'q2',
        category: 'ALGORITHMIC',
        difficulty: 'HARD',
        text: "Design a distributed rate limiter that handles 1 million requests per second across 5 geographic regions."
      },
      {
        id: 'q3',
        category: 'SYSTEM_DESIGN',
        difficulty: 'EXPERT',
        text: "How would you architect a zero-trust authentication layer for a legacy monolithic application without downtime?"
      }
    ];
  }

  getSyncStatus() {
    return this.syncStatus;
  }
}

export const interviewService = new ProtocolService();
