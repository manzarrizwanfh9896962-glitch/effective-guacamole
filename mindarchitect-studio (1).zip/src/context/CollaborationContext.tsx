import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { authService } from '../services/authService';

interface User {
  id: string;
  name: string;
}

interface CursorPosition {
  x: number;
  y: number;
}

interface CollaborationContextType {
  socket: Socket | null;
  users: User[];
  cursors: Record<string, CursorPosition>;
  sendMessage: (message: string) => void;
  updateCursor: (x: number, y: number) => void;
}

const CollaborationContext = createContext<CollaborationContextType | undefined>(undefined);

export const CollaborationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [cursors, setCursors] = useState<Record<string, CursorPosition>>({});
  const user = authService.getCurrentUser();

  useEffect(() => {
    if (!user) return;

    const newSocket = io(window.location.origin);
    setSocket(newSocket);

    newSocket.emit('join-room', { roomId: 'dashboard', user });

    newSocket.on('user-joined', (data: { userId: string; name: string }) => {
      setUsers(prev => [...prev, { id: data.userId, name: data.name }]);
    });

    newSocket.on('user-left', (userId: string) => {
      setUsers(prev => prev.filter(u => u.id !== userId));
      setCursors(prev => {
        const next = { ...prev };
        delete next[userId];
        return next;
      });
    });

    newSocket.on('cursor-update', (data: { userId: string; x: number; y: number }) => {
      if (data.userId !== user.id) {
        setCursors(prev => ({
          ...prev,
          [data.userId]: { x: data.x, y: data.y }
        }));
      }
    });

    return () => {
      newSocket.disconnect();
    };
  }, [user?.id]);

  const sendMessage = (message: string) => {
    socket?.emit('send-message', { roomId: 'dashboard', message });
  };

  const updateCursor = (x: number, y: number) => {
    socket?.emit('cursor-move', { roomId: 'dashboard', x, y });
  };

  return (
    <CollaborationContext.Provider value={{ socket, users, cursors, sendMessage, updateCursor }}>
      {children}
    </CollaborationContext.Provider>
  );
};

export const useCollaboration = () => {
  const context = useContext(CollaborationContext);
  if (context === undefined) {
    throw new Error('useCollaboration must be used within a CollaborationProvider');
  }
  return context;
};
