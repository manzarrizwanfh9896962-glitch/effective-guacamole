import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || import.meta.env.VITE_PROJECT_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_ANON_KEY || '';
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || supabaseAnonKey;

// The user requested:
// Authentication Guard: Ensure the biometric login uses the Anon_Key for public access 
// and the Publishable_Key for authenticated session management.

// We export both clients if needed, but usually one client is enough if keys are the same.
// For the sake of the request, we'll create two instances if they differ, 
// or just export the main one.

export const supabase = createClient(supabaseUrl || 'https://placeholder.supabase.co', supabaseAnonKey || 'placeholder');

// Public client using Anon_Key
export const publicSupabase = createClient(supabaseUrl || 'https://placeholder.supabase.co', supabaseAnonKey || 'placeholder');

// Auth client using Publishable_Key
export const authSupabase = createClient(supabaseUrl || 'https://placeholder.supabase.co', supabasePublishableKey || 'placeholder');

export default supabase;
