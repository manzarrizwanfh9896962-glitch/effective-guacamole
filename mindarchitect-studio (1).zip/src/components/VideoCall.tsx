import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Video, VideoOff, Mic, MicOff, PhoneOff, Maximize2, Minimize2, Users } from 'lucide-react';
import Peer from 'simple-peer';
import { useCollaboration } from '../context/CollaborationContext';
import { authService } from '../services/authService';

interface VideoCallProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoCall: React.FC<VideoCallProps> = ({ isOpen, onClose }) => {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [peers, setPeers] = useState<Record<string, Peer.Instance>>({});
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const { socket, users } = useCollaboration();
  const user = authService.getCurrentUser();

  const myVideo = useRef<HTMLVideoElement>(null);
  const peerVideos = useRef<Record<string, HTMLVideoElement>>({});

  useEffect(() => {
    if (isOpen) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(currentStream => {
          setStream(currentStream);
          if (myVideo.current) {
            myVideo.current.srcObject = currentStream;
          }
        })
        .catch(err => console.error('Failed to get user media', err));
    } else {
      stream?.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!socket || !stream) return;

    socket.on('webrtc-signal', (data: { from: string; signal: any }) => {
      if (peers[data.from]) {
        peers[data.from].signal(data.signal);
      } else {
        const peer = new Peer({
          initiator: false,
          trickle: false,
          stream: stream,
        });

        peer.on('signal', signal => {
          socket.emit('webrtc-signal', { to: data.from, signal });
        });

        peer.on('stream', remoteStream => {
          if (peerVideos.current[data.from]) {
            peerVideos.current[data.from].srcObject = remoteStream;
          }
        });

        peer.signal(data.signal);
        setPeers(prev => ({ ...prev, [data.from]: peer }));
      }
    });

    return () => {
      socket.off('webrtc-signal');
    };
  }, [socket, stream, peers]);

  const toggleMute = () => {
    if (stream) {
      stream.getAudioTracks()[0].enabled = !stream.getAudioTracks()[0].enabled;
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (stream) {
      stream.getVideoTracks()[0].enabled = !stream.getVideoTracks()[0].enabled;
      setIsVideoOff(!isVideoOff);
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[1000] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center p-6"
    >
      <div className="w-full max-w-6xl flex-grow flex flex-col">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-evalion-teal/20 border border-evalion-teal/40 flex items-center justify-center">
              <Video className="text-evalion-teal" size={20} />
            </div>
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white uppercase">Secure Video Conference</h2>
              <p className="text-[10px] font-mono text-evalion-teal tracking-widest">ENCRYPTED_UPLINK_ESTABLISHED</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex -space-x-2">
              {users.map(u => (
                <div key={u.id} className="w-8 h-8 rounded-full bg-evalion-purple/20 border border-evalion-purple/40 flex items-center justify-center text-[10px] font-bold text-evalion-purple">
                  {u.name.charAt(0)}
                </div>
              ))}
            </div>
            <span className="text-[10px] font-mono text-white/40 uppercase tracking-widest">{users.length} PARTICIPANTS</span>
          </div>
        </div>

        <div className="flex-grow grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="relative aspect-video bg-black/40 rounded-2xl border border-evalion-teal/30 overflow-hidden group">
            <video ref={myVideo} autoPlay muted playsInline className="w-full h-full object-cover" />
            <div className="absolute bottom-4 left-4 px-3 py-1 bg-black/60 backdrop-blur-md border border-evalion-teal/30 rounded-lg text-[10px] font-mono text-evalion-teal uppercase tracking-widest">
              {user?.name} (YOU)
            </div>
            {isVideoOff && (
              <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
                <VideoOff size={48} className="text-white/20" />
              </div>
            )}
          </div>

          {Object.keys(peers).map(peerId => (
            <div key={peerId} className="relative aspect-video bg-black/40 rounded-2xl border border-white/10 overflow-hidden group">
              <video
                ref={el => { if (el) peerVideos.current[peerId] = el; }}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-4 px-3 py-1 bg-black/60 backdrop-blur-md border border-white/10 rounded-lg text-[10px] font-mono text-white/60 uppercase tracking-widest">
                {users.find(u => u.id === peerId)?.name || 'REMOTE_USER'}
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-center gap-6">
          <button
            onClick={toggleMute}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${isMuted ? 'bg-evalion-danger/20 border border-evalion-danger text-evalion-danger' : 'bg-white/5 border border-white/10 text-white hover:bg-white/10'}`}
          >
            {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
          </button>
          <button
            onClick={toggleVideo}
            className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${isVideoOff ? 'bg-evalion-danger/20 border border-evalion-danger text-evalion-danger' : 'bg-white/5 border border-white/10 text-white hover:bg-white/10'}`}
          >
            {isVideoOff ? <VideoOff size={24} /> : <Video size={24} />}
          </button>
          <button
            onClick={onClose}
            className="w-20 h-14 bg-evalion-danger text-white rounded-2xl flex items-center justify-center hover:bg-evalion-danger/90 transition-all shadow-[0_0_20px_rgba(255,42,109,0.4)]"
          >
            <PhoneOff size={24} />
          </button>
          <button
            onClick={() => setIsFullScreen(!isFullScreen)}
            className="w-14 h-14 bg-white/5 border border-white/10 text-white rounded-2xl flex items-center justify-center hover:bg-white/10 transition-all"
          >
            {isFullScreen ? <Minimize2 size={24} /> : <Maximize2 size={24} />}
          </button>
        </div>
      </div>
    </motion.div>
  );
};
