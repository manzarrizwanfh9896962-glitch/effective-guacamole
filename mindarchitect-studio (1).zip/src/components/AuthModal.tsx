import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Fingerprint, Terminal, X, ArrowRight, User, UserCheck, ShieldAlert, ScanFace, Camera, Loader2, Eye, EyeOff } from 'lucide-react';
import axios from 'axios';
import { startRegistration, startAuthentication } from '@simplewebauthn/browser';

export const AuthModal = ({ isOpen, onClose, onLogin }: { isOpen: boolean, onClose: () => void, onLogin: () => void }) => {
  const [activeTab, setActiveTab] = useState<'CANDIDATE' | 'INTERVIEWER' | 'ADMIN'>('ADMIN');
  const [isSignup, setIsSignup] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Biometric State
  const [isScanning, setIsScanning] = useState(false);
  const [scanType, setScanType] = useState<'IRIS' | 'FINGERPRINT' | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isBiometricRegistered, setIsBiometricRegistered] = useState(false);
  const [biometricRegistering, setBiometricRegistering] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
      setIsScanning(false);
      setScanType(null);
      setScanProgress(0);
      setCameraError(null);
      setError(null);
    }
  }, [isOpen]);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  };

  const handleBiometricRegistration = async () => {
    setBiometricRegistering(true);
    setError(null);
    try {
      const resp = await axios.post('/api/auth/biometric/register/start', { email });
      const attResp = await startRegistration(resp.data);
      await axios.post('/api/auth/biometric/register/finish', { attResp });
      setIsBiometricRegistered(true);
      alert('Biometric credential registered successfully!');
    } catch (err: any) {
      console.error('Biometric registration failed:', err);
      let msg = err.response?.data?.error || err.message || 'Biometric registration failed';
      if (msg.includes("publickey-credentials-create") || msg.includes("NotAllowedError")) {
        msg = "Biometric registration is blocked. Please ensure you are running this app in a secure context with WebAuthn permissions enabled.";
      }
      setError(msg);
    } finally {
      setBiometricRegistering(false);
    }
  };

  const startBiometricScan = async (type: 'IRIS' | 'FINGERPRINT') => {
    setIsScanning(true);
    setScanType(type);
    setScanProgress(0);
    setCameraError(null);
    setError(null);

    try {
      // For IRIS scan, simulate camera access
      if (type === 'IRIS') {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }

      // Start WebAuthn authentication
      const resp = await axios.post('/api/auth/biometric/login/start', { email });
      const asseResp = await startAuthentication(resp.data);
      const authFinishResp = await axios.post('/api/auth/biometric/login/finish', { asseResp });

      if (authFinishResp.data.verified) {
        localStorage.setItem('token', authFinishResp.data.token);
        // Simulate scanning progress for visual effect after successful auth
        let progress = 0;
        const interval = setInterval(() => {
          progress += 5;
          setScanProgress(progress);
          if (progress >= 100) {
            clearInterval(interval);
            setTimeout(() => {
              stopCamera();
              onLogin();
            }, 500);
          }
        }, 50);
      } else {
        setError('Biometric authentication failed.');
        setIsScanning(false);
        stopCamera();
      }
    } catch (err: any) {
      console.error("Biometric authentication error", err);
      if (type === 'IRIS' && err.name === 'NotAllowedError' && !err.message.includes("publickey-credentials-get")) {
        setCameraError("CAMERA_ACCESS_DENIED. PLEASE ENABLE PERMISSIONS.");
      }
      let msg = err.response?.data?.error || err.message || 'Biometric authentication failed';
      if (msg.includes("publickey-credentials-get") || (err.name === 'NotAllowedError' && type === 'FINGERPRINT')) {
        msg = "Biometric login is blocked. Please ensure you are running this app in a secure context with WebAuthn permissions enabled.";
      }
      setError(msg);
      setIsScanning(false);
      stopCamera();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isSignup) {
      if (password !== confirmPassword) {
        setError("Encryption keys do not match.");
        return;
      }
      try {
        const response = await axios.post('/api/auth/register', { email, password });
        localStorage.setItem('token', response.data.token);
        onLogin();
      } catch (err: any) {
        setError(err.response?.data?.error || 'Registration failed');
      }
    } else {
      try {
        const response = await axios.post('/api/auth/login', { email, password });
        localStorage.setItem('token', response.data.token);
        onLogin();
      } catch (err: any) {
        setError(err.response?.data?.error || 'Login failed');
      }
    }
  };

  const getAccentColor = () => {
    switch (activeTab) {
      case 'ADMIN': return 'evalion-teal';
      case 'INTERVIEWER': return 'evalion-purple';
      case 'CANDIDATE': return 'evalion-textDim';
      default: return 'evalion-teal';
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="w-full max-w-md bg-[#0A0A0F] rounded-2xl border border-evalion-purple/30 overflow-hidden relative shadow-[0_0_50px_rgba(157,0,255,0.15)] max-h-[90vh] overflow-y-auto custom-scrollbar"
          >
            {/* Header */}
            <div className="pt-8 pb-4 text-center relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-evalion-purple/30 bg-evalion-purple/10 text-evalion-purple text-[10px] font-mono mb-6">
                <span className="w-1.5 h-1.5 rounded-full bg-evalion-purple animate-pulse"></span>
                ZERO_TRUST_GATEWAY_V1.2
              </div>
              <h2 className="text-2xl font-bold tracking-widest text-white mb-2">
                {isScanning ? 'BIOMETRIC VERIFICATION' : isSignup ? 'INITIALIZE PROFILE' : 'INITIALIZE ACCESS'}
              </h2>
              <p className="text-[10px] font-mono text-evalion-textDim tracking-[0.2em] uppercase">
                {isScanning ? 'AWAITING NEURAL MATCH' : isSignup ? 'NEW NODE REGISTRATION' : 'NEURAL VERIFICATION PROTOCOL'}
              </p>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 text-evalion-danger text-xs font-mono tracking-wide"
                >
                  ERROR: {error}
                </motion.div>
              )}
            </div>

            {/* Content */}
            <div className="p-8 pt-4 relative z-10">
              {isScanning ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center space-y-6"
                >
                  <div className="relative w-full aspect-square max-w-[240px] rounded-2xl overflow-hidden border border-evalion-teal/30 bg-black flex items-center justify-center">
                    {cameraError ? (
                      <div className="text-center p-4 space-y-2">
                        <ShieldAlert className="text-evalion-danger mx-auto" size={32} />
                        <p className="text-[10px] font-mono text-evalion-danger">{cameraError}</p>
                        <button 
                          onClick={() => setIsScanning(false)}
                          className="mt-4 px-4 py-2 border border-evalion-textDim/30 rounded text-xs font-mono hover:bg-white/5 transition-colors"
                        >
                          RETURN_TO_MANUAL_ENTRY
                        </button>
                      </div>
                    ) : (
                      <>
                        <video 
                          ref={videoRef} 
                          autoPlay 
                          playsInline 
                          muted 
                          className="absolute inset-0 w-full h-full object-cover opacity-60 grayscale"
                        />
                        {/* Scanning Overlay */}
                        <div className="absolute inset-0 pointer-events-none">
                          <motion.div 
                            className="w-full h-1 bg-evalion-teal shadow-[0_0_15px_rgba(0,240,255,0.8)]"
                            animate={{ y: ['0%', '240px', '0%'] }}
                            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                          />
                          <div className="absolute inset-0 border-[20px] border-transparent border-t-evalion-teal/20 border-b-evalion-teal/20 rounded-2xl"></div>
                          
                          {scanType === 'IRIS' && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="w-32 h-32 rounded-full border border-evalion-purple/40 border-dashed animate-spin-slow"></div>
                              <div className="absolute w-16 h-16 rounded-full border border-evalion-teal/60"></div>
                              <div className="absolute w-2 h-2 rounded-full bg-evalion-danger animate-ping"></div>
                            </div>
                          )}
                          
                          {scanType === 'FINGERPRINT' && (
                            <div className="absolute inset-0 flex items-center justify-center opacity-30">
                              <Fingerprint size={120} className="text-evalion-teal" />
                            </div>
                          )}
                        </div>
                      </>
                    )}
                  </div>

                  {!cameraError && (
                    <div className="w-full space-y-2">
                      <div className="flex justify-between text-[10px] font-mono text-evalion-textDim">
                        <span>{scanType === 'IRIS' ? 'RETINAL_SCAN_IN_PROGRESS' : 'DERMAL_PATTERN_ANALYSIS'}</span>
                        <span className="text-evalion-teal">{scanProgress}%</span>
                      </div>
                      <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-evalion-teal"
                          initial={{ width: 0 }}
                          animate={{ width: `${scanProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  <button 
                    onClick={() => {
                      stopCamera();
                      setIsScanning(false);
                    }}
                    className="text-[10px] font-mono text-evalion-textDim hover:text-white transition-colors tracking-widest uppercase mt-4"
                  >
                    CANCEL_BIOMETRIC_SCAN
                  </button>
                </motion.div>
              ) : (
                <>
                  {/* Tabs */}
                  <div className="flex justify-between items-center mb-8 border-b border-evalion-textDim/20 pb-4">
                    <button 
                      onClick={() => setActiveTab('CANDIDATE')}
                      className={`flex flex-col items-center gap-2 text-[10px] font-mono tracking-widest transition-colors ${activeTab === 'CANDIDATE' ? 'text-white' : 'text-evalion-textDim hover:text-white/70'}`}
                    >
                      <User size={16} />
                      CANDIDATE
                    </button>
                    <button 
                      onClick={() => setActiveTab('INTERVIEWER')}
                      className={`flex flex-col items-center gap-2 text-[10px] font-mono tracking-widest transition-colors ${activeTab === 'INTERVIEWER' ? 'text-evalion-purple' : 'text-evalion-textDim hover:text-white/70'}`}
                    >
                      <UserCheck size={16} />
                      INTERVIEWER
                    </button>
                    <button 
                      onClick={() => setActiveTab('ADMIN')}
                      className={`flex flex-col items-center gap-2 text-[10px] font-mono tracking-widest transition-colors ${activeTab === 'ADMIN' ? 'text-white bg-white/10 px-4 py-2 rounded-lg' : 'text-evalion-textDim hover:text-white/70'}`}
                    >
                      <ShieldAlert size={16} />
                      ADMIN
                    </button>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-6">
                    {isSignup && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                      >
                        <label className="block text-[10px] font-mono text-evalion-textDim mb-2 tracking-widest uppercase">IDENTIFIER (NAME)</label>
                        <input 
                          type="text" 
                          required={isSignup}
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full bg-black/50 border border-evalion-textDim/20 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-evalion-teal focus:shadow-[0_0_10px_rgba(0,240,255,0.3)] transition-all font-mono text-white placeholder:text-evalion-textDim/50" 
                          placeholder="JOHN DOE" 
                        />
                      </motion.div>
                    )}

                    <div>
                      <label className="block text-[10px] font-mono text-evalion-textDim mb-2 tracking-widest uppercase">SECURE EMAIL UPLINK</label>
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-black/50 border border-evalion-textDim/20 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-evalion-teal focus:shadow-[0_0_10px_rgba(0,240,255,0.3)] transition-all font-mono text-white placeholder:text-evalion-textDim/50" 
                        placeholder="IDENTITY@PROTOCOL.SYS" 
                      />
                    </div>

                    {isSignup && email && (
                      <motion.button
                        type="button"
                        onClick={handleBiometricRegistration}
                        disabled={biometricRegistering || isBiometricRegistered}
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className={`w-full py-3 font-bold rounded-lg flex items-center justify-center gap-2 transition-all text-xs tracking-widest mt-4
                          ${biometricRegistering ? 'bg-evalion-textDim/20 text-evalion-textDim cursor-not-allowed' :
                            isBiometricRegistered ? 'bg-evalion-teal/20 text-evalion-teal cursor-not-allowed' :
                            'bg-evalion-purple/10 text-evalion-purple hover:bg-evalion-purple/20'}
                        `}
                      >
                        {biometricRegistering ? (
                          <><Loader2 size={16} className="animate-spin" /> REGISTERING BIOMETRIC...</>
                        ) : isBiometricRegistered ? (
                          <><Fingerprint size={16} /> BIOMETRIC REGISTERED</>
                        ) : (
                          <><Fingerprint size={16} /> REGISTER BIOMETRIC</>
                        )}
                      </motion.button>
                    )}


                    {!isSignup && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <button 
                            type="button" 
                            onClick={() => startBiometricScan('FINGERPRINT')}
                            className="group relative flex flex-col items-center justify-center gap-2 py-4 rounded-xl bg-evalion-teal/5 border border-evalion-teal/20 text-evalion-teal hover:bg-evalion-teal/10 hover:border-evalion-teal/40 transition-all duration-300 overflow-hidden"
                          >
                            <div className="absolute inset-0 bg-gradient-to-t from-evalion-teal/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            <Fingerprint size={24} className="relative z-10" />
                            <span className="text-[9px] font-mono tracking-widest relative z-10">BIOMETRIC_SCAN</span>
                            <motion.div 
                              className="absolute bottom-0 left-0 h-[1px] bg-evalion-teal"
                              initial={{ width: 0 }}
                              whileHover={{ width: '100%' }}
                            />
                          </button>
                          <button 
                            type="button" 
                            onClick={() => startBiometricScan('IRIS')}
                            className="group relative flex flex-col items-center justify-center gap-2 py-4 rounded-xl bg-evalion-purple/5 border border-evalion-purple/20 text-evalion-purple hover:bg-evalion-purple/10 hover:border-evalion-purple/40 transition-all duration-300 overflow-hidden"
                          >
                            <div className="absolute inset-0 bg-gradient-to-t from-evalion-purple/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            <ScanFace size={24} className="relative z-10" />
                            <span className="text-[9px] font-mono tracking-widest relative z-10">IRIS_VERIFY</span>
                            <motion.div 
                              className="absolute bottom-0 left-0 h-[1px] bg-evalion-purple"
                              initial={{ width: 0 }}
                              whileHover={{ width: '100%' }}
                            />
                          </button>
                        </div>
                        <div className="flex items-center gap-4 py-2">
                          <div className="h-[1px] flex-grow bg-white/5"></div>
                          <span className="text-[8px] font-mono text-evalion-textDim tracking-[0.3em]">OR_USE_ENCRYPTION_KEY</span>
                          <div className="h-[1px] flex-grow bg-white/5"></div>
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="block text-[10px] font-mono text-evalion-textDim mb-2 tracking-widest uppercase">ENCRYPTION KEY</label>
                      <div className="relative">
                        <input 
                          type={showPassword ? 'text' : 'password'} 
                          required
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="w-full bg-black/50 border border-evalion-textDim/20 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-evalion-purple focus:shadow-[0_0_10px_rgba(157,0,255,0.3)] transition-all font-mono tracking-widest text-white placeholder:text-evalion-textDim/50 pr-10" 
                          placeholder="••••••••••••" 
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute inset-y-0 right-0 pr-3 flex items-center text-evalion-textDim hover:text-white transition-colors"
                        >
                          {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>

                    {isSignup && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                      >
                        <label className="block text-[10px] font-mono text-evalion-textDim mb-2 tracking-widest uppercase">CONFIRM ENCRYPTION KEY</label>
                        <div className="relative">
                          <input 
                            type={showPassword ? 'text' : 'password'} 
                            required={isSignup}
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="w-full bg-black/50 border border-evalion-textDim/20 rounded-lg px-4 py-3 text-sm focus:outline-none focus:border-evalion-purple focus:shadow-[0_0_10px_rgba(157,0,255,0.3)] transition-all font-mono tracking-widest text-white placeholder:text-evalion-textDim/50 pr-10" 
                            placeholder="••••••••••••" 
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute inset-y-0 right-0 pr-3 flex items-center text-evalion-textDim hover:text-white transition-colors"
                          >
                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                          </button>
                        </div>
                      </motion.div>
                    )}

                    <button 
                      type="submit" 
                      className={`w-full py-4 font-bold rounded-lg flex items-center justify-center gap-2 transition-all text-xs tracking-widest mt-4 ${
                        activeTab === 'INTERVIEWER' ? 'bg-evalion-purple text-white hover:bg-evalion-purple/80 shadow-[0_0_20px_rgba(157,0,255,0.4)]' :
                        activeTab === 'ADMIN' ? 'bg-white text-black hover:bg-gray-200 shadow-[0_0_20px_rgba(255,255,255,0.4)]' :
                        'bg-evalion-teal text-black hover:bg-evalion-teal/80 shadow-[0_0_20px_rgba(0,240,255,0.4)]'
                      }`}
                    >
                      {isSignup ? 'REGISTER_NODE' : 'ACCESS_DASHBOARD'} <ArrowRight size={16} />
                    </button>

                    <div className="text-center pt-4">
                      <button 
                        type="button" 
                        onClick={() => setIsSignup(!isSignup)}
                        className="text-[10px] font-mono text-evalion-textDim hover:text-white transition-colors tracking-widest uppercase"
                      >
                        {isSignup ? 'EXISTING NODE? INITIALIZE ACCESS' : 'NEW NODE? INITIALIZE PROFILE'}
                      </button>
                    </div>
                  </form>
                </>
              )}
            </div>

            {/* Footer Icons */}
            <div className="pb-6 flex justify-center gap-4 text-evalion-textDim/30 relative z-10">
              <Fingerprint size={16} />
              <Lock size={16} />
              <ShieldAlert size={16} />
            </div>
            
            {/* Top Gradient Glow */}
            <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-evalion-purple/20 to-transparent pointer-events-none"></div>
            
            {/* Close Button */}
            <button onClick={() => { stopCamera(); onClose(); }} className="absolute top-4 right-4 text-evalion-textDim hover:text-white transition-colors z-20">
              <X size={20} />
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};


