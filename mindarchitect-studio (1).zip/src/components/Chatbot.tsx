import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Bot, User, Loader2, BrainCircuit } from 'lucide-react';
import apiClient from '../services/authService';

interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
}

const CodeBlock = ({ code, language }: { code: string, language?: string }) => (
  <div className="my-2 rounded-lg overflow-hidden border border-evalion-teal/20 bg-[#050505]">
    <div className="flex items-center justify-between px-3 py-1.5 bg-white/5 border-b border-white/5">
      <span className="text-[10px] font-mono text-evalion-textDim uppercase">{language || 'CODE'}</span>
      <div className="flex gap-1.5">
        <div className="w-2 h-2 rounded-full bg-red-500/20"></div>
        <div className="w-2 h-2 rounded-full bg-yellow-500/20"></div>
        <div className="w-2 h-2 rounded-full bg-green-500/20"></div>
      </div>
    </div>
    <div className="p-3 overflow-x-auto custom-scrollbar">
      <pre className="text-xs font-mono text-evalion-text leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  </div>
);

const formatTime = (date: Date) => {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

export const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: '1', 
      role: 'model', 
      content: 'I am the MindArchitect Studio Kernel Assistant. How can I assist you with candidate analysis or system operations today?',
      timestamp: formatTime(new Date())
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [persona, setPersona] = useState<'Default' | 'Interrogator' | 'Analyst' | 'Mentor'>('Default');
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  useEffect(() => {
    const handleOpenChatbot = (e: any) => {
      setIsOpen(true);
      if (e.detail?.message) {
        setInput(e.detail.message);
      }
    };
    window.addEventListener('open-chatbot', handleOpenChatbot);
    return () => window.removeEventListener('open-chatbot', handleOpenChatbot);
  }, []);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMessage = input.trim();
    const timestamp = formatTime(new Date());
    
    setInput('');
    setError(null);
    setMessages(prev => [...prev, { 
      id: Date.now().toString(), 
      role: 'user', 
      content: userMessage,
      timestamp 
    }]);
    setIsLoading(true);

    try {
      // Prepare history for the API (excluding the last user message we just added locally)
      const history = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.content }]
      }));

      const response = await apiClient.post('/chat', { 
        message: userMessage,
        history: history,
        persona: persona === 'Default' ? undefined : persona
      });

      setMessages(prev => [...prev, { 
        id: (Date.now() + 1).toString(), 
        role: 'model', 
        content: response.data.response || 'No response generated.',
        timestamp: formatTime(new Date())
      }]);
    } catch (error: any) {
      console.error("Chat error:", error);
      setError(error.response?.data?.error || 'Failed to connect to the AI service. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderMessageContent = (content: string) => {
    const parts = content.split(/(```[\s\S]*?```)/g);
    return parts.map((part, index) => {
      if (part.startsWith('```') && part.endsWith('```')) {
        const match = part.match(/```(\w*)\n([\s\S]*?)```/);
        const language = match ? match[1] : '';
        const code = match ? match[2] : part.slice(3, -3);
        return <CodeBlock key={index} code={code} language={language} />;
      }
      return <span key={index} className="whitespace-pre-wrap">{part}</span>;
    });
  };

  return (
    <>
      {/* Floating Button */}
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 w-14 h-14 rounded-full bg-evalion-teal text-black flex items-center justify-center shadow-[0_0_20px_rgba(0,240,255,0.3)] z-50 ${isOpen ? 'hidden' : 'flex'}`}
      >
        <MessageSquare size={24} />
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-6 right-6 w-80 sm:w-96 h-[500px] max-h-[80vh] bg-[#0A0A0A] border border-evalion-teal/30 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="h-14 border-b border-evalion-teal/20 bg-evalion-surface/80 backdrop-blur-md flex items-center justify-between px-4">
              <div className="flex items-center gap-2">
                <BrainCircuit className="text-evalion-teal" size={18} />
                <span className="font-mono text-xs font-bold tracking-widest text-white">KERNEL_ASSISTANT</span>
              </div>
              <div className="flex items-center gap-2">
                <select 
                  value={persona}
                  onChange={(e) => setPersona(e.target.value as any)}
                  className="bg-black/50 border border-evalion-teal/20 text-evalion-teal text-[10px] font-mono rounded px-2 py-1 focus:outline-none"
                >
                  <option value="Default">Default</option>
                  <option value="Interrogator">Interrogator</option>
                  <option value="Analyst">Analyst</option>
                  <option value="Mentor">Mentor</option>
                </select>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="text-evalion-textDim hover:text-white transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
              {error && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-xs p-3 rounded-lg font-mono">
                  {error}
                </div>
              )}
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                      msg.role === 'user' ? 'bg-evalion-purple/20 border border-evalion-purple/30' : 'bg-evalion-teal/20 border border-evalion-teal/30'
                    }`}>
                      {msg.role === 'user' ? <User size={14} className="text-evalion-purple" /> : <Bot size={14} className="text-evalion-teal" />}
                    </div>
                    <div className={`rounded-xl p-3 text-sm ${
                      msg.role === 'user' 
                        ? 'bg-evalion-purple/10 border border-evalion-purple/20 text-white rounded-tr-none' 
                        : 'bg-evalion-surface border border-evalion-textDim/10 text-evalion-text rounded-tl-none'
                    }`}>
                      <div className="leading-relaxed">
                        {renderMessageContent(msg.content)}
                      </div>
                    </div>
                  </div>
                  <span className={`text-[9px] font-mono text-evalion-textDim mt-1 px-12 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                    {msg.timestamp}
                  </span>
                </div>
              ))}
              {isLoading && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-evalion-teal/20 border border-evalion-teal/30 flex items-center justify-center shrink-0">
                    <Bot size={14} className="text-evalion-teal" />
                  </div>
                  <div className="bg-evalion-surface border border-evalion-textDim/10 rounded-xl rounded-tl-none p-3 flex items-center gap-2">
                    <Loader2 size={14} className="text-evalion-teal animate-spin" />
                    <span className="text-xs font-mono text-evalion-textDim">PROCESSING_QUERY...</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-evalion-teal/20 bg-evalion-surface/50">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Query the Kernel..."
                  className="w-full bg-black/50 border border-evalion-textDim/20 rounded-lg pl-4 pr-12 py-3 text-sm text-white placeholder-evalion-textDim focus:outline-none focus:border-evalion-teal/50 transition-colors"
                  disabled={isLoading}
                />
                <button
                  onClick={handleSend}
                  disabled={!input.trim() || isLoading}
                  className="absolute right-2 p-2 text-evalion-teal hover:text-white disabled:opacity-50 disabled:hover:text-evalion-teal transition-colors"
                >
                  <Send size={16} />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
