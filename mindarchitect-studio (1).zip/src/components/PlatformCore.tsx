import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Layout, Server, Cpu, Shield, CheckCircle2 } from 'lucide-react';

const coreComponents = [
  { icon: <Layout className="text-evalion-teal" size={24} />, title: "FRONTEND INTERFACE" },
  { icon: <Server className="text-evalion-purple" size={24} />, title: "BACKEND CORE" },
  { icon: <Cpu className="text-evalion-text" size={24} />, title: "AI ENGINE" },
  { icon: <Shield className="text-evalion-danger" size={24} />, title: "SECURITY LAYER" }
];

export const PlatformCore = () => {
  const navigate = useNavigate();

  return (
    <section className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-end justify-between mb-20 gap-8">
          <div className="max-w-xl">
            <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-60">
              [ CORE_SYSTEM_ARCHITECTURE ]
            </h3>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6 leading-none">
              <span className="font-serif italic font-light text-evalion-textDim/50 block text-2xl md:text-3xl mb-2">Engineered for</span>
              UNCOMPROMISED<br />PERFORMANCE
            </h2>
          </div>
          <p className="max-w-xs text-evalion-textDim text-xs font-light leading-relaxed tracking-wide mb-2">
            MindArchitect Studio is built on four hardened pillars, ensuring security, scalability, and performance. Each component is designed for autonomous operation within our unified OS.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {coreComponents.map((comp, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group relative p-10 rounded-3xl bg-white/[0.02] border border-white/[0.05] hover:border-evalion-teal/30 transition-all duration-700 flex flex-col items-center text-center overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-evalion-teal/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              <div className="relative z-10 mb-8 p-5 rounded-2xl bg-black border border-white/10 group-hover:border-evalion-teal/40 group-hover:shadow-[0_0_30px_rgba(0,240,255,0.1)] transition-all duration-700">
                {comp.icon}
              </div>
              <h4 className="relative z-10 font-bold tracking-[0.3em] text-[10px] uppercase text-white/80 group-hover:text-evalion-teal transition-colors duration-700">{comp.title}</h4>
              <div className="relative z-10 w-6 h-[1px] bg-white/20 mt-6 group-hover:w-12 group-hover:bg-evalion-teal transition-all duration-700"></div>
            </motion.div>
          ))}
        </div>

        <div className="relative group/status p-8 md:p-12 rounded-[2rem] bg-white/[0.02] border border-white/[0.05] flex flex-col md:flex-row items-center justify-between gap-8 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-evalion-teal/[0.02] to-transparent"></div>
          
          <div className="relative z-10 flex items-center gap-8">
            <div className="w-16 h-16 rounded-2xl bg-evalion-teal/10 border border-evalion-teal/30 flex items-center justify-center shadow-2xl">
              <Shield className="text-evalion-teal" size={32} />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 rounded-full bg-evalion-success animate-pulse"></div>
                <h4 className="font-bold text-sm tracking-[0.2em] uppercase text-white">Security Protocol V4.2 Active</h4>
              </div>
              <p className="text-xs text-evalion-textDim font-light tracking-wide">All architectural nodes are currently synchronized and operational across global secure shards.</p>
            </div>
          </div>
          
          <button 
            onClick={() => navigate('/status')}
            className="relative z-10 px-8 py-4 bg-white text-black font-bold text-[10px] tracking-[0.3em] uppercase rounded-full hover:bg-evalion-teal transition-all duration-500 shadow-2xl"
          >
            Check System Status
          </button>
        </div>
      </div>
    </section>
  );
};