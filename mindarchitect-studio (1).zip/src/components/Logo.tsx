import React from 'react';
import { motion } from 'framer-motion';
import { Cpu } from 'lucide-react';

export const Logo = ({ className = "", size = 40 }: { className?: string, size?: number }) => {
  return (
    <div className={`relative flex items-center justify-center ${className}`} style={{ width: size, height: size }}>
      {/* 2D Core */}
      <div className="absolute inset-0 flex items-center justify-center">
        <Cpu size={size * 0.7} className="text-evalion-teal drop-shadow-[0_0_10px_rgba(0,240,255,0.5)]" />
      </div>
      
      {/* Subtle Outer Frame */}
      <motion.div 
        className="absolute inset-0 border border-evalion-teal/10 rounded-xl pointer-events-none"
        animate={{ 
          opacity: [0.1, 0.3, 0.1],
          scale: [1, 1.05, 1]
        }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
};
