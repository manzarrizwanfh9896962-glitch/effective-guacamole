import React from 'react';
import { motion } from 'framer-motion';

interface CyberLoadingProps {
  label?: string;
  subLabel?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const CyberLoading: React.FC<CyberLoadingProps> = ({ 
  label = "INITIALIZING_PROTOCOL", 
  subLabel = "SYNCING_NEURAL_STREAMS...",
  size = 'md'
}) => {
  const dimensions = {
    sm: { container: 'w-20 h-20', inner: 'w-10 h-10', dot: 'w-1.5 h-1.5' },
    md: { container: 'w-40 h-40', inner: 'w-20 h-20', dot: 'w-3 h-3' },
    lg: { container: 'w-60 h-60', inner: 'w-32 h-32', dot: 'w-4 h-4' }
  }[size];

  const [hexString, setHexString] = React.useState("0x000000");
  
  React.useEffect(() => {
    const interval = setInterval(() => {
      setHexString(`0x${Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0').toUpperCase()}`);
    }, 150);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`flex flex-col items-center justify-center ${size === 'sm' ? 'space-y-6' : 'space-y-12'} p-6 relative`}>
      {/* Background Data Stream (Subtle) */}
      {size !== 'sm' && (
        <div className="absolute inset-0 pointer-events-none opacity-5 overflow-hidden flex flex-wrap gap-4 p-4 font-mono text-[8px] text-evalion-teal">
          {[...Array(20)].map((_, i) => (
            <motion.span 
              key={i}
              animate={{ opacity: [0.2, 1, 0.2], y: [0, -10, 0] }}
              transition={{ duration: 2 + Math.random() * 3, repeat: Infinity }}
            >
              {Math.random().toString(16).substring(2, 10).toUpperCase()}
            </motion.span>
          ))}
        </div>
      )}

      <div className={`relative ${dimensions.container} flex items-center justify-center`}>
        {/* Outer Pulsing Neon Glow - More intense */}
        <motion.div 
          className="absolute inset-0 rounded-full border-2 border-evalion-teal/30"
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.6, 0.3],
            boxShadow: [
              "0 0 15px rgba(0, 240, 255, 0.2)",
              "0 0 45px rgba(0, 240, 255, 0.5)",
              "0 0 15px rgba(0, 240, 255, 0.2)"
            ]
          }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
        
        {/* Rotating Geometric Frames - Multiple layers */}
        <motion.div 
          className="absolute inset-2 rounded-full border-t-2 border-r-2 border-evalion-teal/50"
          animate={{ rotate: 360 }}
          transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
        />
        <motion.div 
          className="absolute inset-6 rounded-full border-b-2 border-l-2 border-evalion-purple/50"
          animate={{ rotate: -360 }}
          transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
        />
        <motion.div 
          className="absolute inset-10 rounded-full border-t border-white/10"
          animate={{ rotate: 180 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        />

        {/* Inner Data Flow Visualization */}
        <div className={`relative ${dimensions.inner} flex items-center justify-center overflow-hidden rounded-2xl bg-black/80 border border-white/10 backdrop-blur-xl shadow-2xl`}>
          {/* Scanning Line - Faster and more glow */}
          <motion.div 
            className="absolute inset-x-0 h-[2px] bg-evalion-teal shadow-[0_0_20px_rgba(0,240,255,1)] z-10"
            animate={{ 
              top: ["0%", "100%", "0%"],
            }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          />

          {/* Hex Data Stream */}
          <div className="absolute inset-0 flex flex-col items-center justify-center opacity-20 font-mono text-[8px] text-evalion-teal pointer-events-none">
            <span className="animate-pulse">{hexString}</span>
            <span className="opacity-50">SYNC_V1.0.24</span>
          </div>

          {/* Data Particles - More dynamic */}
          <div className="absolute inset-0 flex flex-col justify-around p-2">
            {[...Array(size === 'sm' ? 6 : 12)].map((_, i) => (
              <motion.div 
                key={i}
                className="h-[1px] w-full bg-gradient-to-r from-transparent via-evalion-teal/60 to-transparent"
                animate={{ 
                  x: ["-100%", "100%"],
                  opacity: [0, 1, 0]
                }}
                transition={{ 
                  duration: 0.8 + Math.random() * 1.5, 
                  repeat: Infinity, 
                  delay: i * 0.1,
                  ease: "linear" 
                }}
              />
            ))}
          </div>

          <motion.div 
            className={`${dimensions.dot} rounded-full bg-evalion-teal shadow-[0_0_25px_rgba(0,240,255,1)]`}
            animate={{ 
              scale: [1, 1.5, 1],
              opacity: [0.7, 1, 0.7],
              boxShadow: [
                "0 0 10px rgba(0, 240, 255, 0.5)",
                "0 0 30px rgba(0, 240, 255, 1)",
                "0 0 10px rgba(0, 240, 255, 0.5)"
              ]
            }}
            transition={{ duration: 1, repeat: Infinity }}
          />
        </div>

        {/* Corner Accents - More pronounced */}
        <div className="absolute -top-3 -left-3 w-6 h-6 border-t-2 border-l-2 border-evalion-teal shadow-[0_0_10px_rgba(0,240,255,0.5)]"></div>
        <div className="absolute -bottom-3 -right-3 w-6 h-6 border-b-2 border-r-2 border-evalion-purple shadow-[0_0_10px_rgba(139,92,246,0.5)]"></div>
      </div>

      {(label || subLabel) && (
        <div className="text-center space-y-4 relative z-10">
          {label && (
            <motion.div 
              className="relative"
              animate={{ opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              <p className={`${size === 'sm' ? 'text-[9px]' : 'text-sm'} text-evalion-teal font-bold tracking-[0.8em] uppercase drop-shadow-[0_0_8px_rgba(0,240,255,0.5)]`}>
                {label}
              </p>
              {/* Glitch Effect Overlay - More frequent */}
              <motion.p 
                className={`absolute inset-0 ${size === 'sm' ? 'text-[9px]' : 'text-sm'} text-evalion-purple font-bold tracking-[0.8em] uppercase opacity-0`}
                animate={{ 
                  opacity: [0, 0.8, 0],
                  x: [-3, 3, -3],
                  skewX: [-10, 10, -10]
                }}
                transition={{ duration: 0.15, repeat: Infinity, repeatDelay: 2 }}
              >
                {label}
              </motion.p>
            </motion.div>
          )}
          {subLabel && (
            <div className="flex items-center justify-center gap-3">
              <span className={`${size === 'sm' ? 'text-[8px]' : 'text-[11px]'} text-evalion-textDim font-mono tracking-[0.4em] uppercase opacity-80`}>
                {subLabel}
              </span>
              <motion.span 
                className="w-2 h-2 bg-evalion-teal rounded-full shadow-[0_0_10px_rgba(0,240,255,0.8)]"
                animate={{ 
                  opacity: [0, 1, 0],
                  scale: [0.8, 1.2, 0.8]
                }}
                transition={{ duration: 0.5, repeat: Infinity }}
              />
            </div>
          )}
        </div>
      )}

      {/* Progress Bar Visualization - More cyberpunk */}
      {size !== 'sm' && (
        <div className="w-72 h-1.5 bg-white/5 rounded-full overflow-hidden relative border border-white/10 backdrop-blur-sm">
          <motion.div 
            className="absolute inset-y-0 left-0 bg-gradient-to-r from-evalion-teal via-evalion-purple to-evalion-teal shadow-[0_0_15px_rgba(0,240,255,0.8)]"
            animate={{ 
              width: ["0%", "100%", "0%"],
              left: ["0%", "0%", "100%"]
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          />
          {/* Tick marks */}
          <div className="absolute inset-0 flex justify-between px-1 pointer-events-none">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="w-[1px] h-full bg-white/10"></div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
