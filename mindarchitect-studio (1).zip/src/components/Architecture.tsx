import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Code, BarChart3, ArrowRight, Info, Terminal, Fingerprint, Network } from 'lucide-react';
import { Logo } from './Logo';

const cards = [
  {
    icon: <Shield size={32} className="text-evalion-teal" />,
    title: "BIOMETRIC SENTINEL",
    desc: "Continuous neural proctoring via iris-tracking and audio forensics. RSA-4096 end-to-end encryption.",
    action: "INITIALIZE_ANALYSIS",
    tooltip: "Real-time identity verification using advanced biometric markers.",
    legalLink: "/privacy",
    legalText: "VIEW_PRIVACY_POLICY"
  },
  {
    icon: <Code size={32} className="text-evalion-purple" />,
    title: "NEURO-CODE SANDBOX",
    desc: "Virtualized assessment. Real-time O(n) algorithmic complexity mapping and heap analysis.",
    action: "INITIALIZE_ANALYSIS",
    tooltip: "Secure execution environment for deep code logic analysis.",
    legalLink: "/security",
    legalText: "VIEW_SECURITY_PROTOCOLS"
  },
  {
    icon: <BarChart3 size={32} className="text-evalion-text" />,
    title: "SYNTHESIZED ANALYTICS",
    desc: "Neural scoring engine calibrated across 5,000+ data vectors to generate a comprehensive profile.",
    action: "INITIALIZE_ANALYSIS",
    tooltip: "Multi-dimensional performance metrics and predictive hiring insights.",
    legalLink: "/terms",
    legalText: "VIEW_TERMS_OF_SERVICE"
  }
];

export const Architecture = () => {
  const [hoveredIcon, setHoveredIcon] = useState<number | null>(null);
  const navigate = useNavigate();

  return (
    <section id="platform" className="py-32 relative bg-evalion-bg overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-24">
          <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-80">
            SYSTEM_INFRASTRUCTURE_LAYERS
          </h3>
          <h2 className="text-5xl md:text-7xl font-bold tracking-tight mb-8 text-white">
            ARCHITECTURE<br />OF THE FUTURE
          </h2>
          <p className="max-w-3xl mx-auto text-evalion-textDim font-mono text-[10px] leading-relaxed tracking-[0.2em] uppercase">
            EVERY INTERACTION IS PARSED FOR DEPTH, LOGIC, AND BIOMETRIC<br />
            INTEGRITY. TRANSITIONS ARE VERIFIABLE, DATA IS ENCRYPTED,<br />
            AND INTELLIGENCE IS AUTONOMOUS.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {cards.map((card, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="perspective-1000 h-[420px] group"
            >
              <motion.div 
                className="w-full h-full relative style-preserve-3d"
                whileHover={{ rotateY: 180 }}
                transition={{ duration: 0.6, type: "spring", stiffness: 100, damping: 20 }}
              >
                {/* Front of Card */}
                <div className="absolute inset-0 backface-hidden p-10 rounded-[2rem] flex flex-col items-center text-center border border-white/5 bg-[#050505] group-hover:border-white/10 shadow-[0_0_50px_rgba(0,0,0,0.5)] transform-gpu">
                  <div 
                    className="relative w-20 h-20 rounded-3xl bg-[#0A0A0A] border border-white/5 flex items-center justify-center mb-10 transition-colors shadow-2xl"
                  >
                    {card.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-6 tracking-wider text-white uppercase">{card.title}</h3>
                  <p className="text-evalion-textDim text-[10px] font-mono leading-relaxed mb-10 flex-grow tracking-widest">
                    {card.desc}
                  </p>
                  <button className="text-[10px] font-mono tracking-[0.3em] uppercase text-white/50 flex items-center gap-3 transition-colors">
                    HOVER_FOR_DETAILS <ArrowRight size={14} />
                  </button>
                </div>

                {/* Back of Card */}
                <div className="absolute inset-0 backface-hidden rotate-y-180 p-10 rounded-[2rem] flex flex-col items-center justify-center text-center border border-evalion-teal/30 bg-[#0A0A0A] shadow-[0_0_30px_rgba(0,240,255,0.05)] transform-gpu">
                  <div className="mb-6">
                    <Info size={32} className="text-evalion-teal opacity-80" />
                  </div>
                  <h3 className="text-lg font-bold mb-4 tracking-wider text-white uppercase">SYSTEM_DETAILS</h3>
                  <p className="text-evalion-textDim text-xs font-mono leading-relaxed mb-8 tracking-widest">
                    {card.tooltip}
                  </p>
                  <button 
                    onClick={() => navigate(card.legalLink)}
                    className="mt-auto px-6 py-3 bg-evalion-teal/10 border border-evalion-teal/30 text-evalion-teal text-[10px] font-mono tracking-[0.2em] uppercase rounded-lg hover:bg-evalion-teal hover:text-black transition-all"
                  >
                    {card.legalText}
                  </button>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Architect / Owner Section */}
        <div className="mt-32 border-t border-white/10 pt-24">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative rounded-3xl overflow-hidden border border-white/10 bg-[#050505] aspect-[3/4] md:aspect-square group"
            >
              <img 
                src="/static/architect.jpg" 
                alt="Mr. Hussnain - Founder & Chief Architect" 
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-110 group-hover:scale-100"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent"></div>
              <div className="absolute bottom-0 left-0 p-8">
                <div className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-2">
                  CHIEF_ARCHITECT // FOUNDER
                </div>
                <h3 className="text-3xl font-bold tracking-tight text-white uppercase">
                  MR. HUSSNAIN
                </h3>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h3 className="text-evalion-purple font-mono text-[10px] tracking-[0.5em] uppercase opacity-80">
                DIRECTIVE_OVERRIDE
              </h3>
              <h2 className="text-4xl font-bold tracking-tight text-white uppercase leading-tight">
                ENGINEERING THE<br />NEURAL RECRUITMENT<br />PARADIGM
              </h2>
              <div className="space-y-6 text-evalion-textDim font-mono text-xs leading-relaxed tracking-wider">
                <p>
                  "The traditional recruitment model is fundamentally flawed, relying on subjective human heuristics and easily manipulated metrics. MindArchitect Studio was architected to eliminate these inefficiencies."
                </p>
                <p>
                  "By synthesizing real-time algorithmic complexity mapping with biometric stability feeds, we've created a zero-trust evaluation environment that measures true engineering capability, not just interview performance."
                </p>
                <p className="text-evalion-teal italic">
                  // SYSTEM_AUTHORIZATION_LEVEL: OMEGA
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};