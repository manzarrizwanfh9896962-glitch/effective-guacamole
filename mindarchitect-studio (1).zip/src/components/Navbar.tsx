import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Activity, Cpu, Database, Lock, Terminal, Zap, Fingerprint, Eye, BarChart, Server, Layers, Code, Users, Briefcase, ChevronRight, CheckCircle2, Phone, Mail, MapPin, LogIn, Info } from 'lucide-react';

import { Logo } from './Logo';

interface NavbarProps {
  onAuthClick: () => void;
  isLoggedIn?: boolean;
  onLogout?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onAuthClick, isLoggedIn, onLogout }) => {
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [showLogoTooltip, setShowLogoTooltip] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      isScrolled 
        ? 'bg-black/80 backdrop-blur-2xl border-b border-white/5 py-3 shadow-2xl' 
        : 'bg-transparent py-6'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <div className="relative">
          <Link 
            to="/" 
            className="flex items-center gap-3 group"
            onMouseEnter={() => setShowLogoTooltip(true)}
            onMouseLeave={() => setShowLogoTooltip(false)}
            aria-label="MindArchitect Studio Home"
          >
            <Logo size={32} />
            <span className="text-white font-bold tracking-tight text-lg hidden sm:block">
              Mind<span className="text-evalion-teal">Architect</span> <span className="text-evalion-purple">Studio</span>
            </span>
          </Link>
        </div>
        
        <div className="hidden md:flex items-center gap-12 text-[10px] font-mono tracking-[0.4em] text-white/50">
          <Link 
            to="/interview" 
            className={`hover:text-evalion-teal transition-all duration-300 relative group ${location.pathname === '/interview' ? 'text-evalion-teal' : ''}`}
          >
            EVALUATION
            <span className={`absolute -bottom-2 left-0 w-0 h-[1px] bg-evalion-teal transition-all duration-300 group-hover:w-full ${location.pathname === '/interview' ? 'w-full' : ''}`}></span>
          </Link>
          <Link 
            to="/diligence" 
            className={`hover:text-evalion-purple transition-all duration-300 relative group ${location.pathname === '/diligence' ? 'text-evalion-purple' : ''}`}
          >
            DILIGENCE
            <span className={`absolute -bottom-2 left-0 w-0 h-[1px] bg-evalion-purple transition-all duration-300 group-hover:w-full ${location.pathname === '/diligence' ? 'text-evalion-purple' : ''}`}></span>
          </Link>
          <Link 
            to="/profiling" 
            className={`hover:text-evalion-teal transition-all duration-300 relative group ${location.pathname === '/profiling' ? 'text-evalion-teal' : ''}`}
          >
            PROFILING
            <span className={`absolute -bottom-2 left-0 w-0 h-[1px] bg-evalion-teal transition-all duration-300 group-hover:w-full ${location.pathname === '/profiling' ? 'w-full' : ''}`}></span>
          </Link>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden lg:flex items-center gap-3 text-[9px] text-white/30 font-mono border border-white/5 px-4 py-1.5 rounded-full bg-white/[0.02]">
            <div className="w-1.5 h-1.5 rounded-full bg-evalion-success animate-pulse"></div>
            <span>SECURE_NODE_ACTIVE</span>
          </div>
          
          {isLoggedIn ? (
            <button 
              onClick={onLogout}
              className="group relative px-6 py-2 border border-evalion-danger/30 text-evalion-danger font-bold text-[10px] tracking-[0.3em] uppercase rounded-full hover:bg-evalion-danger hover:text-white transition-all duration-500"
            >
              <span className="relative z-10">Logout</span>
              <div className="absolute inset-0 bg-evalion-danger rounded-full blur-md opacity-0 group-hover:opacity-20 transition-opacity duration-500"></div>
            </button>
          ) : (
            <button 
              onClick={onAuthClick}
              className="group relative px-6 py-2 bg-white text-black font-bold text-[10px] tracking-[0.3em] uppercase rounded-full hover:bg-evalion-teal transition-all duration-500"
            >
              <span className="relative z-10">Login</span>
              <div className="absolute inset-0 bg-evalion-teal rounded-full blur-md opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};
