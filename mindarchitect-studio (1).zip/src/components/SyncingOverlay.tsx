import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Cpu, Activity, CheckCircle2, X } from 'lucide-react';

export const SyncingOverlay = ({ isVisible, onComplete }: { isVisible: boolean, onComplete: () => void }) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('INITIALIZING_NEURAL_LINK...');

  useEffect(() => {
    if (isVisible) {
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += 10;
        if (currentProgress >= 100) {
          currentProgress = 100;
          clearInterval(interval);
          setTimeout(onComplete, 500);
        }
        setProgress(currentProgress);

        if (currentProgress < 30) setStatus('ESTABLISHING_SECURE_CONNECTION...');
        else if (currentProgress < 60) setStatus('LOADING_BIOMETRIC_MODELS...');
        else if (currentProgress < 90) setStatus('SYNCING_NEURAL_BUFFERS...');
        else setStatus('SYSTEM_READY.');
      }, 200);

      return () => clearInterval(interval);
    }
  }, [isVisible, onComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-evalion-bg/95 backdrop-blur-xl"
        >
          <div className="w-full max-w-md px-6">
            <div className="flex items-center justify-center gap-4 mb-8">
              <div className="w-12 h-12 rounded-full border-2 border-evalion-teal flex items-center justify-center animate-spin-slow">
                <div className="w-6 h-6 bg-evalion-teal rounded-full animate-pulse shadow-[0_0_20px_#00F0FF]"></div>
              </div>
            </div>

            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold tracking-widest text-white mb-2">EVALION_OS_BOOT</h2>
              <p className="text-evalion-teal font-mono text-sm animate-pulse">{status}</p>
            </div>

            <div className="w-full h-2 bg-evalion-surface rounded-full overflow-hidden mb-4 border border-evalion-teal/20">
              <motion.div 
                className="h-full bg-gradient-to-r from-evalion-teal to-evalion-purple"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ ease: "linear" }}
              />
            </div>

            <div className="flex justify-between text-[10px] font-mono text-evalion-textDim uppercase tracking-widest">
              <span>PROGRESS: {Math.round(progress)}%</span>
              <span>EST_TIME: &lt; 1s</span>
            </div>

            {/* Simulated Logs */}
            <div className="mt-12 p-4 bg-black/50 border border-evalion-textDim/20 rounded-lg h-32 overflow-hidden font-mono text-[10px] text-evalion-textDim flex flex-col justify-end">
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                &gt; Loading kernel modules... [OK]
              </motion.div>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                &gt; Verifying biometric signatures... [OK]
              </motion.div>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.2 }}
              >
                &gt; Establishing encrypted tunnel... [OK]
              </motion.div>
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1.8 }}
                className="text-evalion-teal"
              >
                &gt; Handshake complete. Awaiting user input.
              </motion.div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};