import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Github, Twitter, Linkedin } from 'lucide-react';
import { Logo } from './Logo';

export const Footer = () => {
  return (
    <footer className="bg-[#010409] border-t border-white/5 py-16 relative overflow-hidden">
      {/* Background 3D Logo */}
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-[600px] h-[600px] opacity-[0.05] pointer-events-none flex items-center justify-center">
        <Logo size={600} />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Column 1 */}
          <div className="col-span-1">
            <div className="flex items-center mb-6 gap-3">
              <Logo size={28} />
              <span className="text-white font-bold tracking-tight text-sm">
                Mind<span className="text-evalion-teal">Architect</span> <span className="text-evalion-purple">Studio</span>
              </span>
              <span className="text-[10px] text-evalion-teal border border-evalion-teal/30 px-1 rounded bg-evalion-teal/10">1.0</span>
            </div>
            <p className="text-evalion-textDim text-[10px] font-mono leading-relaxed mb-8 tracking-widest uppercase">
              AUTONOMOUS HIRING VIA ZERO-TRUST ARCHITECTURE. NEURAL PROCTORING. BIAS-FREE SCORING.
            </p>
            <div className="space-y-4">
              <div>
                <div className="text-[8px] font-mono text-evalion-teal uppercase tracking-[0.3em] mb-1">DEVELOPED_ENTITY</div>
                <div className="text-white font-bold text-xs tracking-widest uppercase">HUSSNAINTECHVERTEX PVT</div>
              </div>
              <div>
                <div className="text-[8px] font-mono text-evalion-teal uppercase tracking-[0.3em] mb-1">ARCHITECT</div>
                <div className="text-white font-bold text-xs tracking-widest uppercase">MR. HUSSNAIN</div>
              </div>
            </div>
          </div>

          {/* Column 2 */}
          <div>
            <h4 className="flex items-center gap-2 text-white text-[10px] font-bold tracking-[0.3em] mb-8 uppercase">
              <div className="w-1.5 h-1.5 bg-evalion-teal rounded-full"></div> CORE_SYSTEMS
            </h4>
            <ul className="space-y-4 text-[10px] font-mono tracking-[0.2em] text-evalion-textDim uppercase">
              <li><Link to="/interview" className="hover:text-evalion-teal transition-colors">EVALUATION_ENGINE</Link></li>
              <li><Link to="/diligence" className="hover:text-evalion-teal transition-colors">AUTONOMOUS_DILIGENCE</Link></li>
              <li><Link to="/profiling" className="hover:text-evalion-teal transition-colors">NEURAL_PROFILING</Link></li>
              <li><Link to="/architecture" className="hover:text-evalion-teal transition-colors">SYSTEM_ARCHITECTURE</Link></li>
              <li><Link to="/platform" className="hover:text-evalion-teal transition-colors">PLATFORM_CORE</Link></li>
              <li className="flex items-center gap-2 text-evalion-textDim"><Link to="/status" className="hover:text-evalion-teal transition-colors">SYSTEM_LIVE</Link> <div className="w-1.5 h-1.5 bg-evalion-success rounded-full animate-pulse"></div></li>
            </ul>
          </div>

          {/* Column 3 */}
          <div>
            <h4 className="flex items-center gap-2 text-white text-[10px] font-bold tracking-[0.3em] mb-8 uppercase">
              <div className="w-1.5 h-1.5 bg-evalion-purple rounded-full"></div> RESOURCES
            </h4>
            <ul className="space-y-4 text-[10px] font-mono tracking-[0.2em] text-evalion-textDim uppercase">
              <li><Link to="/api" className="hover:text-evalion-purple transition-colors">API_DOCUMENTATION</Link></li>
              <li><Link to="/deployment" className="hover:text-evalion-purple transition-colors">DEPLOYMENT_GUIDE</Link></li>
              <li><Link to="/enterprise" className="hover:text-evalion-purple transition-colors">ENTERPRISE_SOLUTIONS</Link></li>
              <li><Link to="/contact" className="hover:text-evalion-purple transition-colors">COMMS_LINK</Link></li>
              <li><Link to="/terms" className="hover:text-evalion-purple transition-colors">TERMS_OF_SERVICE</Link></li>
              <li><Link to="/privacy" className="hover:text-evalion-purple transition-colors">PRIVACY_PROTOCOL</Link></li>
              <li><Link to="/security" className="hover:text-evalion-purple transition-colors">SECURITY_MATRIX</Link></li>
            </ul>
          </div>

          {/* Column 4 */}
          <div>
            <h4 className="flex items-center gap-2 text-white text-[10px] font-bold tracking-[0.3em] mb-8 uppercase">
              <div className="w-1.5 h-1.5 bg-evalion-text rounded-full"></div> HQ_UPLINK
            </h4>
            <ul className="space-y-4 text-[10px] font-mono tracking-[0.1em] text-evalion-textDim uppercase mb-8">
              <li className="flex items-center gap-3">
                <Phone size={12} className="text-evalion-teal" />
                +92 302 8808488
              </li>
              <li className="flex items-center gap-3">
                <Mail size={12} className="text-evalion-teal" />
                HUSSNAINTECHOFFICIAL@GMAIL.COM
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={12} className="text-evalion-teal shrink-0 mt-0.5" />
                <span>DASKA, SIALKOT,<br/>PAKISTAN</span>
              </li>
            </ul>
            <div className="flex gap-4">
              <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-evalion-teal hover:bg-evalion-teal/10 transition-colors"><Twitter size={14} /></a>
              <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-evalion-teal hover:bg-evalion-teal/10 transition-colors"><Linkedin size={14} /></a>
              <a href="#" className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-evalion-teal hover:bg-evalion-teal/10 transition-colors"><Github size={14} /></a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};
