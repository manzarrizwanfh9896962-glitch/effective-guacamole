import React from 'react';
import { motion } from 'framer-motion';
import { Building2, Server, Users, BarChart } from 'lucide-react';

export const Enterprise = () => {
  return (
    <section id="entity" className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-20 mb-32">
          <div className="flex-1">
            <h3 className="text-evalion-purple font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-60">
              [ ENTERPRISE_SOLUTIONS ]
            </h3>
            <h2 className="text-5xl md:text-8xl font-bold tracking-tighter mb-10 leading-none">
              <span className="font-serif italic font-light text-evalion-textDim/50 block text-3xl md:text-4xl mb-2">Deploy at</span>
              GLOBAL SCALE
            </h2>
            <p className="max-w-xl text-evalion-textDim font-light text-base leading-relaxed tracking-wide mb-10">
              Standardize technical assessments across 50+ countries. Integrate with your existing HRIS stack. Ensure compliance with automated audit trails.
            </p>
            <button className="group relative px-10 py-5 bg-white text-black font-bold text-[10px] tracking-[0.4em] uppercase rounded-full hover:bg-evalion-purple transition-all duration-500 shadow-2xl">
              <span className="relative z-10">Schedule Briefing</span>
              <div className="absolute inset-0 bg-evalion-purple rounded-full blur-xl opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
            </button>
          </div>

          <div className="flex-1 w-full">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-evalion-purple/20 to-evalion-teal/20 rounded-[2.5rem] blur-2xl opacity-50 group-hover:opacity-100 transition-opacity duration-1000"></div>
              <div className="relative glass-panel p-10 md:p-12 rounded-[2.5rem] bg-black border border-white/5 overflow-hidden">
                <div className="flex items-center gap-6 mb-12">
                  <div className="w-16 h-16 rounded-2xl bg-evalion-purple/10 border border-evalion-purple/30 flex items-center justify-center shadow-2xl">
                    <Building2 size={32} className="text-evalion-purple" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold tracking-widest text-white">TechGlobal Corp</h4>
                    <p className="text-[10px] font-mono text-evalion-purple/50 uppercase tracking-[0.3em]">Enterprise_Instance_01</p>
                  </div>
                </div>

                <div className="space-y-10">
                  <div>
                    <div className="flex justify-between text-[10px] font-mono text-white/40 uppercase tracking-widest mb-4">
                      <span>Active Pipelines</span>
                      <span className="text-white">142</span>
                    </div>
                    <div className="w-full h-[2px] bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: '75%' }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.5, ease: "easeOut" }}
                        className="h-full bg-evalion-purple shadow-[0_0_15px_rgba(139,92,246,0.5)]"
                      ></motion.div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px] font-mono text-white/40 uppercase tracking-widest mb-4">
                      <span>Candidates Processed (24h)</span>
                      <span className="text-white">8,920</span>
                    </div>
                    <div className="w-full h-[2px] bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        whileInView={{ width: '45%' }}
                        viewport={{ once: true }}
                        transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
                        className="h-full bg-evalion-purple shadow-[0_0_15px_rgba(139,92,246,0.5)]"
                      ></motion.div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-6 border-t border-white/5">
                    <div className="text-[10px] font-mono text-white/40 uppercase tracking-widest">System Uptime</div>
                    <div className="text-evalion-success font-bold tracking-[0.2em]">99.999%</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {[
            { icon: <Server size={24} />, title: "On-Premise / VPC", desc: "Deploy EvalionMind completely within your own VPC or physical infrastructure for maximum data control." },
            { icon: <Users size={24} />, title: "SSO & RBAC", desc: "Seamless integration with Okta, Azure AD, and Google Workspace. Granular permission controls." },
            { icon: <BarChart size={24} />, title: "Custom BI Reporting", desc: "Direct SQL access to your recruitment data lake for creating custom dashboards and insights." }
          ].map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group p-10 rounded-3xl bg-white/[0.02] border border-white/[0.05] hover:border-evalion-purple/30 transition-all duration-700"
            >
              <div className="w-12 h-12 rounded-xl bg-evalion-purple/10 border border-evalion-purple/30 flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500">
                <div className="text-evalion-purple">{item.icon}</div>
              </div>
              <h4 className="text-sm font-bold tracking-[0.2em] uppercase mb-4 text-white/80 group-hover:text-evalion-purple transition-colors duration-700">{item.title}</h4>
              <p className="text-xs text-evalion-textDim font-light leading-relaxed tracking-wide">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};