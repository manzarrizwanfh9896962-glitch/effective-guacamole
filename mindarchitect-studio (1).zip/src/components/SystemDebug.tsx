import React, { useState, useEffect } from 'react';
import * as Sentry from '@sentry/react';
import { ShieldCheck, ShieldAlert, Activity, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const SystemDebug = () => {
  const [sentryStatus, setSentryStatus] = useState<'checking' | 'connected' | 'disconnected'>('checking');
  const [lastError, setLastError] = useState<string | null>(null);
  const [backendStatus, setBackendStatus] = useState<'unknown' | 'online' | 'offline'>('unknown');

  useEffect(() => {
    // Check if Sentry is initialized
    const client = Sentry.getClient();
    if (client && import.meta.env.VITE_SENTRY_DSN) {
      setSentryStatus('connected');
    } else {
      setSentryStatus('disconnected');
    }

    // Check backend health
    fetch('/api/health')
      .then(res => {
        if (res.ok) setBackendStatus('online');
        else setBackendStatus('offline');
      })
      .catch(() => setBackendStatus('offline'));
  }, []);

  const triggerFrontendError = () => {
    try {
      throw new Error("Sentry Test Error: Frontend Exception Triggered");
    } catch (err: any) {
      Sentry.captureException(err);
      setLastError(`Frontend Error Captured: ${err.message}`);
      console.error("Frontend Error Triggered:", err);
    }
  };

  const triggerBackendError = async () => {
    try {
      const response = await fetch('/api/debug-sentry');
      if (!response.ok) {
        setLastError(`Backend Error Triggered: Status ${response.status} (Check Sentry Dashboard)`);
      }
    } catch (err: any) {
      console.error("Failed to trigger backend error:", err);
      setLastError(`Failed to reach backend: ${err.message}`);
    }
  };

  if (process.env.NODE_ENV === 'production' && !import.meta.env.VITE_SENTRY_DSN) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 border-t border-white/5 mt-12 relative overflow-hidden">
      <div className="glass-panel p-8 rounded-3xl border border-white/10 shadow-2xl relative z-10">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-8">
          
          {/* Status Indicators */}
          <div className="flex-1 space-y-6">
            <div className="flex items-center gap-4">
              <h3 className="text-white font-bold text-xl tracking-tight uppercase">System Diagnostics</h3>
              <div className="flex gap-3">
                {sentryStatus === 'connected' ? (
                  <span className="flex items-center gap-2 text-[10px] font-mono bg-evalion-teal/10 text-evalion-teal px-3 py-1.5 rounded-full border border-evalion-teal/20 shadow-[0_0_10px_rgba(0,240,255,0.1)]">
                    <ShieldCheck size={14} /> SENTRY_ACTIVE
                  </span>
                ) : (
                  <span className="flex items-center gap-2 text-[10px] font-mono bg-evalion-danger/10 text-evalion-danger px-3 py-1.5 rounded-full border border-evalion-danger/20">
                    <ShieldAlert size={14} /> SENTRY_OFFLINE
                  </span>
                )}
                
                {backendStatus === 'online' ? (
                  <span className="flex items-center gap-2 text-[10px] font-mono bg-green-500/10 text-green-400 px-3 py-1.5 rounded-full border border-green-500/20 shadow-[0_0_10px_rgba(34,197,94,0.1)]">
                    <CheckCircle2 size={14} /> KERNEL_ONLINE
                  </span>
                ) : (
                  <span className="flex items-center gap-2 text-[10px] font-mono bg-red-500/10 text-red-400 px-3 py-1.5 rounded-full border border-red-500/20">
                    <AlertTriangle size={14} /> KERNEL_OFFLINE
                  </span>
                )}
              </div>
            </div>
            
            <p className="text-evalion-textDim text-xs font-mono uppercase tracking-[0.2em] opacity-60">
              Observability & Error Tracking Control Plane // NODE_ID: {Math.random().toString(36).substring(7).toUpperCase()}
            </p>

            {lastError && (
              <div className="mt-4 flex items-center gap-4 text-xs font-mono text-orange-300 bg-orange-500/10 px-5 py-4 rounded-xl border border-orange-500/20 animate-pulse">
                <Activity size={16} className="shrink-0" />
                <span>{lastError}</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 w-full md:w-auto">
            <button
              onClick={triggerFrontendError}
              className="flex-1 md:flex-none px-6 py-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl text-[10px] font-mono font-bold tracking-[0.2em] uppercase transition-all active:scale-95 shadow-lg"
            >
              TRIGGER_UI_EXCEPTION
            </button>
            <button
              onClick={triggerBackendError}
              className="flex-1 md:flex-none px-6 py-3 bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xl text-[10px] font-mono font-bold tracking-[0.2em] uppercase transition-all active:scale-95 shadow-lg"
            >
              TRIGGER_KERNEL_PANIC
            </button>
          </div>
        </div>
      </div>
      
      {/* Background Glow */}
      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-evalion-teal/5 rounded-full blur-[100px] pointer-events-none"></div>
    </div>
  );
};
