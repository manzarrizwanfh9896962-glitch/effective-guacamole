import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Logo } from './Logo';

export const LoadingScreen = ({ onFinished }: { onFinished: () => void }) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState('INITIALIZING_KERNEL');
  const finishedRef = useRef(false);
  const onFinishedRef = useRef(onFinished);

  useEffect(() => {
    onFinishedRef.current = onFinished;
  }, [onFinished]);

  useEffect(() => {
    let currentProgress = 0;
    const timer = setInterval(() => {
      // Smoother, more organic progress increments
      const remaining = 100 - currentProgress;
      const jump = Math.max(0.2, Math.random() * (remaining * 0.15));
      currentProgress = Math.min(100, currentProgress + jump);
      
      setProgress(currentProgress);

      if (currentProgress >= 100) {
        clearInterval(timer);
        if (!finishedRef.current) {
          finishedRef.current = true;
          setTimeout(() => onFinishedRef.current(), 800);
        }
      }
    }, 50);

    const statusTimer = setInterval(() => {
      const statuses = [
        'INITIALIZING_KERNEL',
        'LOADING_NEURAL_WEIGHTS',
        'ESTABLISHING_SECURE_UPLINK',
        'CALIBRATING_BIOMETRICS',
        'SYNCHRONIZING_NODES',
        'READY'
      ];
      setStatus((prev) => {
        const currentIndex = statuses.indexOf(prev);
        return statuses[Math.min(currentIndex + 1, statuses.length - 1)];
      });
    }, 600);

    return () => {
      clearInterval(timer);
      clearInterval(statusTimer);
    };
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1, filter: 'blur(20px)' }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-[200] bg-evalion-bg flex flex-col items-center justify-center p-6 overflow-hidden"
    >
      {/* Immersive Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,240,255,0.15),transparent_70%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(139,92,246,0.1),transparent_50%)]" />
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -top-1/2 -left-1/2 w-full h-full bg-evalion-teal/5 rounded-full blur-[120px]" 
        />
        <motion.div 
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.4, 0.2]
          }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-evalion-purple/5 rounded-full blur-[120px]" 
        />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.8, filter: 'blur(10px)' }}
        animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
        className="mb-12 relative z-10"
      >
        <div className="relative flex items-center justify-center">
          <Logo size={150} />
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            className="absolute -inset-8 border border-evalion-teal/10 rounded-full border-dashed"
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 45, repeat: Infinity, ease: "linear" }}
            className="absolute -inset-12 border border-evalion-purple/10 rounded-full border-dotted"
          />
        </div>
      </motion.div>

      <div className="w-full max-w-md relative z-10">
        <div className="flex justify-between items-end mb-4">
          <div className="flex flex-col">
            <motion.span 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-evalion-teal text-[10px] font-mono tracking-[0.3em] mb-1"
            >
              SYSTEM_BOOT_SEQUENCE
            </motion.span>
            <motion.span 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-white font-bold tracking-tight text-2xl"
            >
              Mind<span className="text-evalion-teal">Architect</span> <span className="text-evalion-purple">Studio</span>
            </motion.span>
          </div>
          <motion.span 
            key={progress}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-evalion-teal font-mono text-xs"
          >
            {Math.round(progress)}%
          </motion.span>
        </div>
        
        <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden mb-4 backdrop-blur-sm">
          <motion.div 
            className="h-full bg-gradient-to-r from-evalion-teal via-evalion-purple to-evalion-teal shadow-[0_0_20px_rgba(0,240,255,0.5)]"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ type: "spring", bounce: 0, duration: 0.5 }}
          />
        </div>

        <div className="flex items-center gap-3 text-[10px] font-mono text-evalion-textDim uppercase tracking-widest">
          <div className="w-2 h-2 rounded-full bg-evalion-teal animate-pulse shadow-[0_0_8px_rgba(0,240,255,0.8)]"></div>
          <AnimatePresence mode="wait">
            <motion.span
              key={status}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
            >
              {status}...
            </motion.span>
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
};
