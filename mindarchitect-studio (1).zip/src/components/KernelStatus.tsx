import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, CheckCircle2, AlertTriangle, ShieldAlert, Info } from 'lucide-react';
import apiClient from '../services/authService';

interface NodeData {
  id: string;
  region: string;
  status: string;
  latency: string;
}

const DEFAULT_NODES: NodeData[] = [
  { id: '1', region: "US-EAST-1", status: "OPTIMAL", latency: "12ms" },
  { id: '2', region: "EU-WEST-2", status: "OPTIMAL", latency: "24ms" },
  { id: '3', region: "AP-NORTHEAST-1", status: "STABLE", latency: "145ms" },
  { id: '4', region: "SA-EAST-1", status: "OPTIMAL", latency: "45ms" }
];

export const KernelStatus = () => {
  const navigate = useNavigate();
  const [nodes, setNodes] = useState<NodeData[]>(DEFAULT_NODES);
  const [lastSync, setLastSync] = useState<string>(new Date().toLocaleTimeString());
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  useEffect(() => {
    const fetchNodes = async () => {
      try {
        const response = await apiClient.get('/nodes');
        if (response.data && response.data.length > 0) {
          setNodes(response.data);
          setLastSync(new Date().toLocaleTimeString());
        }
      } catch (err) {
        console.error('API connection error:', err);
      }
    };

    fetchNodes();
    const interval = setInterval(fetchNodes, 30000);
    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status: string) => {
    const s = status?.toUpperCase() || '';
    if (s === 'OPTIMAL' || s === 'ONLINE') {
      return (
        <motion.div
          animate={{ scale: [1, 1.2, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        >
          <CheckCircle2 size={16} className="text-evalion-success" />
        </motion.div>
      );
    } else if (s === 'STABLE') {
      return <CheckCircle2 size={16} className="text-evalion-teal" />;
    } else {
      return (
        <motion.div
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 2 }}
        >
          <AlertTriangle size={16} className="text-evalion-danger" />
        </motion.div>
      );
    }
  };

  return (
    <section className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12 mb-16">
          <div>
            <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-4 flex items-center gap-3 opacity-60">
              <Activity size={14} className="animate-pulse" /> [ SYSTEM_KERNEL_STATUS ]
            </h3>
            <h2 className="text-3xl md:text-5xl font-bold tracking-tighter text-white">Global Infrastructure</h2>
          </div>
          <div className="flex items-center gap-6 text-[10px] font-mono tracking-widest">
            <span className="flex items-center gap-3 text-evalion-success">
              <div className="w-2 h-2 rounded-full bg-evalion-success animate-pulse"></div>
              ALL SYSTEMS OPERATIONAL
            </span>
            <span className="text-white/20">|</span>
            <span className="text-white/40 uppercase">Last_Sync: {lastSync}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {nodes.map((node, idx) => (
            <motion.div 
              key={node.id || idx} 
              onHoverStart={() => setHoveredNode(node.id)}
              onHoverEnd={() => setHoveredNode(null)}
              whileHover={{ scale: 1.05, y: -5 }}
              className={`group relative p-8 rounded-3xl bg-white/[0.02] border transition-all duration-500 flex flex-col justify-between h-48 overflow-hidden ${
                hoveredNode === node.id ? 'border-evalion-teal/50 bg-white/[0.05]' : 'border-white/[0.05]'
              }`}
            >
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              
              <div className="relative z-10 flex justify-between items-start">
                <span className="text-[10px] font-bold tracking-[0.2em] text-white/60 uppercase">{node.region}</span>
                {getStatusIcon(node.status)}
              </div>

              <div className="relative z-10">
                <AnimatePresence mode="wait">
                  {hoveredNode === node.id ? (
                    <motion.div
                      key="details"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-2"
                    >
                      <div className="flex items-center gap-2 text-[9px] font-mono text-evalion-teal uppercase tracking-widest">
                        <Info size={10} /> Node Details
                      </div>
                      <div className="text-[10px] text-white/60 font-mono">
                        Uptime: 99.99%<br />
                        Load: 12.4%<br />
                        Status: {node.status}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="latency"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                    >
                      <div className="text-[9px] font-mono text-white/30 uppercase tracking-widest mb-2">Latency</div>
                      <div className="text-3xl font-mono font-bold text-white tracking-tighter">{node.latency}</div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {node.status === 'OPTIMAL' && (
                <motion.div
                  className="absolute bottom-0 left-0 w-full h-1 bg-evalion-success/20"
                  animate={{ opacity: [0.2, 0.5, 0.2] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              )}
            </motion.div>
          ))}
        </div>

        <div className="mt-12 relative group p-8 md:p-10 rounded-[2rem] bg-white/[0.02] border border-white/[0.05] flex flex-col md:flex-row items-center justify-between gap-8 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-evalion-danger/[0.02] to-transparent"></div>
          
          <div className="relative z-10 flex items-center gap-8">
            <div className="w-14 h-14 rounded-2xl bg-evalion-danger/10 border border-evalion-danger/30 flex items-center justify-center shadow-2xl">
              <ShieldAlert className="text-evalion-danger" size={28} />
            </div>
            <div>
              <h4 className="font-bold tracking-[0.2em] text-sm uppercase text-white mb-2">Security Advisory: CVE-2024-001</h4>
              <p className="text-xs text-white/40 font-light tracking-wide">Kernel patch deployed across all nodes. No action required.</p>
            </div>
          </div>
          
          <button 
            onClick={() => navigate('/api')}
            className="relative z-10 px-8 py-4 bg-transparent border border-white/10 text-white font-mono text-[10px] tracking-[0.3em] uppercase rounded-full hover:bg-white/5 hover:border-white/30 transition-all duration-500"
          >
            View Audit Logs
          </button>
        </div>
      </div>
    </section>
  );
};