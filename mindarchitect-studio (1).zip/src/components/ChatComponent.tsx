import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send } from 'lucide-react';
import { useCollaboration } from '../context/CollaborationContext';
import { authService } from '../services/authService';

export const ChatComponent = () => {
  const [messages, setMessages] = useState<{ from: string; text: string }[]>([]);
  const [input, setInput] = useState('');
  const { socket, sendMessage } = useCollaboration();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const user = authService.getCurrentUser();

  useEffect(() => {
    if (!socket) return;

    const handleNewMessage = (data: { from: string; text: string }) => {
      setMessages(prev => [...prev, data]);
    };

    socket.on('new-message', handleNewMessage);

    return () => {
      socket.off('new-message', handleNewMessage);
    };
  }, [socket]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      sendMessage(input);
      setInput('');
    }
  };

  return (
    <div className="glass-card p-4 border border-white/5 flex flex-col h-full">
      <h3 className="font-bold tracking-wider mb-4 flex items-center gap-2 text-sm text-white">
        <MessageSquare className="text-evalion-teal" size={18} /> LIVE_CHAT
      </h3>
      <div className="flex-grow overflow-y-auto custom-scrollbar space-y-2 mb-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`text-xs font-mono ${msg.from === socket?.id ? 'text-evalion-teal text-right' : 'text-white'}`}>
            <span className="text-white/40">{msg.from.slice(0, 4)}: </span>
            {msg.text}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <form onSubmit={handleSend} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="TYPE_MESSAGE..."
          className="flex-grow bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-evalion-teal transition-all font-mono"
        />
        <button type="submit" className="p-2 bg-evalion-teal/10 border border-evalion-teal/30 rounded-lg text-evalion-teal hover:bg-evalion-teal/20 transition-all">
          <Send size={14} />
        </button>
      </form>
    </div>
  );
};
