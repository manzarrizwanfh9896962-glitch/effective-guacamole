import React from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, MapPin, Phone, Send } from 'lucide-react';

export const Contact = () => {
  return (
    <section className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24">
          <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-60">
            [ SECURE_COMMS_CHANNEL ]
          </h3>
          <h2 className="text-4xl md:text-7xl font-bold tracking-tighter text-white mb-8 leading-none">
            <span className="font-serif italic font-light text-evalion-textDim/50 block text-2xl md:text-3xl mb-2">Initiate protocol to</span>
            CONNECT WITH US
          </h2>
          <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-evalion-teal to-transparent mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Left Panel */}
          <div className="p-12 rounded-[3rem] bg-white/[0.02] border border-white/[0.05] relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-white/[0.02] to-transparent"></div>
            <h3 className="text-white font-mono text-[10px] tracking-[0.4em] mb-12 uppercase opacity-40">Direct_Uplink</h3>
            
            <div className="space-y-10 relative z-10">
              <div className="flex items-start gap-6 group/item">
                <div className="w-12 h-12 rounded-2xl bg-evalion-teal/10 border border-evalion-teal/20 flex items-center justify-center text-evalion-teal group-hover/item:scale-110 transition-transform duration-500">
                  <Phone size={20} />
                </div>
                <div>
                  <div className="text-[9px] font-mono text-white/30 uppercase mb-2 tracking-widest">Secure Line (PK)</div>
                  <div className="text-white font-bold tracking-wider text-lg">+92 302 8808488</div>
                </div>
              </div>

              <div className="flex items-start gap-6 group/item">
                <div className="w-12 h-12 rounded-2xl bg-evalion-purple/10 border border-evalion-purple/20 flex items-center justify-center text-evalion-purple group-hover/item:scale-110 transition-transform duration-500">
                  <Mail size={20} />
                </div>
                <div>
                  <div className="text-[9px] font-mono text-white/30 uppercase mb-2 tracking-widest">Official Query Stream</div>
                  <div className="text-white font-bold tracking-wider text-lg">hussnaintechofficial@gmail.com</div>
                </div>
              </div>

              <div className="flex items-start gap-6 group/item">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-white/40 group-hover/item:scale-110 transition-transform duration-500">
                  <MapPin size={20} />
                </div>
                <div>
                  <div className="text-[9px] font-mono text-white/30 uppercase mb-2 tracking-widest">Operational Base</div>
                  <div className="text-white font-bold tracking-wider text-lg">Daska, Sialkot</div>
                  <div className="text-white/40 text-xs font-light mt-1 tracking-wide">Punjab, Pakistan</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Panel */}
          <div className="p-12 rounded-[3rem] bg-white/[0.02] border border-evalion-teal/30 relative overflow-hidden group shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-evalion-teal/[0.03] to-transparent"></div>
            <h3 className="text-white font-mono text-[10px] tracking-[0.4em] mb-12 uppercase flex items-center gap-3">
              <MessageSquare size={16} className="text-evalion-teal" /> Transmission_Form
            </h3>
            
            <form className="space-y-8 relative z-10">
              <div className="space-y-3">
                <label className="block text-[9px] font-mono text-white/30 tracking-[0.3em] uppercase">Identity</label>
                <input type="text" className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm focus:outline-none focus:border-evalion-teal/50 transition-all duration-500 text-white placeholder:text-white/10" placeholder="NAME / ORG" />
              </div>
              
              <div className="space-y-3">
                <label className="block text-[9px] font-mono text-white/30 tracking-[0.3em] uppercase">Payload</label>
                <textarea className="w-full bg-white/[0.03] border border-white/10 rounded-2xl px-6 py-4 text-sm h-32 resize-none focus:outline-none focus:border-evalion-teal/50 transition-all duration-500 text-white placeholder:text-white/10" placeholder="ENTER MESSAGE..."></textarea>
              </div>
              
              <button type="button" className="group/btn relative w-full py-5 bg-evalion-teal text-black font-bold text-[10px] tracking-[0.4em] uppercase rounded-full hover:bg-evalion-teal/90 transition-all duration-500 shadow-2xl">
                <span className="relative z-10 flex items-center justify-center gap-3">
                  Send Encrypted Packet <Send size={16} className="group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
                </span>
                <div className="absolute inset-0 bg-evalion-teal rounded-full blur-xl opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
