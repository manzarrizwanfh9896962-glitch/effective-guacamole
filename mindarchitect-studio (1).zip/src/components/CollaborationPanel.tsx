import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, Eye, MessageSquare, Shield, Terminal, Activity, Zap } from 'lucide-react';

interface Observer {
  id: string;
  name: string;
  status: 'WATCHING' | 'ANALYZING' | 'INTERACTING';
}

export const CollaborationPanel = () => {
  const [observers, setObservers] = useState<Observer[]>([
    { id: '1', name: 'OPERATIVE_01', status: 'WATCHING' },
    { id: '2', name: 'LEAD_ARCHITECT', status: 'ANALYZING' }
  ]);
  const [messages, setMessages] = useState<{ from: string, text: string }[]>([
    { from: 'OPERATIVE_01', text: 'Candidate exhibits high neural stability.' },
    { from: 'LEAD_ARCHITECT', text: 'Focus on distributed systems depth.' }
  ]);
  const [newMessage, setNewMessage] = useState('');

  const sendMessage = () => {
    if (!newMessage.trim()) return;
    setMessages(prev => [...prev, { from: 'YOU (OBSERVER)', text: newMessage }]);
    setNewMessage('');
  };

  return (
    <div className="glass-panel rounded-2xl border-white/5 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-white/5 bg-white/[0.02] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users size={16} className="text-evalion-purple" />
          <h3 className="text-[10px] font-bold tracking-[0.3em] text-white uppercase">OPERATIVE_OBSERVERS</h3>
        </div>
        <div className="flex items-center gap-2 px-2 py-0.5 rounded bg-evalion-purple/10 border border-evalion-purple/30">
          <span className="w-1.5 h-1.5 rounded-full bg-evalion-purple animate-pulse"></span>
          <span className="text-[8px] text-evalion-purple font-bold">{observers.length} ACTIVE</span>
        </div>
      </div>

      {/* Observer List */}
      <div className="p-4 border-b border-white/5 space-y-3">
        {observers.map(obs => (
          <div key={obs.id} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-white/5 border border-white/10 flex items-center justify-center">
                <Eye size={12} className="text-evalion-textDim" />
              </div>
              <span className="text-[9px] font-mono text-white">{obs.name}</span>
            </div>
            <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded ${
              obs.status === 'ANALYZING' ? 'bg-evalion-teal/10 text-evalion-teal border border-evalion-teal/20' : 'bg-white/5 text-evalion-textDim border border-white/10'
            }`}>
              {obs.status}
            </span>
          </div>
        ))}
      </div>

      {/* Internal Comms */}
      <div className="flex-grow p-4 overflow-y-auto space-y-4 custom-scrollbar">
        <div className="flex items-center gap-2 mb-2">
          <MessageSquare size={12} className="text-evalion-teal" />
          <span className="text-[8px] font-bold tracking-widest text-evalion-teal uppercase">INTERNAL_COMMS</span>
        </div>
        {messages.map((msg, idx) => (
          <div key={idx} className="space-y-1">
            <div className="flex justify-between text-[8px] font-mono text-evalion-textDim">
              <span>{msg.from}</span>
              <span>12:42:0{idx}</span>
            </div>
            <p className="text-[9px] text-white/80 leading-relaxed bg-white/5 p-2 rounded-lg border border-white/5">
              {msg.text}
            </p>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 border-t border-white/5 bg-black/20">
        <div className="relative">
          <input 
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            placeholder="INTERNAL_NOTE..."
            className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-[9px] focus:outline-none focus:border-evalion-purple transition-all pr-10"
          />
          <button 
            onClick={sendMessage}
            className="absolute right-1 top-1 bottom-1 px-2 text-evalion-purple hover:text-white transition-colors"
          >
            <Zap size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};
