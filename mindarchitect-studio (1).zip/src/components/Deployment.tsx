import React from 'react';
import { motion } from 'framer-motion';
import { Cloud, Server, CheckCircle2, ArrowRight } from 'lucide-react';

export const Deployment = () => {
  return (
    <section className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-24">
          <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-60">
            [ DEPLOYMENT_MODELS ]
          </h3>
          <h2 className="text-5xl md:text-8xl font-bold tracking-tighter mb-10 leading-none">
            <span className="font-serif italic font-light text-evalion-textDim/50 block text-3xl md:text-4xl mb-2">Flexible infrastructure for</span>
            MODERN HIRING
          </h2>
          <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-evalion-teal to-transparent mx-auto mb-10"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group relative p-12 rounded-[3rem] bg-white/[0.02] border border-white/[0.05] hover:border-evalion-teal/30 transition-all duration-700 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-evalion-teal/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            
            <div className="flex items-center gap-6 mb-10">
              <div className="w-16 h-16 rounded-2xl bg-evalion-teal/10 border border-evalion-teal/30 flex items-center justify-center shadow-2xl">
                <Cloud className="text-evalion-teal" size={32} />
              </div>
              <h3 className="text-2xl font-bold tracking-wider text-white">Cloud Instance</h3>
            </div>
            
            <p className="text-evalion-textDim text-sm font-light leading-relaxed mb-10 h-20">
              Get started in minutes with our secure, multi-tenant cloud infrastructure. Fully managed and auto-scaling.
            </p>
            
            <ul className="space-y-5 mb-12">
              {[
                "99.99% Uptime SLA",
                "Instant Updates",
                "Global Low-Latency Network"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-4 text-xs font-light text-white/70">
                  <div className="w-1.5 h-1.5 rounded-full bg-evalion-teal"></div>
                  {item}
                </li>
              ))}
            </ul>
            
            <button className="group/btn relative w-full py-5 bg-white text-black font-bold text-[10px] tracking-[0.4em] uppercase rounded-full hover:bg-evalion-teal transition-all duration-500 shadow-2xl">
              <span className="relative z-10 flex items-center justify-center gap-3">
                Get Started <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-evalion-teal rounded-full blur-xl opacity-0 group-hover:opacity-40 transition-opacity duration-500"></div>
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="group relative p-12 rounded-[3rem] bg-white/[0.02] border border-white/[0.05] hover:border-evalion-purple/30 transition-all duration-700 overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-evalion-purple/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            
            <div className="flex items-center gap-6 mb-10">
              <div className="w-16 h-16 rounded-2xl bg-evalion-purple/10 border border-evalion-purple/30 flex items-center justify-center shadow-2xl">
                <Server className="text-evalion-purple" size={32} />
              </div>
              <h3 className="text-2xl font-bold tracking-wider text-white">Enterprise VPC</h3>
            </div>
            
            <p className="text-evalion-textDim text-sm font-light leading-relaxed mb-10 h-20">
              Deploy within your own Virtual Private Cloud or on-premise servers for maximum data control and compliance.
            </p>
            
            <ul className="space-y-5 mb-12">
              {[
                "Data Sovereignty",
                "SSO & Custom Integrations",
                "Dedicated Support & Onboarding"
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-4 text-xs font-light text-white/70">
                  <div className="w-1.5 h-1.5 rounded-full bg-evalion-purple"></div>
                  {item}
                </li>
              ))}
            </ul>
            
            <button className="group/btn relative w-full py-5 bg-transparent border border-white/10 text-white font-bold text-[10px] tracking-[0.4em] uppercase rounded-full hover:border-evalion-purple transition-all duration-500">
              <span className="relative z-10 flex items-center justify-center gap-3">
                Contact Sales <ArrowRight size={18} className="group-hover/btn:translate-x-1 transition-transform" />
              </span>
              <div className="absolute inset-0 bg-evalion-purple rounded-full blur-xl opacity-0 group-hover:opacity-20 transition-opacity duration-500"></div>
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};