import React, { useEffect, useState } from 'react';
import { motion, useMotionValue, useTransform, useSpring, AnimatePresence } from 'framer-motion';
import { Terminal, Info, Cpu } from 'lucide-react';
import { FeatureCards } from './FeatureCards';
import { Logo } from './Logo';

export const Hero = ({ onDeploy, onSimulate }: { onDeploy: () => void, onSimulate: () => void }) => {
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springConfig = { damping: 25, stiffness: 150 };
  const x = useSpring(mouseX, springConfig);
  const y = useSpring(mouseY, springConfig);

  // Parallax transforms for different layers - more subtle
  const layer1X = useTransform(x, [-0.5, 0.5], ['-10px', '10px']);
  const layer1Y = useTransform(y, [-0.5, 0.5], ['-10px', '10px']);
  
  const layer2X = useTransform(x, [-0.5, 0.5], ['10px', '-10px']);
  const layer2Y = useTransform(y, [-0.5, 0.5], ['10px', '-10px']);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      mouseX.set((clientX / innerWidth) - 0.5);
      mouseY.set((clientY / innerHeight) - 0.5);
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center pt-32 pb-20 overflow-hidden bg-black">
      {/* Simplified Background */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,240,255,0.03)_0%,transparent_70%)]"></div>
      
      {/* Subtle Grid */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none" 
           style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)', backgroundSize: '100px 100px' }}>
      </div>

      <div className="max-w-6xl mx-auto px-6 relative z-10 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-evalion-teal/30 bg-evalion-teal/10 text-evalion-teal text-[10px] font-mono mb-12 tracking-[0.2em]"
        >
          <span className="w-2 h-2 rounded-full bg-evalion-teal animate-pulse-fast"></span>
          NEURAL_OS_KERNEL: V1.0.24_STABLE
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-6xl md:text-8xl font-bold tracking-tight mb-12 leading-[1.1] text-center"
        >
          <span className="text-white">Hire with</span> <br />
          <span className="text-white">
            Mind<span className="text-evalion-teal">Architect</span> <span className="text-evalion-purple">Studio</span>
          </span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative max-w-2xl mb-16 text-left mx-auto flex"
        >
          <div className="w-1 bg-evalion-teal rounded-full mr-6 shrink-0"></div>
          <p className="text-lg md:text-xl text-evalion-textDim font-mono leading-relaxed">
            Scale technical recruitment with Zero-Trust<br />
            autonomy. Our AI agents verify depth, logic,<br />
            and architectural reasoning in real-time.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <div className="relative group">
            <button 
              onClick={onDeploy}
              className="px-8 py-4 bg-evalion-teal text-black font-bold text-xs font-mono tracking-widest uppercase rounded-xl hover:bg-evalion-teal/90 transition-all duration-500 shadow-[0_0_20px_rgba(0,240,255,0.4)] flex items-center gap-3"
            >
              START_AUTONOMOUS_INTERVIEW <span className="text-lg leading-none">→</span>
            </button>
          </div>
          
          <button 
            onClick={onSimulate}
            className="px-8 py-4 border border-white/10 text-white font-mono text-xs tracking-widest uppercase rounded-xl hover:bg-white/5 hover:border-white/30 transition-all duration-500 flex items-center gap-3"
          >
            START_PRACTICE_LAB <Cpu size={16} />
          </button>
        </motion.div>

        {/* Feature Cards Section */}
        <FeatureCards />
      </div>
    </section>
  );
};
