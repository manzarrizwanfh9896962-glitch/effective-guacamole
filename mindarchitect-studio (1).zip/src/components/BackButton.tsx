import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export const BackButton = () => {
  const navigate = useNavigate();

  return (
    <button 
      onClick={() => navigate(-1)}
      className="fixed top-24 left-6 z-40 flex items-center gap-2 text-xs font-mono text-evalion-textDim hover:text-evalion-teal transition-colors bg-evalion-bg/50 backdrop-blur-md border border-evalion-teal/20 px-4 py-2 rounded-full group"
    >
      <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
      RETURN_TO_PREVIOUS_NODE
    </button>
  );
};
