import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Sliders, ShieldAlert, Brain, MessageSquare, Zap, Save, CheckCircle2 } from 'lucide-react';

interface PersonaConfig {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  parameters: {
    id: string;
    label: string;
    value: number;
    min: number;
    max: number;
    description: string;
  }[];
}

const DEFAULT_PERSONAS: PersonaConfig[] = [
  {
    id: 'interrogator',
    name: 'INTERROGATOR',
    description: 'High-pressure tactical assessment. Focuses on breaking down complex logic and identifying weaknesses.',
    icon: <ShieldAlert size={20} />,
    color: 'evalion-danger',
    parameters: [
      { id: 'assertiveness', label: 'ASSERTIVENESS', value: 85, min: 0, max: 100, description: 'How aggressively the AI challenges the candidate\'s answers.' },
      { id: 'technicalDepth', label: 'TECHNICAL_DEPTH', value: 95, min: 0, max: 100, description: 'The complexity and specificity of follow-up questions.' },
      { id: 'patience', label: 'PATIENCE_THRESHOLD', value: 20, min: 0, max: 100, description: 'Tolerance for hesitation or incomplete answers before interrupting.' }
    ]
  },
  {
    id: 'analyst',
    name: 'ANALYST',
    description: 'Objective and methodical. Focuses on architectural patterns, trade-offs, and system design principles.',
    icon: <Brain size={20} />,
    color: 'evalion-teal',
    parameters: [
      { id: 'analyticalRigor', label: 'ANALYTICAL_RIGOR', value: 90, min: 0, max: 100, description: 'Demand for precise, data-driven explanations.' },
      { id: 'broadness', label: 'SCOPE_BROADNESS', value: 75, min: 0, max: 100, description: 'Tendency to ask about system-wide implications vs. isolated components.' },
      { id: 'neutrality', label: 'NEUTRALITY', value: 95, min: 0, max: 100, description: 'Lack of emotional feedback or leading hints.' }
    ]
  },
  {
    id: 'mentor',
    name: 'MENTOR',
    description: 'Collaborative and guiding. Focuses on problem-solving approach and potential for growth.',
    icon: <MessageSquare size={20} />,
    color: 'evalion-purple',
    parameters: [
      { id: 'encouragement', label: 'ENCOURAGEMENT_LEVEL', value: 80, min: 0, max: 100, description: 'Frequency of positive reinforcement and validation.' },
      { id: 'hinting', label: 'HINT_PROPENSITY', value: 60, min: 0, max: 100, description: 'Likelihood of providing subtle clues when the candidate is stuck.' },
      { id: 'adaptability', label: 'ADAPTABILITY', value: 85, min: 0, max: 100, description: 'Willingness to pivot the question based on the candidate\'s strengths.' }
    ]
  }
];

export const PersonaSettingsPanel = () => {
  const [personas, setPersonas] = useState<PersonaConfig[]>(DEFAULT_PERSONAS);
  const [activePersonaId, setActivePersonaId] = useState<string>('interrogator');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const activePersona = personas.find(p => p.id === activePersonaId)!;

  const handleParameterChange = (parameterId: string, newValue: number) => {
    setPersonas(prev => prev.map(persona => {
      if (persona.id === activePersonaId) {
        return {
          ...persona,
          parameters: persona.parameters.map(param => 
            param.id === parameterId ? { ...param, value: newValue } : param
          )
        };
      }
      return persona;
    }));
  };

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call to save settings
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }, 1500);
  };

  return (
    <div className="h-full flex flex-col glass-panel rounded-xl border border-white/5 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-white/5 bg-white/[0.02] flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Sliders size={20} className="text-evalion-teal" />
          <h2 className="text-lg font-bold tracking-widest text-white uppercase">PROMPT_PERSONA_CONFIG</h2>
        </div>
        <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-evalion-teal/10 border border-evalion-teal/30">
          <span className="w-1.5 h-1.5 rounded-full bg-evalion-teal animate-pulse"></span>
          <span className="text-[9px] text-evalion-teal font-bold tracking-widest">KERNEL_ACCESS_GRANTED</span>
        </div>
      </div>

      <div className="flex flex-grow overflow-hidden">
        {/* Sidebar: Persona Selection */}
        <div className="w-64 border-r border-white/5 bg-black/20 p-4 space-y-2 overflow-y-auto">
          <div className="text-[10px] font-mono text-evalion-textDim uppercase tracking-widest mb-4 px-2">AVAILABLE_PERSONAS</div>
          {personas.map(persona => (
            <button
              key={persona.id}
              onClick={() => setActivePersonaId(persona.id)}
              className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all text-left ${
                activePersonaId === persona.id 
                  ? `bg-${persona.color}/10 border border-${persona.color}/30 text-white` 
                  : 'hover:bg-white/5 text-evalion-textDim border border-transparent'
              }`}
            >
              <div className={`text-${persona.color}`}>
                {persona.icon}
              </div>
              <span className="text-xs font-bold tracking-widest uppercase">{persona.name}</span>
            </button>
          ))}
        </div>

        {/* Main Content: Parameter Tuning */}
        <div className="flex-grow p-8 overflow-y-auto custom-scrollbar relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePersona.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="max-w-2xl space-y-8"
            >
              {/* Persona Header */}
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg bg-${activePersona.color}/10 text-${activePersona.color}`}>
                    {activePersona.icon}
                  </div>
                  <h3 className={`text-2xl font-bold tracking-widest text-${activePersona.color} uppercase`}>
                    {activePersona.name}
                  </h3>
                </div>
                <p className="text-sm text-evalion-textDim leading-relaxed">
                  {activePersona.description}
                </p>
              </div>

              {/* Parameters List */}
              <div className="space-y-8 pt-4">
                {activePersona.parameters.map(param => (
                  <div key={param.id} className="space-y-4">
                    <div className="flex justify-between items-end">
                      <div className="space-y-1">
                        <label className="text-xs font-bold tracking-widest text-white uppercase flex items-center gap-2">
                          <Zap size={12} className={`text-${activePersona.color}`} />
                          {param.label}
                        </label>
                        <p className="text-[10px] text-evalion-textDim max-w-md">{param.description}</p>
                      </div>
                      <div className={`text-xl font-mono font-bold text-${activePersona.color}`}>
                        {param.value}<span className="text-xs text-evalion-textDim">/100</span>
                      </div>
                    </div>
                    
                    {/* Custom Slider */}
                    <div className="relative h-2 bg-white/5 rounded-full overflow-hidden group">
                      <div 
                        className={`absolute top-0 left-0 h-full bg-${activePersona.color} transition-all duration-150 ease-out`}
                        style={{ width: `${param.value}%` }}
                      ></div>
                      <input 
                        type="range" 
                        min={param.min} 
                        max={param.max} 
                        value={param.value}
                        onChange={(e) => handleParameterChange(param.id, parseInt(e.target.value))}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Save Action */}
          <div className="absolute bottom-8 right-8">
            <button
              onClick={handleSave}
              disabled={isSaving || saveSuccess}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-bold text-xs tracking-widest uppercase transition-all ${
                saveSuccess 
                  ? 'bg-evalion-success/20 text-evalion-success border border-evalion-success/40'
                  : 'bg-white text-black hover:bg-gray-200'
              }`}
            >
              {isSaving ? (
                <><Zap size={16} className="animate-pulse" /> SYNCING_TO_KERNEL...</>
              ) : saveSuccess ? (
                <><CheckCircle2 size={16} /> CONFIG_SAVED</>
              ) : (
                <><Save size={16} /> SAVE_CONFIGURATION</>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
