import React from 'react';
import { motion } from 'framer-motion';
import { Briefcase, Code, BarChart, ArrowRight, CheckCircle2 } from 'lucide-react';

const workflows = [
  {
    icon: <Briefcase className="text-evalion-teal" size={24} />,
    title: "TALENT ACQUISITION",
    subtitle: "FOR THE TECHNICAL RECRUITER",
    desc: "Automate top-of-funnel screening and identify high-potential candidates with 98% accuracy, reducing time-to-hire by over 60%.",
    features: ["AI-Powered Resume Parsing", "Automated Technical Screens", "Candidate Pipeline Analytics", "Bias Reduction Reporting"],
    color: "teal"
  },
  {
    icon: <Code className="text-evalion-purple" size={24} />,
    title: "ENGINEERING LEADS",
    subtitle: "FOR THE HIRING MANAGER",
    desc: "Go beyond simple pass/fail. Deeply assess code quality, system design philosophy, and problem-solving abilities with our sandboxed environment.",
    features: ["Live Code Execution Analysis", "System Design Whiteboarding", "Algorithmic Complexity Scoring", "Plagiarism & Proctoring Alerts"],
    color: "purple"
  },
  {
    icon: <BarChart className="text-evalion-text" size={24} />,
    title: "EXECUTIVE OVERSIGHT",
    subtitle: "FOR THE CTO / VP ENG",
    desc: "Gain a strategic overview of your organization's technical capabilities, identify skill gaps, and make data-driven decisions on talent strategy.",
    features: ["Team Skill-Gap Analysis", "Hiring Velocity Metrics", "Interviewer Calibration Reports", "Enterprise SSO & Audit Logs"],
    color: "text"
  }
];

export const Workflows = () => {
  return (
    <section className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-24">
          <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-60">
            [ ORGANIZATIONAL_WORKFLOWS ]
          </h3>
          <h2 className="text-5xl md:text-8xl font-bold tracking-tighter mb-10 leading-none">
            <span className="font-serif italic font-light text-evalion-textDim/50 block text-3xl md:text-4xl mb-2">Tailored solutions for</span>
            EVERY ROLE
          </h2>
          <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-evalion-teal to-transparent mx-auto mb-10"></div>
          <p className="max-w-2xl mx-auto text-evalion-textDim font-light text-base leading-relaxed tracking-wide">
            MindArchitect Studio provides tailored workflows and data insights to empower every member of your hiring team, from sourcing to final decision.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {workflows.map((wf, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2 }}
              className="group relative p-10 rounded-[2.5rem] bg-white/[0.02] border border-white/[0.05] hover:border-evalion-teal/30 transition-all duration-700 flex flex-col overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-evalion-teal/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
              
              <div className="flex items-center gap-6 mb-10">
                <div className="p-5 rounded-2xl bg-black border border-white/10 group-hover:border-evalion-teal/40 transition-all duration-700 shadow-2xl">
                  {wf.icon}
                </div>
                <div>
                  <h3 className="text-xl font-bold tracking-wider text-white">{wf.title}</h3>
                  <p className="text-[9px] font-mono text-evalion-teal/50 uppercase tracking-[0.3em]">{wf.subtitle}</p>
                </div>
              </div>
              
              <p className="text-evalion-textDim text-sm font-light leading-relaxed mb-10 flex-grow">
                {wf.desc}
              </p>

              <ul className="space-y-4 mb-10">
                {wf.features.map((feat, i) => (
                  <li key={i} className="flex items-center gap-3 text-[11px] font-light text-white/70">
                    <div className="w-1.5 h-1.5 rounded-full bg-evalion-teal/50"></div>
                    {feat}
                  </li>
                ))}
              </ul>

              <button className="group/btn relative py-4 border-t border-white/5 text-[10px] font-mono tracking-[0.4em] uppercase text-white/40 hover:text-evalion-teal transition-all duration-500 flex items-center justify-center gap-3">
                View Dashboard <ArrowRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
              </button>
            </motion.div>
          ))}
        </div>

        <div className="mt-24 text-center">
          <div className="inline-flex items-center gap-6 px-8 py-4 rounded-full border border-white/5 bg-white/[0.02] backdrop-blur-xl text-[10px] font-mono text-white/40 uppercase tracking-[0.2em]">
            <span className="px-3 py-1 bg-evalion-teal/10 text-evalion-teal border border-evalion-teal/30 rounded-full text-[9px] font-bold">API_V2</span>
            Scale your recruitment OS with our advanced Enterprise API.
            <a href="#" className="text-evalion-teal hover:text-white transition-colors ml-2 underline underline-offset-4">Read Documentation</a>
          </div>
        </div>
      </div>
    </section>
  );
};