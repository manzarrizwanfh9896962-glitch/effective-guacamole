import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { Terminal, Shield, Cpu, Activity, LogOut, Users, Settings, BarChart3, Fingerprint, CheckCircle2, Brain, Zap, HeartPulse, MessageSquare, Layers, Info, HelpCircle, Search, ArrowRight, Video, Palette, Monitor, Sun, Moon, ZapOff, CreditCard } from 'lucide-react';
import { Logo } from './Logo';
import { BiometricEnrollment } from './BiometricEnrollment';
import { VideoCall } from './VideoCall';
import { LoadingSpinner } from './LoadingSpinner';

import { TaskList } from './TaskList';
import { ChatComponent } from './ChatComponent';
import { PassportManagement } from '../pages/PassportManagement';

import { authService } from '../services/authService';
import apiClient from '../services/authService';
import { useTheme } from '../context/ThemeContext';
import { useCollaboration } from '../context/CollaborationContext';
import { useAutoScroll } from '../hooks/useAutoScroll';

export const Dashboard = ({ onLogout, onShowTutorial }: { onLogout: () => void, onShowTutorial?: () => void }) => {
  const [nodes, setNodes] = useState<any[]>([]);
  const [isNodesLoading, setIsNodesLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'autonomous' | 'candidates' | 'passport'>('autonomous');
  const [isBiometricModalOpen, setIsBiometricModalOpen] = useState(false);
  const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
  const [isThemeMenuOpen, setIsThemeMenuOpen] = useState(false);
  const [isVideoCallOpen, setIsVideoCallOpen] = useState(false);
  const [dbConnected, setDbConnected] = useState(false);
  const [sessionId] = useState(`SESS_8842_AX_SECURE`);
  const [activeRole] = useState('SENIOR_ARCHITECT_EVALUATOR');
  const [candidateProcessingRate, setCandidateProcessingRate] = useState<number | null>(null);
  const [aiNodeHealth, setAiNodeHealth] = useState<number | null>(null);
  const [systemUptime, setSystemUptime] = useState<string | null>(null);
  const [aiStream, setAiStream] = useState<any[]>([
    { time: '05:23:27', status: 'INITIALIZING_NEURAL_UPLINK... SUCCESS', type: 'system' },
    { time: '05:23:28', status: 'ESTABLISHING_ZERO_TRUST_ENVIRONMENT... VERIFIED', type: 'system' },
    { time: '05:23:30', status: '"Explain the trade-offs between eventual consistency and strong consistency in a globally distributed database system."', type: 'ai', label: 'AI_INTERROGATOR' },
    { time: '05:23:35', status: 'CANDIDATE_RESPONSE_DETECTED... TRANScribing...', type: 'system' },
    { time: '05:23:40', status: 'ANALYZING_ARCHITECTURAL_DEPTH...', type: 'system', pulse: true },
  ]);
  
  const { theme, setTheme } = useTheme();
  const { users, cursors, sendMessage, updateCursor } = useCollaboration();
  const dashboardRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const aiStreamRef = useRef<HTMLDivElement>(null);

  // Apply auto-scroll to AI stream
  useAutoScroll(aiStreamRef, aiStream);
  
  const { scrollYProgress } = useScroll({ container: contentRef });
  const backgroundY = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const gridY = useTransform(scrollYProgress, [0, 1], [0, 100]);
  const dotsY = useTransform(scrollYProgress, [0, 1], [0, 300]);

  // Simulate AI stream updates
  useEffect(() => {
    const interval = setInterval(() => {
      if (activeTab === 'autonomous') {
        const newLog = {
          time: new Date().toLocaleTimeString([], { hour12: false }),
          status: `NEURAL_NODE_${Math.floor(Math.random() * 1000)}_HEARTBEAT... OK`,
          type: 'system'
        };
        setAiStream(prev => [...prev.slice(-49), newLog]);
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [activeTab]);

  // Candidate Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (dashboardRef.current) {
      const rect = dashboardRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      updateCursor(x, y);
    }
  };

  useEffect(() => {
    const fetchCandidates = async () => {
      setIsSearching(true);
      try {
        const response = await apiClient.get(`/candidates/search?q=${searchQuery}`);
        setSearchResults(response.data);
      } catch (error) {
        console.error('Search failed:', error);
      } finally {
        setIsSearching(false);
      }
    };

    const timeoutId = setTimeout(() => {
      if (activeTab === 'candidates') {
        fetchCandidates();
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchQuery, activeTab]);

  useEffect(() => {
    // Fetch initial nodes data from our new backend endpoint
    const fetchNodes = async () => {
      setIsNodesLoading(true);
      try {
        const response = await apiClient.get('/nodes');
        setNodes(response.data || []);
        
        // Check health for DB connection status
        const healthRes = await apiClient.get('/health');
        const healthData = healthRes.data;
        setDbConnected(healthData.db_connected);
        setCandidateProcessingRate(healthData.candidate_processing_rate);
        setAiNodeHealth(healthData.ai_node_health);
        setSystemUptime(healthData.system_uptime);
      } catch (error) {
        console.error('Error fetching nodes:', error);
      } finally {
        setIsNodesLoading(false);
      }
    };

    fetchNodes();

    // In a real production app, we would use WebSockets for real-time updates.
    // For now, we'll use a simple polling mechanism as a fallback.
    const interval = setInterval(fetchNodes, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, []);


  return (
    <div 
      ref={dashboardRef}
      onMouseMove={handleMouseMove}
      className="min-h-screen bg-evalion-bg text-evalion-text flex relative overflow-hidden"
    >
      <motion.div 
        className="absolute inset-0 z-0 opacity-20 pointer-events-none"
        style={{ y: backgroundY }}
      >
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,_var(--teal-neon),_transparent_70%)]" />
      </motion.div>
      <motion.div 
        className="absolute inset-0 z-0 opacity-[0.03] pointer-events-none"
        style={{ y: gridY }}
      >
        <div className="absolute inset-0" style={{ backgroundImage: 'linear-gradient(var(--teal-neon) 1px, transparent 1px), linear-gradient(90deg, var(--teal-neon) 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
      </motion.div>
      <motion.div 
        className="absolute inset-0 z-0 opacity-[0.1] pointer-events-none"
        style={{ y: dotsY }}
      >
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, var(--teal-neon) 1px, transparent 1px)', backgroundSize: '100px 100px' }} />
      </motion.div>
      {/* Sidebar */}
      <aside className="w-64 glass-sidebar border-r border-white/5 flex flex-col z-20 hidden lg:flex">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10">
            <Logo size={32} />
            <span className="text-xl font-bold tracking-tighter text-white">MIND<span className="text-evalion-teal">ARCH</span></span>
          </div>

          <nav className="space-y-2">
            {[
              { id: 'autonomous', label: 'AUTONOMOUS', icon: Activity },
              { id: 'candidates', label: 'CANDIDATES', icon: Users },
              { id: 'passport', label: 'PASSPORT', icon: CreditCard },
              { id: 'analytics', label: 'ANALYTICS', icon: BarChart3 },
              { id: 'settings', label: 'SETTINGS', icon: Settings },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all group ${activeTab === item.id ? 'bg-evalion-teal/10 text-evalion-teal border border-evalion-teal/20 shadow-[0_0_15px_rgba(0,240,255,0.1)]' : 'text-evalion-textDim hover:text-white hover:bg-white/5'}`}
              >
                <item.icon size={18} className={activeTab === item.id ? 'text-evalion-teal' : 'group-hover:text-white'} />
                <span className="text-[10px] font-bold tracking-widest uppercase">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-white/5">
          <div className="glass-card p-4 border border-white/5 mb-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-2 h-2 rounded-full bg-evalion-success animate-pulse" />
              <span className="text-[8px] font-mono text-evalion-success uppercase tracking-widest">System Stable</span>
            </div>
            <div className="text-[10px] text-evalion-textDim font-mono">
              UPTIME: {systemUptime || '---'}
            </div>
          </div>

          <button 
            onClick={() => setIsLogoutModalOpen(true)}
            className="w-full flex items-center gap-4 px-4 py-3 rounded-xl text-evalion-danger hover:bg-evalion-danger/5 transition-all group"
          >
            <LogOut size={18} />
            <span className="text-[10px] font-bold tracking-widest uppercase">Terminate</span>
          </button>
        </div>
      </aside>

      <div className="flex-grow flex flex-col h-screen overflow-hidden">
        {/* Top Navigation */}
        <nav className="h-16 border-b border-white/5 bg-black/20 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-50">
          <div className="flex items-center gap-4 lg:hidden">
            <Logo size={24} />
          </div>
          
          <div className="flex items-center gap-6 ml-auto">
            {/* Active Users Presence */}
            <div className="hidden md:flex items-center -space-x-2 mr-2">
              {users.slice(0, 3).map((user, idx) => (
                <div 
                  key={user.id} 
                  className="w-6 h-6 rounded-full bg-evalion-purple/20 border border-evalion-purple/40 flex items-center justify-center text-[8px] font-bold text-evalion-purple relative group"
                  title={user.name}
                >
                  {user.name.charAt(0)}
                  <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-black border border-white/10 rounded text-[8px] whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity z-[100]">
                    {user.name}
                  </div>
                </div>
              ))}
              {users.length > 3 && (
                <div className="w-6 h-6 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-[8px] font-bold text-white/50">
                  +{users.length - 3}
                </div>
              )}
            </div>

            {/* Database Connection Indicator */}
            <div className="flex items-center gap-2 px-3 py-1 bg-black/20 rounded-full border border-white/5">
              <div className={`w-2 h-2 rounded-full ${dbConnected ? 'bg-evalion-success shadow-[0_0_8px_rgba(0,255,157,0.5)]' : 'bg-evalion-danger shadow-[0_0_8px_rgba(255,68,68,0.5)]'}`}></div>
              <span className={`text-[9px] font-mono tracking-tighter ${dbConnected ? 'text-evalion-success' : 'text-evalion-danger'}`}>
                {dbConnected ? 'STABLE' : 'OFFLINE'}
              </span>
            </div>

            <div className="relative">
              <button 
                onClick={() => setIsThemeMenuOpen(!isThemeMenuOpen)}
                className="p-2 text-evalion-textDim hover:text-white transition-colors"
                title="Change Theme"
              >
                <Palette size={18} />
              </button>
              <AnimatePresence>
                {isThemeMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-48 glass-panel p-2 rounded-xl z-[100]"
                  >
                    <div className="text-[10px] font-bold text-white/40 px-3 py-2 uppercase tracking-widest">Select Theme</div>
                    {[
                      { id: 'cyberpunk', name: 'Cyberpunk', icon: Zap },
                      { id: 'matrix', name: 'Matrix', icon: Terminal },
                      { id: 'synthwave', name: 'Synthwave', icon: Moon },
                      { id: 'minimalist', name: 'Minimalist', icon: Sun }
                    ].map((t) => (
                      <button
                        key={t.id}
                        onClick={() => {
                          setTheme(t.id as any);
                          setIsThemeMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-mono transition-colors ${theme === t.id ? 'bg-evalion-teal/10 text-evalion-teal' : 'text-white/60 hover:bg-white/5 hover:text-white'}`}
                      >
                        <t.icon size={14} />
                        {t.name}
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button 
              onClick={() => setIsVideoCallOpen(true)}
              className="p-2 text-evalion-textDim hover:text-evalion-teal transition-colors"
              title="Start Video Call"
            >
              <Video size={18} />
            </button>

            <button 
              onClick={onShowTutorial}
              className="p-2 text-evalion-textDim hover:text-white transition-colors"
              title="Show Tutorial"
            >
              <HelpCircle size={18} />
            </button>

            <button 
              onClick={() => setIsBiometricModalOpen(true)}
              className="hidden lg:flex items-center gap-2 px-4 py-1.5 bg-evalion-teal/10 border border-evalion-teal text-evalion-teal text-[10px] font-bold tracking-widest uppercase rounded shadow-[0_0_15px_rgba(0,240,255,0.4)] animate-pulse hover:bg-evalion-teal/20 transition-all"
            >
              <Fingerprint size={14} />
              Secure
            </button>
          </div>
        </nav>

        {/* Main Content */}
        <div ref={contentRef} className="flex-grow p-8 max-w-7xl mx-auto w-full h-[calc(100vh-64px)] overflow-y-auto custom-scrollbar">
        <AnimatePresence mode="wait">
          {activeTab === 'autonomous' && (
            <motion.div 
              key="autonomous"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full"
            >
              {/* Left Column - System Status */}
              <div className="lg:col-span-3 space-y-6 h-full flex flex-col">
                <div className="glass-card p-6 border border-evalion-textDim/20 flex-1 overflow-y-auto custom-scrollbar min-h-0">
                  <h3 className="font-bold tracking-wider mb-6 flex items-center gap-2 text-sm">
                    <Cpu className="text-evalion-teal" size={18} /> KERNEL_NODES
                  </h3>
                  
                  <div className="space-y-4">
                    {isNodesLoading ? (
                      <LoadingSpinner />
                    ) : (
                      nodes.map((node, idx) => (
                        <motion.div 
                          key={node.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.1 }}
                          whileHover={{ scale: 1.05, backgroundColor: 'rgba(255, 255, 255, 0.08)', zIndex: 10 }}
                          className={`p-3 rounded-lg border transition-all cursor-pointer group relative overflow-hidden 
                            ${node.status === 'OPTIMAL' ? 'border-evalion-success/30 bg-evalion-success/10 shadow-[0_0_15px_rgba(0,255,157,0.1)]' : 'border-evalion-teal/30 bg-evalion-teal/10'}
                          `}
                        >
                          <div className="flex justify-between items-center mb-1.5">
                            <h4 className={`font-bold text-[10px] tracking-wide truncate pr-2 ${node.status === 'OPTIMAL' ? 'text-evalion-success' : 'text-evalion-teal'}`}>{node.name}</h4>
                            <span className="text-[8px] font-mono text-evalion-success bg-evalion-success/10 px-1.5 py-0.5 rounded border border-evalion-success/20">
                              {node.latency}
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <p className="text-[8px] font-mono text-evalion-textDim uppercase">{node.region}</p>
                            <div className={`w-2 h-2 rounded-full ${node.status === 'OPTIMAL' ? 'bg-evalion-success animate-pulse shadow-[0_0_8px_rgba(0,255,157,0.8)]' : 'bg-evalion-teal'}`}></div>
                          </div>
                          
                          {/* Hover Details */}
                          <div className="grid grid-rows-[0fr] group-hover:grid-rows-[1fr] opacity-0 group-hover:opacity-100 transition-all duration-300">
                            <div className="overflow-hidden">
                              <div className="pt-2 mt-2 border-t border-white/5 text-[8px] font-mono text-evalion-textDim space-y-1">
                                <div className="flex justify-between">
                                  <span>UPTIME:</span>
                                  <span className="text-white">99.9%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>LOAD:</span>
                                  <span className="text-white">42%</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))
                    )}
                  </div>
                </div>
                
                <div className="flex-1 min-h-0">
                  <TaskList />
                </div>
                <div className="flex-1 min-h-0">
                  <ChatComponent />
                </div>
              </div>

              {/* Center Column - Active Evaluation */}
              <div className="lg:col-span-6 space-y-6 h-full flex flex-col">
                <div className="glass-card p-8 border border-evalion-teal/30 relative overflow-hidden flex-grow flex flex-col">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-evalion-teal/5 rounded-bl-full blur-3xl"></div>
                  
                  <div className="flex justify-between items-start mb-8 relative z-10">
                    <div>
                      <div className="text-evalion-teal font-mono text-[10px] tracking-[0.3em] uppercase mb-2">ACTIVE_EVALUATION_STREAM</div>
                      <h2 className="text-2xl font-bold tracking-tight text-white uppercase">AUTONOMOUS_INTERVIEW_ENGINE</h2>
                    </div>
                    <div className="px-3 py-1 bg-evalion-teal/10 border border-evalion-teal/30 rounded text-[10px] font-bold text-evalion-teal animate-pulse">
                      LIVE_PROCESSING
                    </div>
                  </div>

                  <div 
                    ref={aiStreamRef}
                    className="flex-grow bg-black/40 rounded-xl border border-white/5 p-6 font-mono text-xs leading-relaxed text-evalion-textDim overflow-y-auto custom-scrollbar mb-6"
                  >
                    <div className="space-y-4">
                      {aiStream.map((log, idx) => (
                        <div key={idx} className="flex gap-4">
                          <span className="text-evalion-teal shrink-0">[{log.time}]</span>
                          {log.type === 'ai' ? (
                            <span className="text-white">
                              <span className="text-evalion-purple">{log.label}:</span> {log.status}
                            </span>
                          ) : (
                            <span className={log.pulse ? 'animate-pulse text-evalion-teal' : ''}>
                              {log.status}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button className="flex-grow py-3 bg-evalion-teal text-black font-bold text-[10px] tracking-widest uppercase rounded-lg hover:bg-evalion-teal/90 transition-all">
                      INTERVENE_IN_SESSION
                    </button>
                    <button className="px-6 py-3 border border-white/10 text-white font-bold text-[10px] tracking-widest uppercase rounded-lg hover:bg-white/5 transition-all">
                      VIEW_FULL_LOGS
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column - Real-time Metrics */}
              <div className="lg:col-span-3 space-y-6 h-full flex flex-col">
                <div className="glass-card p-6 border border-white/5 space-y-8">
                  <div>
                    <h4 className="text-[10px] font-bold tracking-widest text-white uppercase mb-4">NEURAL_STABILITY</h4>
                    <div className="h-24 flex items-end gap-1 px-2">
                      {[40, 70, 45, 90, 65, 80, 50, 85, 95, 75].map((h, i) => (
                        <motion.div 
                          key={i}
                          className="flex-grow bg-evalion-purple/40 rounded-t-sm"
                          initial={{ height: 0 }}
                          animate={{ height: `${h}%` }}
                          transition={{ delay: i * 0.05, repeat: Infinity, repeatType: 'reverse', duration: 1.5 }}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between text-[10px] font-mono">
                      <span className="text-evalion-textDim">COGNITIVE_LOAD</span>
                      <span className="text-evalion-teal">68%</span>
                    </div>
                    <div className="flex justify-between text-[10px] font-mono">
                      <span className="text-evalion-textDim">LOGIC_PRECISION</span>
                      <span className="text-evalion-success">92%</span>
                    </div>
                    <div className="flex justify-between text-[10px] font-mono">
                      <span className="text-evalion-textDim">STRESS_LEVEL</span>
                      <span className="text-evalion-danger">LOW</span>
                    </div>
                    
                    {candidateProcessingRate !== null && (
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-evalion-textDim">CANDIDATE_PROCESSING_RATE</span>
                        <span className="text-evalion-teal">{candidateProcessingRate} / MIN</span>
                      </div>
                    )}
                    {aiNodeHealth !== null && (
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-evalion-textDim">AI_NODE_HEALTH</span>
                        <span className="text-evalion-success">{aiNodeHealth}%</span>
                      </div>
                    )}
                    {systemUptime !== null && (
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-evalion-textDim">SYSTEM_UPTIME</span>
                        <span className="text-evalion-teal">{systemUptime}</span>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-white/5">
                    <div className="text-[10px] font-bold text-white uppercase mb-2">PREDICTIVE_SCORE</div>
                    <div className="text-4xl font-bold text-evalion-teal tracking-tighter">88.4</div>
                    <div className="text-[8px] font-mono text-evalion-textDim mt-1">CONFIDENCE_INTERVAL: 94.2%</div>
                  </div>
                </div>

                <div className="glass-card p-6 border border-white/5 flex-grow">
                  <h4 className="text-[10px] font-bold tracking-widest text-white uppercase mb-4">ACTIVE_CANDIDATE</h4>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-lg bg-evalion-purple/20 border border-evalion-purple/30 flex items-center justify-center">
                      <Users size={20} className="text-evalion-purple" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">CAND_8842_AX</div>
                      <div className="text-[8px] font-mono text-evalion-textDim">SENIOR_BACKEND_ARCHITECT</div>
                    </div>
                  </div>
                  <p className="text-[9px] font-mono text-evalion-textDim leading-relaxed">
                    Candidate is currently explaining distributed locking mechanisms. Logic precision is trending upward.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
          {activeTab === 'passport' && (
            <motion.div 
              key="passport"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="h-full"
            >
              <PassportManagement />
            </motion.div>
          )}
          {activeTab === 'candidates' && (
            <motion.div 
              key="candidates"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="h-full flex flex-col space-y-6"
            >
              {/* Search Bar */}
              <div className="glass-card p-6 border border-white/5 flex items-center gap-4">
                <div className="relative flex-grow">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-evalion-textDim">
                    <Search size={16} />
                  </div>
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="SEARCH_CANDIDATES_BY_NAME_OR_ID..."
                    className="w-full bg-black/30 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-sm text-white focus:outline-none focus:border-evalion-teal transition-all font-mono"
                  />
                </div>
                <div className="text-[10px] font-mono text-evalion-textDim uppercase tracking-widest">
                  {searchResults.length} RECORDS_FOUND
                </div>
              </div>

              {/* Results Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 overflow-y-auto custom-scrollbar pb-20">
                {isSearching ? (
                  <div className="col-span-full flex justify-center py-20">
                    <LoadingSpinner />
                  </div>
                ) : searchResults.length > 0 ? (
                  searchResults.map((candidate) => (
                    <motion.div
                      key={candidate.id}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      whileHover={{ scale: 1.02 }}
                      onClick={() => window.location.href = `/candidates/${candidate.id}`}
                      className="glass-card p-6 border border-white/5 cursor-pointer hover:border-evalion-teal/50 transition-all group relative overflow-hidden"
                    >
                      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                        <Users size={80} />
                      </div>
                      
                      <div className="flex justify-between items-start mb-4 relative z-10">
                        <div>
                          <h3 className="text-lg font-bold text-white group-hover:text-evalion-teal transition-colors">{candidate.name}</h3>
                          <p className="text-[10px] text-evalion-textDim font-mono mt-1">{candidate.role}</p>
                        </div>
                        <span className={`px-2 py-1 rounded text-[8px] font-bold tracking-widest border ${
                          candidate.status === 'COMPLETED' ? 'bg-evalion-success/10 text-evalion-success border-evalion-success/30' : 
                          candidate.status === 'IN_PROGRESS' ? 'bg-evalion-teal/10 text-evalion-teal border-evalion-teal/30' :
                          'bg-white/5 text-white/50 border-white/10'
                        }`}>
                          {candidate.status}
                        </span>
                      </div>
                      
                      <div className="space-y-3 mb-6 relative z-10">
                        <div className="flex justify-between text-[10px] font-mono border-b border-white/5 pb-2">
                          <span className="text-evalion-textDim">ID_CODE</span>
                          <span className="text-white">{candidate.id_code}</span>
                        </div>
                        <div className="flex justify-between text-[10px] font-mono">
                          <span className="text-evalion-textDim">SYNTHESIS_SCORE</span>
                          <span className="text-evalion-purple font-bold">{candidate.score}/100</span>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-white/5 flex justify-between items-center text-[10px] text-evalion-textDim group-hover:text-white transition-colors relative z-10">
                        <span className="tracking-widest uppercase">VIEW_PROFILE</span>
                        <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="col-span-full text-center py-20 text-evalion-textDim font-mono text-sm">
                    NO_CANDIDATES_MATCH_QUERY
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <BiometricEnrollment 
        isOpen={isBiometricModalOpen} 
        onClose={() => setIsBiometricModalOpen(false)} 
      />

      <VideoCall 
        isOpen={isVideoCallOpen}
        onClose={() => setIsVideoCallOpen(false)}
      />
    </div>

    {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {isLogoutModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0A0A0A] border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-4 text-evalion-danger">
                <LogOut size={24} />
                <h3 className="text-lg font-bold tracking-widest uppercase">Terminate Session</h3>
              </div>
              <p className="text-evalion-textDim text-sm font-mono mb-8">
                Are you sure you want to terminate the current secure session? Unsaved data may be lost.
              </p>
              <div className="flex justify-end gap-4">
                <button
                  onClick={() => setIsLogoutModalOpen(false)}
                  className="px-4 py-2 text-xs font-mono text-white/50 hover:text-white transition-colors uppercase tracking-widest"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    setIsLogoutModalOpen(false);
                    onLogout();
                  }}
                  className="px-4 py-2 bg-evalion-danger/10 border border-evalion-danger text-evalion-danger text-xs font-bold tracking-widest uppercase rounded hover:bg-evalion-danger hover:text-white transition-all"
                >
                  Confirm
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
