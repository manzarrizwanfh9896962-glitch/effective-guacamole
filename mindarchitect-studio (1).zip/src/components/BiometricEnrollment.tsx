import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Fingerprint, X, ShieldCheck, AlertTriangle, Loader2, Cpu } from 'lucide-react';
import { startRegistration } from '@simplewebauthn/browser';
import axios from 'axios';

export const BiometricEnrollment = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const [status, setStatus] = useState<'IDLE' | 'PROMPTING' | 'SAVING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [errorMessage, setErrorMessage] = useState<string>('');

  useEffect(() => {
    if (!isOpen) {
      setStatus('IDLE');
      setErrorMessage('');
    }
  }, [isOpen]);

  const enrollBiometrics = async () => {
    try {
      setStatus('PROMPTING');
      setErrorMessage('');
      
      const token = localStorage.getItem('token') || localStorage.getItem('mindarchitect_token');
      if (!token) {
        throw new Error("No active session found. Please log in again.");
      }

      // 1. Get registration options from server
      const resp = await axios.post('/api/auth/biometric/enroll/start', {}, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // 2. Pass options to browser authenticator
      const attResp = await startRegistration(resp.data);

      setStatus('SAVING');

      // 3. Send response back to server for verification
      await axios.post('/api/auth/biometric/enroll/finish', { attResp }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setStatus('SUCCESS');
      setTimeout(() => {
        onClose();
      }, 3000);

    } catch (err: any) {
      console.error("Enrollment Error:", err);
      let msg = err.response?.data?.error || err.message || "Biometric enrollment failed.";
      if (msg.includes("publickey-credentials-create") || msg.includes("NotAllowedError")) {
        msg = "Biometric enrollment is blocked. Please ensure you are running this app in a secure context with WebAuthn permissions enabled.";
      }
      setErrorMessage(msg);
      setStatus('ERROR');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="w-full max-w-sm bg-[#0A0A0F] rounded-2xl border border-evalion-teal/30 overflow-hidden relative shadow-[0_0_50px_rgba(0,240,255,0.15)]"
          >
            {/* Header */}
            <div className="pt-8 pb-4 text-center relative z-10">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-evalion-teal/30 bg-evalion-teal/10 text-evalion-teal text-[10px] font-mono mb-4">
                <span className="w-1.5 h-1.5 rounded-full bg-evalion-teal animate-pulse"></span>
                HARDWARE_SECURITY_MODULE
              </div>
              <h2 className="text-xl font-bold tracking-widest text-white mb-2 uppercase">
                Biometric Enrollment
              </h2>
            </div>

            {/* Content */}
            <div className="p-8 pt-2 relative z-10 flex flex-col items-center text-center min-h-[280px] justify-center">
              
              {status === 'IDLE' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 flex flex-col items-center">
                  <div className="w-24 h-24 rounded-full bg-evalion-teal/5 border border-evalion-teal/20 flex items-center justify-center relative">
                    <Fingerprint size={48} className="text-evalion-teal" />
                    <div className="absolute inset-0 rounded-full border border-evalion-teal/40 animate-ping opacity-20"></div>
                  </div>
                  <p className="text-xs text-evalion-textDim font-mono leading-relaxed">
                    Register your device's biometric sensor (Touch ID, Face ID, or Windows Hello) to enable zero-trust passwordless access.
                  </p>
                  <button 
                    onClick={enrollBiometrics}
                    className="w-full py-3 bg-evalion-teal text-black font-bold text-xs tracking-widest uppercase rounded-lg hover:bg-evalion-teal/90 transition-all shadow-[0_0_20px_rgba(0,240,255,0.4)]"
                  >
                    INITIALIZE_SENSOR
                  </button>
                </motion.div>
              )}

              {status === 'PROMPTING' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 flex flex-col items-center">
                  <div className="relative w-24 h-24 flex items-center justify-center">
                    <Fingerprint size={48} className="text-evalion-teal animate-pulse" />
                    <motion.div 
                      className="absolute top-0 left-0 w-full h-1 bg-evalion-teal shadow-[0_0_10px_rgba(0,240,255,0.8)]"
                      animate={{ y: [0, 96, 0] }}
                      transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    />
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-bold text-evalion-teal tracking-widest uppercase">AWAITING_INPUT</p>
                    <p className="text-[10px] text-evalion-textDim font-mono">Please follow your browser's prompt to verify your identity.</p>
                  </div>
                </motion.div>
              )}

              {status === 'SAVING' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 flex flex-col items-center">
                  <Loader2 size={48} className="text-evalion-teal animate-spin" />
                  <div className="space-y-2">
                    <p className="text-sm font-bold text-evalion-teal tracking-widest uppercase">SYNCING_TO_KERNEL</p>
                    <p className="text-[10px] text-evalion-textDim font-mono">Encrypting and storing biometric keys securely...</p>
                  </div>
                </motion.div>
              )}

              {status === 'SUCCESS' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 flex flex-col items-center">
                  <div className="w-24 h-24 rounded-full bg-evalion-success/10 border border-evalion-success/30 flex items-center justify-center">
                    <ShieldCheck size={48} className="text-evalion-success" />
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-bold text-evalion-success tracking-widest uppercase">ENROLLMENT_COMPLETE</p>
                    <p className="text-[10px] text-evalion-textDim font-mono">Device secured. Biometric keys synchronized.</p>
                  </div>
                </motion.div>
              )}

              {status === 'ERROR' && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 flex flex-col items-center w-full">
                  <div className="w-24 h-24 rounded-full bg-evalion-danger/10 border border-evalion-danger/30 flex items-center justify-center">
                    <AlertTriangle size={48} className="text-evalion-danger" />
                  </div>
                  <div className="space-y-2 w-full">
                    <p className="text-sm font-bold text-evalion-danger tracking-widest uppercase">ENROLLMENT_FAILED</p>
                    <p className="text-[10px] text-evalion-danger/70 font-mono bg-evalion-danger/10 p-2 rounded border border-evalion-danger/20 break-words">
                      {errorMessage}
                    </p>
                  </div>
                  <button 
                    onClick={() => setStatus('IDLE')}
                    className="w-full py-3 border border-evalion-textDim/30 text-white font-bold text-xs tracking-widest uppercase rounded-lg hover:bg-white/5 transition-all"
                  >
                    RETRY_PROTOCOL
                  </button>
                </motion.div>
              )}

            </div>

            {/* Top Gradient Glow */}
            <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-evalion-teal/10 to-transparent pointer-events-none"></div>
            
            {/* Close Button */}
            <button onClick={onClose} className="absolute top-4 right-4 text-evalion-textDim hover:text-white transition-colors z-20">
              <X size={20} />
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
