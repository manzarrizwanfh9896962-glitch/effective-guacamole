import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, X } from 'lucide-react';

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
}

export const ConfirmationModal = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = "Confirm",
  cancelText = "Cancel"
}: ConfirmationModalProps) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-[#0A0A0A] border border-evalion-danger/30 rounded-2xl p-6 max-w-sm w-full shadow-[0_0_30px_rgba(255,68,68,0.1)] relative overflow-hidden"
          >
            {/* Background decoration */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-evalion-danger to-transparent"></div>
            
            <div className="flex items-center gap-3 mb-4 text-evalion-danger">
              <div className="p-2 rounded-full bg-evalion-danger/10 border border-evalion-danger/20">
                <AlertTriangle size={24} />
              </div>
              <h3 className="text-lg font-bold tracking-widest uppercase">{title}</h3>
            </div>
            
            <p className="text-evalion-textDim text-sm font-mono mb-8 leading-relaxed">
              {message}
            </p>
            
            <div className="flex justify-end gap-3">
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-mono text-white/50 hover:text-white transition-colors uppercase tracking-widest border border-transparent hover:border-white/10 rounded"
              >
                {cancelText}
              </button>
              <button
                onClick={() => {
                  onConfirm();
                  onClose();
                }}
                className="px-6 py-2 bg-evalion-danger text-black text-xs font-bold tracking-widest uppercase rounded hover:bg-evalion-danger/90 transition-all shadow-[0_0_15px_rgba(255,68,68,0.4)]"
              >
                {confirmText}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
