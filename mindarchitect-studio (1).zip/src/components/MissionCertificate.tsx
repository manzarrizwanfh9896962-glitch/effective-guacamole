import React from 'react';
import { Shield, CheckCircle2, Award, Lock } from 'lucide-react';

interface CertificateProps {
  candidateName: string;
  role: string;
  synthesisIndex: number;
  date: string;
  signature: string;
  benchmarks: {
    logic: number;
    architecture: number;
    security: number;
    performance: number;
  };
}

export const MissionCertificate = React.forwardRef<HTMLDivElement, CertificateProps>((props, ref) => {
  return (
    <div 
      ref={ref}
      className="w-[800px] h-[1132px] bg-[#050505] text-white p-12 font-mono relative border-[20px] border-[#0A0A0A] overflow-hidden"
      style={{ display: 'none' }} // Hidden from UI, used for PDF generation
    >
      {/* Security Border */}
      <div className="absolute inset-4 border border-evalion-teal/30 pointer-events-none"></div>
      <div className="absolute inset-8 border border-evalion-purple/20 pointer-events-none"></div>
      
      {/* Corner Accents */}
      <div className="absolute top-0 left-0 w-32 h-32 border-t-4 border-l-4 border-evalion-teal"></div>
      <div className="absolute top-0 right-0 w-32 h-32 border-t-4 border-r-4 border-evalion-teal"></div>
      <div className="absolute bottom-0 left-0 w-32 h-32 border-b-4 border-l-4 border-evalion-teal"></div>
      <div className="absolute bottom-0 right-0 w-32 h-32 border-b-4 border-r-4 border-evalion-teal"></div>

      {/* Header */}
      <div className="text-center mt-16 space-y-6">
        <div className="flex justify-center mb-8">
          <div className="w-24 h-24 rounded-full border-4 border-evalion-teal flex items-center justify-center">
            <Shield size={48} className="text-evalion-teal" />
          </div>
        </div>
        <h1 className="text-5xl font-bold tracking-[0.2em] text-white uppercase">MISSION_CLEARANCE</h1>
        <div className="h-1 w-64 bg-evalion-teal mx-auto"></div>
        <p className="text-evalion-teal tracking-[0.5em] text-sm">SYSTEM_AUTHORIZATION_LEVEL: OMEGA</p>
      </div>

      {/* Body */}
      <div className="mt-24 space-y-12 px-12">
        <div className="space-y-4">
          <p className="text-evalion-textDim text-xs tracking-widest uppercase">THIS_DOCUMENT_CERTIFIES_THAT</p>
          <h2 className="text-4xl font-bold text-white tracking-tight">{props.candidateName}</h2>
        </div>

        <div className="space-y-4">
          <p className="text-evalion-textDim text-xs tracking-widest uppercase">HAS_SUCCESSFULLY_CLEARED_THE_EVALUATION_FOR</p>
          <h3 className="text-2xl font-bold text-evalion-teal tracking-widest uppercase">{props.role}</h3>
        </div>

        <div className="grid grid-cols-2 gap-12 pt-12">
          <div className="space-y-6">
            <div className="flex justify-between items-end border-b border-white/10 pb-2">
              <span className="text-[10px] text-evalion-textDim uppercase tracking-widest">SYNTHESIS_INDEX</span>
              <span className="text-3xl font-bold text-evalion-teal">{props.synthesisIndex}</span>
            </div>
            <div className="space-y-4">
              {Object.entries(props.benchmarks).map(([key, val]) => (
                <div key={key} className="space-y-1">
                  <div className="flex justify-between text-[8px] tracking-widest uppercase">
                    <span>{key}</span>
                    <span>{val}%</span>
                  </div>
                  <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-evalion-teal" style={{ width: `${val}%` }}></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col justify-center items-center p-8 rounded-3xl bg-evalion-teal/5 border border-evalion-teal/20 relative overflow-hidden">
            <Award size={80} className="text-evalion-teal/20 absolute -top-4 -right-4" />
            <div className="text-center space-y-4 relative z-10">
              <div className="text-6xl font-bold text-evalion-teal">{props.synthesisIndex}</div>
              <div className="text-[10px] text-evalion-textDim tracking-widest uppercase">FINAL_SCORE_SEAL</div>
              <CheckCircle2 size={32} className="text-evalion-success mx-auto" />
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-24 left-24 right-24 flex justify-between items-end">
        <div className="space-y-2">
          <p className="text-[8px] text-evalion-textDim uppercase tracking-widest">VALIDATION_SIGNATURE</p>
          <p className="text-sm font-bold text-white font-mono">{props.signature}</p>
          <div className="h-[1px] w-48 bg-white/20"></div>
        </div>
        <div className="text-right space-y-2">
          <p className="text-[8px] text-evalion-textDim uppercase tracking-widest">ISSUE_DATE</p>
          <p className="text-sm font-bold text-white font-mono">{props.date}</p>
          <div className="flex gap-2 justify-end text-evalion-teal/30">
            <Lock size={12} />
            <Shield size={12} />
          </div>
        </div>
      </div>

      {/* Background Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none">
        <h1 className="text-[200px] font-bold rotate-[-45deg] tracking-[0.2em]">VERIFIED</h1>
      </div>
    </div>
  );
});
