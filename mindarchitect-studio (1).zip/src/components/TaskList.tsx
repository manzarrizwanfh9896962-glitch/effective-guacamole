import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Circle, Trash2, Plus, AlertTriangle } from 'lucide-react';
import { ConfirmationModal } from './ConfirmationModal';
import { LoadingSpinner } from './LoadingSpinner';
import { toast } from 'sonner';
import apiClient from '../services/authService';

interface Task {
  id: string;
  text: string;
  completed: boolean;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
}

export const TaskList = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskText, setNewTaskText] = useState('');
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    setIsLoading(true);
    try {
      const response = await apiClient.get('/tasks');
      setTasks(response.data);
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const addTask = async () => {
    if (!newTaskText.trim()) return;
    try {
      const response = await apiClient.post('/tasks', {
        text: newTaskText,
        priority: 'MEDIUM'
      });
      setTasks([...tasks, response.data]);
      setNewTaskText('');
      toast.success('OBJECTIVE_ADDED', {
        description: `Task "${response.data.text}" has been initialized.`
      });
    } catch (error) {
      console.error('Failed to add task:', error);
      toast.error('INITIALIZATION_FAILED', {
        description: 'Could not add new objective to the kernel.'
      });
    }
  };

  const toggleTask = async (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    
    try {
      const response = await apiClient.put(`/tasks/${id}`, {
        completed: !task.completed
      });
      setTasks(tasks.map(t => t.id === id ? response.data : t));
      
      if (response.data.completed) {
        toast.success('OBJECTIVE_COMPLETED', {
          description: `Task "${task.text}" marked as finished.`
        });
      }
    } catch (error) {
      console.error('Failed to toggle task:', error);
      toast.error('STATE_UPDATE_FAILED');
    }
  };

  const confirmDelete = (id: string) => {
    setTaskToDelete(id);
  };

  const handleDelete = async () => {
    if (taskToDelete) {
      try {
        await apiClient.delete(`/tasks/${taskToDelete}`);
        const deletedTask = tasks.find(t => t.id === taskToDelete);
        setTasks(tasks.filter(t => t.id !== taskToDelete));
        setTaskToDelete(null);
        toast.info('OBJECTIVE_DELETED', {
          description: `Task "${deletedTask?.text}" has been purged.`
        });
      } catch (error) {
        console.error('Failed to delete task:', error);
        toast.error('PURGE_FAILED');
      }
    }
  };

  return (
    <div className="glass-panel p-6 rounded-xl border border-white/5 h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold tracking-wider flex items-center gap-2 text-sm text-white uppercase">
          <CheckCircle2 className="text-evalion-teal" size={18} /> MISSION_OBJECTIVES
        </h3>
        <div className="text-[10px] font-mono text-evalion-textDim">
          {tasks.filter(t => t.completed).length}/{tasks.length} COMPLETED
        </div>
      </div>

      <div className="flex gap-2 mb-6">
        <input
          type="text"
          value={newTaskText}
          onChange={(e) => setNewTaskText(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addTask()}
          placeholder="ADD_NEW_OBJECTIVE..."
          className="flex-grow bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-evalion-teal transition-all placeholder-white/20 font-mono"
        />
        <button
          onClick={addTask}
          disabled={!newTaskText.trim()}
          className="p-2 bg-evalion-teal/10 border border-evalion-teal/30 text-evalion-teal rounded-lg hover:bg-evalion-teal/20 transition-all disabled:opacity-50"
        >
          <Plus size={16} />
        </button>
      </div>

      <div className="space-y-3 overflow-y-auto custom-scrollbar flex-grow pr-2">
        {isLoading ? (
          <div className="flex justify-center py-10">
            <LoadingSpinner />
          </div>
        ) : (
          <AnimatePresence>
            {tasks.map((task) => (
              <motion.div
                key={task.id}
                layout
                initial={{ opacity: 0, x: -20, scale: 0.95 }}
                animate={{ 
                  opacity: task.completed ? 0.4 : 1, 
                  x: 0,
                  scale: task.completed ? 0.96 : 1,
                  backgroundColor: task.completed ? 'rgba(5, 255, 0, 0.05)' : 'rgba(0, 0, 0, 0.4)',
                  transition: { 
                    type: "spring", 
                    stiffness: 400, 
                    damping: 25,
                    opacity: { duration: 0.4 },
                    backgroundColor: { duration: 0.5 }
                  }
                }}
                exit={{ 
                  opacity: 0, 
                  x: 20, 
                  scale: 0.95,
                  transition: { duration: 0.2 }
                }}
                whileHover={{ 
                  scale: task.completed ? 0.96 : 1.01,
                  backgroundColor: task.completed ? 'rgba(5, 255, 0, 0.08)' : 'rgba(255, 255, 255, 0.08)',
                }}
                className={`group flex items-center justify-between p-3 rounded-lg border transition-all ${
                  task.completed 
                    ? 'border-evalion-success/20' 
                    : 'border-white/10 hover:border-evalion-teal/30 shadow-lg shadow-black/20'
                }`}
              >
                <div className="flex items-center gap-3 overflow-hidden">
                  <button
                    onClick={() => toggleTask(task.id)}
                    className={`shrink-0 transition-colors relative ${task.completed ? 'text-evalion-success' : 'text-white/20 hover:text-evalion-teal'}`}
                  >
                    <AnimatePresence mode="wait">
                      {task.completed ? (
                        <motion.div
                          key="checked"
                          initial={{ scale: 0, opacity: 0, rotate: -180 }}
                          animate={{ 
                            scale: [0, 1.5, 1], 
                            opacity: 1, 
                            rotate: 0,
                            filter: ["blur(10px)", "blur(0px)"],
                            boxShadow: ["0 0 0px rgba(5,255,0,0)", "0 0 20px rgba(5,255,0,0.8)", "0 0 5px rgba(5,255,0,0.4)"]
                          }}
                          exit={{ scale: 0, opacity: 0, rotate: 180 }}
                          transition={{ type: "spring", stiffness: 500, damping: 15 }}
                          className="rounded-full"
                        >
                          <CheckCircle2 size={16} className="text-evalion-success drop-shadow-[0_0_8px_rgba(5,255,0,0.8)]" />
                        </motion.div>
                      ) : (
                        <motion.div
                          key="unchecked"
                          initial={{ scale: 0.5, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.5, opacity: 0 }}
                        >
                          <Circle size={16} />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </button>
                  <div className="relative overflow-hidden flex items-center">
                    <motion.span 
                      layout
                      className={`text-xs font-mono truncate transition-all duration-500 ${task.completed ? 'line-through text-white/30 italic' : 'text-white/80'}`}
                    >
                      {task.text}
                    </motion.span>
                    {task.completed && (
                      <motion.div 
                        initial={{ x: "-100%" }}
                        animate={{ x: "100%" }}
                        transition={{ duration: 0.5, ease: "linear" }}
                        className="absolute inset-0 bg-evalion-success/20 skew-x-12"
                      />
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className={`text-[8px] px-1.5 py-0.5 rounded border ${
                    task.priority === 'HIGH' ? 'text-evalion-danger border-evalion-danger/30 bg-evalion-danger/10' :
                    task.priority === 'MEDIUM' ? 'text-evalion-teal border-evalion-teal/30 bg-evalion-teal/10' :
                    'text-white/50 border-white/10 bg-white/5'
                  }`}>
                    {task.priority}
                  </span>
                  <button
                    onClick={() => confirmDelete(task.id)}
                    className="p-1.5 text-evalion-danger/50 hover:text-evalion-danger hover:bg-evalion-danger/10 rounded transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
        
        {!isLoading && tasks.length === 0 && (
          <div className="text-center py-8 text-white/20 text-xs font-mono">
            NO_ACTIVE_OBJECTIVES
          </div>
        )}
      </div>

      <ConfirmationModal
        isOpen={!!taskToDelete}
        onClose={() => setTaskToDelete(null)}
        onConfirm={handleDelete}
        title="DELETE_OBJECTIVE"
        message="Are you sure you want to permanently remove this mission objective? This action cannot be undone."
        confirmText="DELETE"
        cancelText="CANCEL"
      />
    </div>
  );
};
