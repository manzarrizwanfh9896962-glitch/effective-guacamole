import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight, CheckCircle, Terminal, Shield, Cpu, Activity, BarChart3, Code } from 'lucide-react';

const VisualWelcome = () => (
  <div className="w-full h-48 rounded-2xl mb-6 border border-white/5 bg-evalion-surface/50 overflow-hidden relative flex items-center justify-center">
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-evalion-teal/20 via-black to-black"></div>
    <div className="relative z-10 flex flex-col items-center gap-4">
      <div className="w-16 h-16 rounded-full border border-evalion-teal/30 flex items-center justify-center bg-black/50 backdrop-blur-sm">
        <Shield className="text-evalion-teal w-8 h-8" />
      </div>
      <div className="flex gap-2">
        <div className="h-2 w-16 bg-evalion-teal/40 rounded-full"></div>
        <div className="h-2 w-8 bg-evalion-purple/40 rounded-full"></div>
        <div className="h-2 w-24 bg-white/20 rounded-full"></div>
      </div>
      <div className="flex gap-2">
        <div className="h-2 w-12 bg-white/20 rounded-full"></div>
        <div className="h-2 w-20 bg-evalion-teal/40 rounded-full"></div>
      </div>
    </div>
  </div>
);

const VisualDeploy = () => (
  <div className="w-full h-48 rounded-2xl mb-6 border border-white/5 bg-evalion-surface/50 overflow-hidden relative flex items-center justify-center">
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-evalion-purple/20 via-black to-black"></div>
    <div className="relative z-10 w-3/4 bg-black/80 border border-white/10 rounded-lg p-4 shadow-2xl">
      <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-2">
        <Terminal className="text-evalion-purple w-4 h-4" />
        <div className="text-[10px] font-mono text-white/50">AGENT_CONFIG.yml</div>
      </div>
      <div className="space-y-2">
        <div className="flex gap-2 items-center"><span className="text-evalion-purple text-xs font-mono">role:</span><div className="h-2 w-24 bg-white/20 rounded"></div></div>
        <div className="flex gap-2 items-center"><span className="text-evalion-purple text-xs font-mono">strictness:</span><div className="h-2 w-12 bg-evalion-teal/40 rounded"></div></div>
        <div className="flex gap-2 items-center"><span className="text-evalion-purple text-xs font-mono">modules:</span><div className="h-2 w-32 bg-white/20 rounded"></div></div>
      </div>
    </div>
  </div>
);

const VisualSimulation = () => (
  <div className="w-full h-48 rounded-2xl mb-6 border border-white/5 bg-evalion-surface/50 overflow-hidden relative flex items-center justify-center p-4 gap-4">
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-evalion-teal/10 via-black to-black"></div>
    <div className="flex-1 h-full bg-black/80 border border-white/10 rounded-lg p-3 flex flex-col gap-3 relative z-10">
      <div className="flex items-center gap-2 text-evalion-teal/50 mb-2">
        <Code className="w-4 h-4" />
      </div>
      <div className="h-2 w-3/4 bg-evalion-teal/30 rounded-full"></div>
      <div className="h-2 w-1/2 bg-white/20 rounded-full ml-4"></div>
      <div className="h-2 w-2/3 bg-white/20 rounded-full ml-4"></div>
      <div className="h-2 w-1/3 bg-evalion-purple/30 rounded-full"></div>
    </div>
    <div className="w-1/3 h-full flex flex-col gap-2 relative z-10">
      <div className="flex-1 bg-black/80 border border-evalion-teal/20 rounded-lg p-2 flex items-center justify-center">
        <Activity className="text-evalion-teal w-6 h-6 animate-pulse" />
      </div>
      <div className="flex-1 bg-black/80 border border-evalion-purple/20 rounded-lg p-2 flex items-center justify-center">
        <Cpu className="text-evalion-purple w-6 h-6" />
      </div>
    </div>
  </div>
);

const VisualAnalytics = () => (
  <div className="w-full h-48 rounded-2xl mb-6 border border-white/5 bg-evalion-surface/50 overflow-hidden relative flex items-end justify-center p-6 gap-3">
    <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-evalion-success/20 via-black to-black"></div>
    <div className="absolute top-4 right-4 z-10">
      <BarChart3 className="text-evalion-success w-6 h-6" />
    </div>
    <div className="w-8 bg-evalion-teal/40 rounded-t-sm h-[40%] relative z-10"></div>
    <div className="w-8 bg-evalion-purple/40 rounded-t-sm h-[60%] relative z-10"></div>
    <div className="w-8 bg-evalion-success/40 rounded-t-sm h-[85%] relative z-10"></div>
    <div className="w-8 bg-white/20 rounded-t-sm h-[30%] relative z-10"></div>
    <div className="w-8 bg-evalion-teal/60 rounded-t-sm h-[70%] relative z-10"></div>
  </div>
);

const tutorialSteps = [
  {
    title: "WELCOME TO MINDARCHITECT STUDIO",
    description: "Discover the autonomous operating system for technical recruitment. Let's get started!",
    visual: <VisualWelcome />,
    actionText: "NEXT: DEPLOYMENT",
  },
  {
    title: "DEPLOY YOUR AI AGENT",
    description: "Seamlessly deploy your custom AI agent to evaluate candidates with zero-trust architecture.",
    visual: <VisualDeploy />,
    actionText: "NEXT: SIMULATION",
  },
  {
    title: "RUN REAL-TIME SIMULATIONS",
    description: "Test candidate performance in a neuro-code sandbox with real-time algorithmic complexity mapping.",
    visual: <VisualSimulation />,
    actionText: "NEXT: ANALYTICS",
  },
  {
    title: "ANALYZE WITH NEURAL SCORING",
    description: "Gain deep insights with synthesized analytics, calibrated across 5,000+ data vectors.",
    visual: <VisualAnalytics />,
    actionText: "GET STARTED",
  },
];

interface OnboardingTutorialProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export const OnboardingTutorial: React.FC<OnboardingTutorialProps> = ({
  isOpen,
  onClose,
  onComplete,
}) => {
  const [currentStep, setCurrentStep] = React.useState(0);

  const handleNext = () => {
    if (currentStep < tutorialSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
      onClose();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  if (!isOpen) return null;

  const step = tutorialSteps[currentStep];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="glass-panel relative w-full max-w-3xl rounded-3xl p-8 md:p-12 text-white text-center border border-white/10 bg-[#0A0A0A]"
          >
            <button
              onClick={onClose}
              className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors"
              aria-label="Close tutorial"
            >
              <X size={24} />
            </button>

            <div className="mb-8">
              {step.visual}
              <h3 className="text-3xl font-bold tracking-tight mb-4 text-white uppercase">
                {step.title}
              </h3>
              <p className="text-evalion-textDim text-sm font-mono leading-relaxed tracking-wider max-w-md mx-auto">
                {step.description}
              </p>
            </div>

            <div className="flex justify-center items-center gap-4 mb-8">
              {tutorialSteps.map((_, index) => (
                <span
                  key={index}
                  className={`w-2.5 h-2.5 rounded-full ${
                    index === currentStep ? 'bg-evalion-teal' : 'bg-white/20'
                  } transition-colors`}
                ></span>
              ))}
            </div>

            <div className="flex justify-between gap-4">
              <button
                onClick={handleBack}
                disabled={currentStep === 0}
                className="px-6 py-3 border border-white/10 text-white/50 font-mono text-xs tracking-widest uppercase rounded-xl hover:bg-white/5 hover:border-white/30 transition-all duration-500 flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={16} /> BACK
              </button>
              <button
                onClick={handleNext}
                className="px-6 py-3 bg-evalion-teal text-black font-bold text-xs tracking-widest uppercase rounded-xl hover:bg-evalion-teal/80 transition-all duration-500 flex items-center gap-2"
              >
                {step.actionText} {currentStep === tutorialSteps.length - 1 ? <CheckCircle size={16} /> : <ChevronRight size={16} />}
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
