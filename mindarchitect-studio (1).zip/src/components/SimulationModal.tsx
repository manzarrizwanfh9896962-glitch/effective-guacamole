import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Code, Play, X, CheckCircle2, AlertCircle, Activity } from 'lucide-react';

export const SimulationModal = ({ isOpen, onClose }: { isOpen: boolean, onClose: () => void }) => {
  const [code, setCode] = useState('function calculateComplexity(arr) {\n  // Implement O(n log n) sorting algorithm\n  return arr.sort((a, b) => a - b);\n}');
  const [isRunning, setIsRunning] = useState(false);
  const [results, setResults] = useState<{ status: string, time: string, memory: string } | null>(null);

  const runSimulation = () => {
    setIsRunning(true);
    setResults(null);
    setTimeout(() => {
      setIsRunning(false);
      setResults({
        status: 'PASSED',
        time: '42ms',
        memory: '12.4MB'
      });
    }, 1500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="w-full max-w-4xl glass-panel rounded-2xl border border-evalion-purple/30 overflow-hidden relative flex flex-col h-[80vh]"
          >
            {/* Header */}
            <div className="p-4 border-b border-evalion-purple/20 flex justify-between items-center bg-evalion-surface/50">
              <div className="flex items-center gap-3">
                <Terminal className="text-evalion-purple" size={20} />
                <h3 className="font-bold tracking-widest text-sm">SIMULATION_ENVIRONMENT</h3>
                <span className="px-2 py-0.5 bg-evalion-purple/20 text-evalion-purple rounded text-[10px] font-mono border border-evalion-purple/30">SANDBOX_ACTIVE</span>
              </div>
              <button onClick={onClose} className="text-evalion-textDim hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>

            {/* Content */}
            <div className="flex-grow flex flex-col md:flex-row overflow-hidden">
              {/* Editor */}
              <div className="flex-grow flex flex-col border-r border-evalion-textDim/10">
                <div className="p-2 border-b border-evalion-textDim/10 bg-evalion-bg flex items-center gap-2 text-xs font-mono text-evalion-textDim">
                  <Code size={14} /> algorithm.js
                </div>
                <textarea
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="flex-grow bg-evalion-bg p-4 font-mono text-sm text-evalion-text focus:outline-none resize-none"
                  spellCheck="false"
                />
              </div>

              {/* Sidebar */}
              <div className="w-full md:w-80 bg-evalion-surface/30 flex flex-col">
                <div className="p-6 flex-grow">
                  <h4 className="font-bold tracking-wider text-sm mb-4">TASK_OBJECTIVE</h4>
                  <p className="text-xs text-evalion-textDim font-mono mb-6">
                    Implement a sorting algorithm with a time complexity of O(n log n) and space complexity of O(1).
                  </p>

                  <div className="space-y-4 mb-8">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-evalion-textDim">Time Limit:</span>
                      <span className="text-evalion-purple">2000ms</span>
                    </div>
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-evalion-textDim">Memory Limit:</span>
                      <span className="text-evalion-purple">256MB</span>
                    </div>
                  </div>

                  {results && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 rounded-lg border border-evalion-success/30 bg-evalion-success/10 mb-6"
                    >
                      <div className="flex items-center gap-2 text-evalion-success font-bold text-sm mb-2">
                        <CheckCircle2 size={16} /> {results.status}
                      </div>
                      <div className="flex justify-between text-xs font-mono text-evalion-textDim">
                        <span>Time: {results.time}</span>
                        <span>Mem: {results.memory}</span>
                      </div>
                    </motion.div>
                  )}
                </div>

                <div className="p-4 border-t border-evalion-textDim/10 bg-evalion-bg">
                  <button 
                    onClick={runSimulation}
                    disabled={isRunning}
                    className="w-full py-3 bg-evalion-purple text-white font-bold rounded hover:bg-evalion-purple/90 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isRunning ? (
                      <><Activity size={18} className="animate-spin" /> EXECUTING...</>
                    ) : (
                      <><Play size={18} /> RUN_CODE</>
                    )}
                  </button>
                </div>
              </div>
            </div>
            
            {/* Scanline Effect */}
            <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.1)_50%)] bg-[length:100%_4px] opacity-10"></div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};