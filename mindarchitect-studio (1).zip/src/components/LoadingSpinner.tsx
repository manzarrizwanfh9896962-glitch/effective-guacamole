import React from 'react';
import { motion } from 'framer-motion';

export const LoadingSpinner = () => {
  return (
    <div className="flex items-center justify-center p-4 relative">
      <motion.div
        className="w-8 h-8 border-2 border-evalion-teal/30 rounded-full"
      />
      <motion.div
        className="absolute w-8 h-8 border-2 border-t-evalion-teal border-r-transparent border-b-transparent border-l-transparent rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        className="absolute w-4 h-4 border-2 border-t-evalion-purple border-r-transparent border-b-transparent border-l-transparent rounded-full"
        animate={{ rotate: -360 }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
};
