import React from 'react';
import { Terminal, Fingerprint } from 'lucide-react';

export const ApiDocs = () => {
  return (
    <section className="py-32 bg-[#050505] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-white/10 to-transparent"></div>
      
      <div className="max-w-5xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-end justify-between mb-20 gap-8">
          <div className="max-w-xl">
            <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase mb-6 opacity-60">
              [ DEVELOPER_RESOURCES ]
            </h3>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tighter mb-6 leading-none">
              <span className="font-serif italic font-light text-evalion-textDim/50 block text-2xl md:text-3xl mb-2">Build with our</span>
              ENTERPRISE API
            </h2>
          </div>
          <p className="max-w-xs text-evalion-textDim text-xs font-light leading-relaxed tracking-wide mb-2">
            Integrate MindArchitect Studio's autonomous hiring engine directly into your existing ATS or internal portals. All endpoints are secured via JWT.
          </p>
        </div>

        <div className="space-y-16">
          {/* Health Endpoint */}
          <div className="group">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-10 h-10 rounded-xl bg-evalion-teal/10 border border-evalion-teal/30 flex items-center justify-center">
                <Terminal size={20} className="text-evalion-teal" />
              </div>
              <h3 className="text-xl font-bold tracking-wider text-white">System Health</h3>
            </div>
            <div className="relative rounded-3xl bg-white/[0.02] border border-white/[0.05] p-10 overflow-hidden">
              <div className="absolute top-0 right-0 p-4 text-[9px] font-mono text-white/20 uppercase tracking-widest">GET /api/health</div>
              <code className="text-sm font-mono text-white/80 leading-relaxed block">
                <span className="text-evalion-teal">curl</span> -X GET http://localhost:3000/api/health
              </code>
            </div>
          </div>

          {/* Auth Endpoint */}
          <div className="group">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-10 h-10 rounded-xl bg-evalion-purple/10 border border-evalion-purple/30 flex items-center justify-center">
                <Terminal size={20} className="text-evalion-purple" />
              </div>
              <h3 className="text-xl font-bold tracking-wider text-white">Authentication</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="rounded-3xl bg-white/[0.02] border border-white/[0.05] p-10">
                <div className="flex items-center gap-3 mb-8">
                  <span className="px-3 py-1 bg-evalion-success/10 border border-evalion-success/30 rounded-full text-[9px] font-bold text-evalion-success uppercase tracking-widest">POST</span>
                  <span className="text-xs font-mono text-white/40">/api/auth/login</span>
                </div>
                <pre className="text-xs font-mono text-white/60 leading-relaxed">
{`{
  "email": "admin@mindarchitect.sys",
  "password": "••••••••"
}`}
                </pre>
              </div>
              <div className="rounded-3xl bg-white/[0.02] border border-white/[0.05] p-10">
                <div className="text-[9px] font-mono text-white/20 uppercase tracking-widest mb-8">Response (200 OK)</div>
                <pre className="text-xs font-mono text-evalion-teal leading-relaxed">
{`{
  "user": { "id": 1, "email": "..." },
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI..."
}`}
                </pre>
              </div>
            </div>
          </div>

          {/* Biometric Endpoint */}
          <div className="group">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-10 h-10 rounded-xl bg-evalion-teal/10 border border-evalion-teal/30 flex items-center justify-center">
                <Fingerprint size={20} className="text-evalion-teal" />
              </div>
              <h3 className="text-xl font-bold tracking-wider text-white">Biometric (WebAuthn)</h3>
            </div>
            <div className="rounded-3xl bg-white/[0.02] border border-white/[0.05] p-10">
              <p className="text-xs text-evalion-textDim mb-6">Passwordless authentication via FIDO2/WebAuthn standards.</p>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-white/60 uppercase tracking-widest">Register Start</span>
                  <span className="text-[10px] font-mono text-evalion-teal">POST /api/auth/biometric/register/start</span>
                </div>
                <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-white/60 uppercase tracking-widest">Login Start</span>
                  <span className="text-[10px] font-mono text-evalion-purple">POST /api/auth/biometric/login/start</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};