import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface CollapsibleTextProps {
  text: string;
  maxLength?: number;
  className?: string;
  speakerColorClass?: string; // Tailwind class for speaker color
}

export const CollapsibleText: React.FC<CollapsibleTextProps> = ({
  text,
  maxLength = 150,
  className = '',
  speakerColorClass = 'text-evalion-text',
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isLongText = text.length > maxLength;

  const displayedText = isLongText && !isExpanded
    ? `${text.substring(0, maxLength)}...`
    : text;

  return (
    <span className={`flex flex-col ${className}`}>
      <span className={speakerColorClass}>
        {displayedText}
        <span className="ml-2 text-[9px] font-mono text-evalion-textDim/50 bg-black/30 px-1.5 py-0.5 rounded border border-white/5 inline-flex items-center">
          {text.length} chars
        </span>
      </span>
      {isLongText && (
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="mt-2 text-[10px] font-mono tracking-wider uppercase text-evalion-teal hover:text-white transition-colors flex items-center gap-1 self-start"
        >
          {isExpanded ? (
            <><ChevronUp size={12} /> SHOW_LESS</>
          ) : (
            <><ChevronDown size={12} /> READ_MORE</>
          )}
        </button>
      )}
    </span>
  );
};
