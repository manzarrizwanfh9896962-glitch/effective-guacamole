import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Zap, Cpu, Lock, Globe, BarChart3 } from 'lucide-react';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
  linkLabel: string;
}

const FeatureCard = ({ icon, title, description, link, linkLabel }: FeatureCardProps) => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <div 
      className="relative w-full h-64 perspective-1000 cursor-pointer group"
      onMouseEnter={() => setIsFlipped(true)}
      onMouseLeave={() => setIsFlipped(false)}
    >
      <motion.div
        className="w-full h-full relative style-preserve-3d transition-all duration-700"
        animate={{ rotateY: isFlipped ? 180 : 0 }}
        transition={{ type: 'spring', stiffness: 150, damping: 20 }}
      >
        {/* Front Side */}
        <div className="absolute inset-0 backface-hidden glass-panel p-8 rounded-3xl border border-white/10 flex flex-col items-center justify-center text-center gap-4 group-hover:border-evalion-teal/30 transition-colors duration-500">
          <div className="absolute inset-0 bg-evalion-teal/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-3xl"></div>
          <div className="w-12 h-12 rounded-2xl bg-evalion-teal/10 border border-evalion-teal/30 flex items-center justify-center text-evalion-teal shadow-[0_0_15px_rgba(0,240,255,0.2)] group-hover:shadow-[0_0_25px_rgba(0,240,255,0.4)] transition-all duration-500">
            {icon}
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight relative z-10">{title}</h3>
          <div className="text-[10px] font-mono text-evalion-teal/60 uppercase tracking-widest relative z-10">Hover to reveal</div>
        </div>

        {/* Back Side */}
        <div 
          className="absolute inset-0 backface-hidden glass-panel p-8 rounded-3xl border border-evalion-teal/30 flex flex-col items-center justify-center text-center gap-4 bg-evalion-teal/10 shadow-[0_0_30px_rgba(0,240,255,0.1)]"
          style={{ transform: 'rotateY(180deg)' }}
        >
          <p className="text-sm text-white/90 leading-relaxed font-mono tracking-tight">
            {description}
          </p>
          <a 
            href={link} 
            target="_blank" 
            rel="noopener noreferrer"
            className="mt-4 text-[10px] font-mono text-evalion-teal hover:text-white transition-colors uppercase tracking-widest flex items-center gap-2"
          >
            {linkLabel} <Zap size={10} className="animate-pulse" />
          </a>
        </div>
      </motion.div>
    </div>
  );
};

export const FeatureCards = () => {
  const features = [
    {
      icon: <Shield size={24} />,
      title: "Zero-Trust Verification",
      description: "Our AI agents use multi-layered verification to ensure candidate depth and logic integrity.",
      link: "/legal/terms",
      linkLabel: "Legal Protocol"
    },
    {
      icon: <Cpu size={24} />,
      title: "Autonomous Interviews",
      description: "Scale your hiring with fully autonomous technical interviews that adapt to candidate skill levels.",
      link: "/legal/privacy",
      linkLabel: "Privacy Policy"
    },
    {
      icon: <Globe size={24} />,
      title: "Global Infrastructure",
      description: "Deployed across 12 global regions for low-latency, real-time technical evaluation.",
      link: "/legal/terms",
      linkLabel: "Terms of Service"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24 w-full max-w-6xl">
      {features.map((feature, idx) => (
        <FeatureCard key={idx} {...feature} />
      ))}
    </div>
  );
};
