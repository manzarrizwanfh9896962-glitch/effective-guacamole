import React, { useEffect, useState } from 'react';
import { Contrast } from 'lucide-react';

export const HighContrastToggle = () => {
  const [isHighContrast, setIsHighContrast] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('high-contrast-mode');
    if (saved === 'true') {
      setIsHighContrast(true);
      document.body.classList.add('high-contrast');
    }
  }, []);

  const toggle = () => {
    const next = !isHighContrast;
    setIsHighContrast(next);
    localStorage.setItem('high-contrast-mode', String(next));
    if (next) {
      document.body.classList.add('high-contrast');
    } else {
      document.body.classList.remove('high-contrast');
    }
  };

  return (
    <button
      onClick={toggle}
      className={`fixed bottom-24 right-6 z-50 w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-[0_0_20px_rgba(255,255,255,0.1)] ${
        isHighContrast 
          ? 'bg-white text-black border-2 border-white shadow-[0_0_15px_rgba(255,255,255,0.5)]' 
          : 'bg-black/50 text-white/50 border border-white/10 hover:text-white hover:bg-white/10'
      }`}
      title="Toggle High Contrast Mode"
    >
      <Contrast size={24} />
    </button>
  );
};
