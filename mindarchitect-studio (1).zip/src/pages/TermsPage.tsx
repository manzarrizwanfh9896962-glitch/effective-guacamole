import React from 'react';

export const TermsPage = () => (
  <div className="max-w-4xl mx-auto px-6 py-32 text-evalion-textDim">
    <h1 className="text-4xl font-bold text-white mb-8">Terms of Service</h1>
    <div className="prose prose-invert prose-sm font-light leading-relaxed tracking-wide">
      <p>Last Updated: October 26, 2023</p>
      <p>Welcome to MindArchitect Studio. These terms and conditions outline the rules and regulations for the use of our website and services.</p>
      <h2 className="text-white">1. Acceptance of Terms</h2>
      <p>By accessing this website, we assume you accept these terms and conditions. Do not continue to use MindArchitect Studio if you do not agree to all of the terms and conditions stated on this page.</p>
      <h2 className="text-white">2. License to Use</h2>
      <p>Unless otherwise stated, MindArchitect Studio and/or its licensors own the intellectual property rights for all material on this website. You may view and/or print pages from https://mindarchitect.studio for your own personal use subject to restrictions set in these terms and conditions.</p>
      <h2 className="text-white">3. User Data and Biometrics</h2>
      <p>Our service uses advanced AI and may involve the collection of biometric data for security and identification purposes, as well as voice and video data during simulated interviews. By using our service, you consent to the collection and processing of this data as outlined in our Privacy Policy. We are committed to protecting your data and using it solely for the purpose of providing and improving our services.</p>
      <h2 className="text-white">4. Disclaimer</h2>
      <p>The materials on MindArchitect Studio's website are provided on an 'as is' basis. MindArchitect Studio makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
    </div>
  </div>
);
