import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShieldAlert, Loader2, Lock, Mail, UserPlus, LogIn, Fingerprint } from 'lucide-react';
import { startRegistration, startAuthentication } from '@simplewebauthn/browser';
import { Logo } from '../components/Logo';

import { authService } from '../services/authService';

export const LoginPage = ({ onLoginSuccess }: { onLoginSuccess: () => void }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState<'IDLE' | 'LOADING' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('LOADING');
    setErrorMessage('');

    try {
      if (isLogin) {
        await authService.login(email, password);
      } else {
        await authService.signup(email, password);
      }
      
      setStatus('SUCCESS');
      setTimeout(() => {
        onLoginSuccess();
        navigate('/dashboard');
      }, 500);

    } catch (err: any) {
      console.error("Auth Error:", err);
      setErrorMessage(err.response?.data?.error || err.message || "Authentication failed");
      setStatus('ERROR');
    }
  };

  const handleBiometricAuth = async () => {
    if (!email) {
      setErrorMessage('Please enter your email to use biometrics');
      setStatus('ERROR');
      return;
    }

    setStatus('LOADING');
    setErrorMessage('');

    try {
      if (isLogin) {
        // Biometric Login
        const resp = await fetch('/api/auth/biometric/login/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email }),
        });
        
        if (!resp.ok) {
          const errData = await resp.json();
          throw new Error(errData.error || 'Biometric login failed');
        }
        
        const options = await resp.json();
        const asseResp = await startAuthentication(options);
        
        const verificationResp = await fetch('/api/auth/biometric/login/finish', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, response: asseResp }),
        });
        
        const verificationData = await verificationResp.json();
        if (!verificationResp.ok) throw new Error(verificationData.error || 'Biometric verification failed');
        
        localStorage.setItem('mindarchitect_access_token', verificationData.accessToken);
        localStorage.setItem('mindarchitect_refresh_token', verificationData.refreshToken);
        setStatus('SUCCESS');
        setTimeout(() => {
          onLoginSuccess();
          navigate('/dashboard');
        }, 500);
      } else {
        // Biometric Registration
        const resp = await fetch('/api/auth/biometric/register/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email }),
        });
        
        if (!resp.ok) {
          const errData = await resp.json();
          throw new Error(errData.error || 'Biometric registration failed. Ensure account exists first.');
        }
        
        const options = await resp.json();
        const attResp = await startRegistration(options);
        
        const verificationResp = await fetch('/api/auth/biometric/register/finish', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, response: attResp }),
        });
        
        const verificationData = await verificationResp.json();
        if (!verificationResp.ok) throw new Error(verificationData.error || 'Biometric registration verification failed');
        
        setErrorMessage('Biometric registered successfully. You can now login.');
        setStatus('IDLE');
        setIsLogin(true);
      }
    } catch (err: any) {
      console.error("Biometric Auth Error:", err);
      setErrorMessage(err.message || "Biometric authentication failed");
      setStatus('ERROR');
    }
  };

  return (
    <div className="min-h-screen bg-evalion-bg text-evalion-text flex flex-col items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-4 mb-12"
      >
        <Logo size={48} />
        <h1 className="text-3xl font-bold tracking-tight text-white">
          Mind<span className="text-evalion-teal">Architect</span> <span className="text-evalion-purple">Studio</span>
        </h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md bg-[#0A0A0F] rounded-2xl border border-evalion-teal/30 p-8 shadow-[0_0_50px_rgba(0,240,255,0.1)]"
      >
        <div className="text-center mb-8">
          <h2 className="text-xl font-bold text-white tracking-widest uppercase mb-2">
            {isLogin ? 'SECURE_LOGIN' : 'INITIALIZE_ACCOUNT'}
          </h2>
          <p className="text-xs font-mono text-evalion-textDim">
            {isLogin ? 'Enter your credentials to access the system.' : 'Create a new secure identity.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-mono text-evalion-teal tracking-widest uppercase mb-2">
                EMAIL_ADDRESS
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-evalion-textDim w-4 h-4" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-black/50 border border-white/10 rounded-lg py-3 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-evalion-teal transition-colors"
                  placeholder="architect@evalion.ai"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-mono text-evalion-teal tracking-widest uppercase mb-2">
                SECURITY_KEY
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-evalion-textDim w-4 h-4" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black/50 border border-white/10 rounded-lg py-3 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-evalion-teal transition-colors"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>
          </div>

          {status === 'ERROR' && (
            <div className="flex items-center gap-2 text-evalion-danger bg-evalion-danger/10 p-3 rounded-lg border border-evalion-danger/20">
              <ShieldAlert size={16} />
              <span className="text-xs font-mono">{errorMessage}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={status === 'LOADING' || status === 'SUCCESS'}
            className="w-full py-3 bg-evalion-teal text-black font-bold text-xs tracking-widest uppercase rounded-lg hover:bg-evalion-teal/90 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {status === 'LOADING' ? (
              <Loader2 size={16} className="animate-spin" />
            ) : isLogin ? (
              <><LogIn size={16} /> AUTHENTICATE</>
            ) : (
              <><UserPlus size={16} /> REGISTER_IDENTITY</>
            )}
          </button>
          
          <div className="relative flex items-center py-2">
            <div className="flex-grow border-t border-white/10"></div>
            <span className="flex-shrink-0 mx-4 text-evalion-textDim text-[10px] font-mono uppercase tracking-widest">OR</span>
            <div className="flex-grow border-t border-white/10"></div>
          </div>

          <button
            type="button"
            onClick={handleBiometricAuth}
            disabled={status === 'LOADING' || status === 'SUCCESS'}
            className="w-full py-3 bg-transparent text-evalion-teal border border-evalion-teal/30 font-bold text-xs tracking-widest uppercase rounded-lg hover:bg-evalion-teal/10 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Fingerprint size={16} />
            {isLogin ? 'BIOMETRIC LOGIN' : 'REGISTER BIOMETRICS'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setErrorMessage('');
            }}
            className="text-[10px] font-mono text-evalion-textDim hover:text-white transition-colors tracking-widest uppercase"
          >
            {isLogin ? 'NO_IDENTITY? REGISTER_NOW' : 'HAVE_IDENTITY? LOGIN_NOW'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};
