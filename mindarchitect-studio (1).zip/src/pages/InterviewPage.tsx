import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Terminal, Camera, Mic, Shield, Activity, Play, Send, Loader2, CheckCircle2, AlertTriangle, Cpu, Users, Download } from 'lucide-react';
import { interviewService, Question } from '../services/interviewService';
import { geminiService } from '../services/geminiService';
import { evaluationService, EvaluationResult } from '../services/evaluationService';
import { CollaborationPanel } from '../components/CollaborationPanel';
import { MissionCertificate } from '../components/MissionCertificate';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

import { CyberLoading } from '../components/CyberLoading';

export const InterviewPage = () => {
  const [status, setStatus] = useState<'IDLE' | 'SYNCING' | 'ACTIVE' | 'SUBMITTING' | 'REPORTING'>('IDLE');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [transcript, setTranscript] = useState<string[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isAITyping, setIsAITyping] = useState(false);
  const [evaluation, setEvaluation] = useState<EvaluationResult | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [candidateName, setCandidateName] = useState('UNIDENTIFIED_NODE');
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const certificateRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [transcript, isAITyping]);

  const startInterview = async () => {
    setStatus('SYNCING');
    await interviewService.initializeNeuralSync();
    const generatedQuestions = interviewService.generateStrategicQuestions("Senior Fullstack Architect");
    setQuestions(generatedQuestions);
    setStatus('ACTIVE');
    
    // Initial AI Greeting
    setIsAITyping(true);
    setTimeout(() => {
      setTranscript([`[SYSTEM]: Neural Sync Established. Protocol 0x01_START initiated. Welcome, candidate. I am your Lead Architect for this session. Let's begin with our first strategic inquiry.`]);
      setIsAITyping(false);
      // Ask first question
      setTimeout(() => {
        setTranscript(prev => [...prev, `[AI_AGENT]: ${generatedQuestions[0].text}`]);
      }, 500);
    }, 1500);

    // Start Camera and Microphone
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch (err: any) {
      console.error("Media access denied", err);
      let errorMessage = "Sensors offline.";
      
      if (err.name === 'NotAllowedError') {
        errorMessage = "Permission denied. Please allow camera and microphone access.";
      } else if (err.name === 'NotFoundError') {
        errorMessage = "No camera or microphone found.";
      }

      setTranscript(prev => [...prev, `[SYSTEM]: WARNING - ${errorMessage} Proceeding with text-only protocol.`]);
    }
  };

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const userMsg = `[CANDIDATE]: ${userInput}`;
    setTranscript(prev => [...prev, userMsg]);
    setUserInput('');
    setIsAITyping(true);

    // Get AI Response (Hybrid Strategy)
    const response = await geminiService.generateResponse(userInput, 'INTERROGATOR');
    setIsAITyping(false);
    setTranscript(prev => [...prev, `[AI_AGENT]: ${response}`]);

    // Move to next question or finish
    if (currentQuestionIndex < questions.length - 1) {
      const nextIndex = currentQuestionIndex + 1;
      setCurrentQuestionIndex(nextIndex);
      setTimeout(() => {
        setTranscript(prev => [...prev, `[SYSTEM]: Transitioning to next strategic node...`]);
        setTimeout(() => {
          setTranscript(prev => [...prev, `[AI_AGENT]: ${questions[nextIndex].text}`]);
        }, 1000);
      }, 2000);
    } else {
      setTimeout(() => {
        finishInterview();
      }, 2000);
    }
  };

  const finishInterview = async () => {
    setStatus('SUBMITTING');
    try {
      const result = await evaluationService.calculateSynthesisIndex(transcript.join('\n'));
      setEvaluation(result);
      setStatus('REPORTING');
    } catch (error) {
      console.error("Evaluation failed:", error);
      // Handle error appropriately, maybe set a default error state
      setStatus('REPORTING'); // Proceed to report even on error for now
    }
  };

  const generatePDF = async () => {
    if (!certificateRef.current || !evaluation) return;
    
    setIsGeneratingPDF(true);
    try {
      // Temporarily show the certificate for capture
      certificateRef.current.style.display = 'block';
      
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2,
        backgroundColor: '#050505',
        logging: false,
        useCORS: true
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'px',
        format: [canvas.width, canvas.height]
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`MISSION_CLEARANCE_${candidateName.replace(/\s+/g, '_').toUpperCase()}.pdf`);
      
      certificateRef.current.style.display = 'none';
    } catch (error) {
      console.error("PDF Generation failed:", error);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  return (
    <div className="min-h-screen bg-evalion-bg text-evalion-text p-6 pt-24 font-mono">
      {/* Hidden Certificate for PDF Generation */}
      {evaluation && (
        <MissionCertificate 
          ref={certificateRef}
          candidateName={candidateName}
          role="Senior Fullstack Architect"
          synthesisIndex={evaluation.synthesisIndex}
          date={new Date().toLocaleDateString()}
          signature={evaluation.signature}
          benchmarks={evaluation.technicalBenchmarks}
        />
      )}

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Panel: Tactical Feed */}
        <div className="lg:col-span-3 space-y-6">
          <div className="glass-panel p-4 rounded-2xl border-evalion-teal/20 relative overflow-hidden aspect-video bg-black">
            <div className="absolute top-2 left-2 z-10 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-evalion-danger animate-pulse"></div>
              <span className="text-[10px] text-evalion-danger font-bold tracking-widest">LIVE_FEED_SECURED</span>
            </div>
            <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover opacity-60 grayscale" />
            <div className="absolute inset-0 pointer-events-none border-[20px] border-transparent border-t-evalion-teal/5 border-l-evalion-teal/5"></div>
            {!cameraActive && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Camera className="text-evalion-textDim/20" size={48} />
              </div>
            )}
          </div>

          <div className="glass-panel p-6 rounded-2xl border-evalion-purple/20">
            <h3 className="text-[10px] text-evalion-purple font-bold tracking-[0.3em] mb-4 uppercase flex items-center gap-2">
              <Activity size={14} /> BIOMETRIC_STABILITY
            </h3>
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between text-[10px]">
                  <span>COGNITIVE_LOAD</span>
                  <span className="text-evalion-teal">68%</span>
                </div>
                <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div className="h-full bg-evalion-teal" initial={{ width: 0 }} animate={{ width: '68%' }} />
                </div>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-[10px]">
                  <span>STRESS_INDEX</span>
                  <span className="text-evalion-purple">42%</span>
                </div>
                <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div className="h-full bg-evalion-purple" initial={{ width: 0 }} animate={{ width: '42%' }} />
                </div>
              </div>
            </div>
          </div>

          {/* Collaboration Panel Integrated */}
          <div className="h-[400px]">
            <CollaborationPanel />
          </div>
        </div>

        {/* Right Panel: Main Interface */}
        <div className="lg:col-span-9">
          <AnimatePresence mode="wait">
            {status === 'IDLE' && (
              <motion.div 
                key="idle"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="h-full flex flex-col items-center justify-center text-center space-y-8 glass-panel rounded-3xl p-12 border-white/5"
              >
                <div className="w-24 h-24 rounded-full border border-evalion-teal/20 flex items-center justify-center relative">
                  <div className="absolute inset-0 rounded-full border border-evalion-teal/40 animate-ping opacity-20"></div>
                  <Cpu className="text-evalion-teal" size={40} />
                </div>
                <div className="space-y-6 w-full max-w-sm">
                  <div className="space-y-2">
                    <h2 className="text-3xl font-bold tracking-tighter text-white">READY FOR EVALUATION?</h2>
                    <p className="text-evalion-textDim text-sm leading-relaxed">
                      Initialize your neural profile to begin the tactical assessment.
                    </p>
                  </div>
                  <div className="space-y-2 text-left">
                    <label className="text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">CANDIDATE_IDENTIFIER</label>
                    <input 
                      type="text"
                      value={candidateName}
                      onChange={(e) => setCandidateName(e.target.value)}
                      className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-xs focus:outline-none focus:border-evalion-teal transition-all text-white font-mono"
                      placeholder="ENTER NAME..."
                    />
                  </div>
                </div>
                <button 
                  onClick={startInterview}
                  className="px-12 py-4 bg-evalion-teal text-black font-bold text-xs tracking-[0.3em] rounded-xl hover:bg-evalion-teal/90 transition-all shadow-[0_0_30px_rgba(0,240,255,0.3)]"
                >
                  INITIALIZE_SESSION
                </button>
              </motion.div>
            )}

            {status === 'SYNCING' && (
              <motion.div 
                key="syncing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col items-center justify-center glass-panel rounded-3xl p-12"
              >
                <CyberLoading 
                  label="NEURAL_SYNC_PROTOCOL" 
                  subLabel="ALIGNING_BACKGROUND_SERVICES..." 
                />
              </motion.div>
            )}

            {(status === 'ACTIVE' || status === 'SUBMITTING') && (
              <motion.div 
                key="active"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col glass-panel rounded-3xl overflow-hidden border-white/5"
              >
                {/* Chat Header */}
                <div className="p-6 border-b border-white/5 bg-white/[0.02] flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-evalion-teal/10 border border-evalion-teal/30 flex items-center justify-center">
                      <Terminal size={20} className="text-evalion-teal" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white tracking-widest uppercase">{candidateName} // TACTICAL_TERMINAL</h3>
                      <p className="text-[9px] text-evalion-teal/50 font-mono">SESSION_ID: SESS_ACTIVE_01</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-evalion-success/10 border border-evalion-success/30">
                    <div className="w-1.5 h-1.5 rounded-full bg-evalion-success animate-pulse"></div>
                    <span className="text-[9px] text-evalion-success font-bold">SECURE_CHANNEL</span>
                  </div>
                </div>

                {/* Chat Messages */}
                <div className="flex-grow p-6 overflow-y-auto space-y-6 custom-scrollbar min-h-[400px]">
                  {transcript.map((msg, idx) => (
                    <motion.div 
                      key={idx}
                      initial={{ opacity: 0, x: msg.startsWith('[CANDIDATE]') ? 20 : -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className={`flex ${msg.startsWith('[CANDIDATE]') ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-[80%] p-4 rounded-2xl text-xs leading-relaxed ${
                        msg.startsWith('[CANDIDATE]') 
                          ? 'bg-evalion-purple/10 border border-evalion-purple/30 text-white' 
                          : msg.startsWith('[SYSTEM]')
                          ? 'bg-white/5 border border-white/10 text-evalion-teal italic'
                          : 'bg-white/5 border border-white/10 text-evalion-textDim'
                      }`}>
                        {msg.split(': ')[1]}
                      </div>
                    </motion.div>
                  ))}
                  {isAITyping && (
                    <div className="flex justify-start">
                      <div className="bg-white/5 border border-white/10 p-4 rounded-2xl">
                        <Loader2 className="animate-spin text-evalion-teal" size={16} />
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                {/* Chat Input */}
                <div className="p-6 border-t border-white/5 bg-white/[0.02]">
                  <div className="relative">
                    <input 
                      type="text"
                      value={userInput}
                      onChange={(e) => setUserInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="ENTER_RESPONSE_HERE..."
                      disabled={status === 'SUBMITTING'}
                      className="w-full bg-black/50 border border-white/10 rounded-xl px-6 py-4 text-xs focus:outline-none focus:border-evalion-teal transition-all pr-16"
                    />
                    <button 
                      onClick={handleSendMessage}
                      disabled={status === 'SUBMITTING'}
                      className="absolute right-2 top-2 bottom-2 px-4 bg-evalion-teal text-black rounded-lg hover:bg-evalion-teal/90 transition-all flex items-center justify-center"
                    >
                      <Send size={16} />
                    </button>
                  </div>
                </div>

                {status === 'SUBMITTING' && (
                  <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center z-50">
                    <CyberLoading 
                      label="FINALIZING_EVALUATION" 
                      subLabel="RUNNING_PROTOCOL_0x99_DELTA..." 
                    />
                  </div>
                )}
              </motion.div>
            )}

            {status === 'REPORTING' && evaluation && (
              <motion.div 
                key="reporting"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="h-full glass-panel rounded-3xl p-12 border-evalion-teal/20 space-y-12"
              >
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <h2 className="text-4xl font-bold tracking-tighter text-white uppercase">MISSION_CLEARANCE</h2>
                    <p className="text-evalion-teal font-mono text-xs tracking-[0.3em]">{evaluation.protocolStatus}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-[40px] font-bold text-evalion-teal leading-none">{evaluation.synthesisIndex}</div>
                    <div className="text-[10px] text-evalion-textDim tracking-widest uppercase">SYNTHESIS_INDEX</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {Object.entries(evaluation.technicalBenchmarks).map(([key, val]) => (
                    <div key={key} className="p-6 rounded-2xl bg-white/5 border border-white/10 text-center space-y-2">
                      <div className="text-[10px] text-evalion-textDim uppercase tracking-widest">{key}</div>
                      <div className="text-2xl font-bold text-white">{val}%</div>
                    </div>
                  ))}
                </div>

                <div className="p-8 rounded-3xl bg-evalion-teal/5 border border-evalion-teal/20 relative overflow-hidden">
                  <div className="relative z-10 space-y-4">
                    <div className="flex items-center gap-3 text-evalion-teal">
                      <CheckCircle2 size={20} />
                      <h4 className="font-bold tracking-widest text-sm uppercase">VERIFICATION_COMPLETE</h4>
                    </div>
                    <p className="text-xs text-evalion-textDim leading-relaxed">
                      Candidate {candidateName} has successfully cleared the tactical evaluation protocol. Technical depth in distributed systems and zero-trust architecture is verified. Synthesis Index indicates top performance.
                    </p>
                    <div className="pt-4 flex justify-between items-end border-t border-evalion-teal/10">
                      <div className="space-y-1">
                        <p className="text-[8px] text-evalion-textDim uppercase tracking-widest">VALIDATION_SIGNATURE</p>
                        <p className="text-[10px] font-bold text-white font-mono">{evaluation.signature}</p>
                      </div>
                      <button 
                        onClick={generatePDF}
                        disabled={isGeneratingPDF}
                        className="px-6 py-2 bg-white text-black text-[10px] font-bold tracking-widest rounded-lg hover:bg-gray-200 transition-all flex items-center gap-2 disabled:opacity-50"
                      >
                        {isGeneratingPDF ? <Loader2 size={12} className="animate-spin" /> : <Download size={12} />}
                        GENERATE_CERTIFICATE (PDF)
                      </button>
                    </div>
                  </div>
                  <div className="absolute top-0 right-0 p-4 opacity-10">
                    <Shield size={120} />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
