import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Brain, Activity, User, Shield, Target, Zap, TrendingUp, BarChart3, Loader2 } from 'lucide-react';

export const NeuralProfilingPage = () => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [profile, setProfile] = useState<any | null>(null);

  const startAnalysis = () => {
    setIsAnalyzing(true);
    setProfile(null);
    setTimeout(() => {
      setIsAnalyzing(false);
      setProfile({
        traits: [
          { label: 'PROBLEM_SOLVING', value: 92, color: 'evalion-teal' },
          { label: 'STRESS_RESILIENCE', value: 78, color: 'evalion-purple' },
          { label: 'ADAPTABILITY', value: 85, color: 'evalion-teal' },
          { label: 'COLLABORATION', value: 64, color: 'evalion-purple' }
        ],
        tacticalProfile: "Candidate exhibits high analytical depth under pressure. Problem-solving approach is systematic and logic-driven. Resilience is strong, though collaborative patterns suggest a preference for autonomous execution.",
        recommendation: "HIGH_POTENTIAL_LEAD"
      });
    }, 2500);
  };

  return (
    <div className="min-h-screen bg-evalion-bg text-evalion-text p-6 pt-24 font-mono">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-end gap-8">
          <div className="space-y-4">
            <h3 className="text-evalion-purple font-mono text-[10px] tracking-[0.5em] uppercase opacity-60">
              [ BEHAVIORAL_PATTERN_ANALYSIS ]
            </h3>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tighter text-white uppercase">
              NEURAL_PROFILING
            </h2>
            <p className="max-w-xl text-evalion-textDim text-xs leading-relaxed tracking-wider">
              Create a Tactical Profile of candidates by analyzing behavioral patterns during high-pressure technical evaluations. We look beyond the answers to how they solve problems.
            </p>
          </div>
          <button 
            onClick={startAnalysis}
            disabled={isAnalyzing}
            className="px-10 py-4 bg-evalion-purple text-white font-bold text-xs tracking-[0.3em] rounded-xl hover:bg-evalion-purple/90 transition-all shadow-[0_0_30px_rgba(139,92,246,0.3)] disabled:opacity-50"
          >
            {isAnalyzing ? 'ANALYZING_PATTERNS' : 'GENERATE_TACTICAL_PROFILE'}
          </button>
        </div>

        {/* Main Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Neural Visualization */}
          <div className="lg:col-span-5 glass-panel rounded-3xl p-8 border-white/5 flex flex-col items-center justify-center min-h-[400px]">
            {isAnalyzing ? (
              <div className="relative">
                <Brain className="text-evalion-purple animate-pulse" size={120} />
                <motion.div 
                  className="absolute inset-0 border-2 border-evalion-purple/30 rounded-full"
                  animate={{ scale: [1, 1.5], opacity: [0.5, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </div>
            ) : profile ? (
              <div className="w-full space-y-8">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-16 h-16 rounded-full bg-evalion-purple/10 border border-evalion-purple/30 flex items-center justify-center">
                    <User className="text-evalion-purple" size={32} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white uppercase tracking-widest">CANDIDATE_NODE_0x1</h3>
                    <p className="text-[10px] text-evalion-purple font-bold tracking-[0.3em]">PROFILE_VERIFIED</p>
                  </div>
                </div>
                <div className="space-y-6">
                  {profile.traits.map((trait: any) => (
                    <div key={trait.label} className="space-y-2">
                      <div className="flex justify-between text-[10px] tracking-widest uppercase">
                        <span>{trait.label}</span>
                        <span className={`text-${trait.color}`}>{trait.value}%</span>
                      </div>
                      <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          className={`h-full bg-${trait.color}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${trait.value}%` }}
                          transition={{ duration: 1, delay: 0.2 }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4 opacity-20">
                <Brain size={64} className="mx-auto" />
                <p className="text-xs tracking-[0.3em]">AWAITING_DATA_INPUT</p>
              </div>
            )}
          </div>

          {/* Right: Tactical Analysis */}
          <div className="lg:col-span-7 space-y-6">
            <div className="glass-panel rounded-3xl p-8 border-white/5 h-full space-y-8">
              <div className="flex items-center gap-3">
                <Shield size={20} className="text-evalion-purple" />
                <h3 className="text-sm font-bold tracking-widest text-white uppercase">TACTICAL_ANALYSIS_REPORT</h3>
              </div>
              
              {isAnalyzing ? (
                <div className="space-y-4">
                  <div className="h-4 w-3/4 bg-white/5 rounded animate-pulse"></div>
                  <div className="h-4 w-full bg-white/5 rounded animate-pulse"></div>
                  <div className="h-4 w-5/6 bg-white/5 rounded animate-pulse"></div>
                </div>
              ) : profile ? (
                <div className="space-y-8">
                  <p className="text-sm text-evalion-textDim leading-relaxed font-mono italic">
                    "{profile.tacticalProfile}"
                  </p>
                  
                  <div className="grid grid-cols-2 gap-6">
                    <div className="p-4 rounded-xl bg-evalion-teal/5 border border-evalion-teal/20 space-y-2">
                      <div className="flex items-center gap-2 text-evalion-teal">
                        <Target size={14} />
                        <span className="text-[10px] font-bold tracking-widest uppercase">CORE_STRENGTH</span>
                      </div>
                      <p className="text-[10px] text-white/70">SYSTEMATIC_LOGIC</p>
                    </div>
                    <div className="p-4 rounded-xl bg-evalion-purple/5 border border-evalion-purple/20 space-y-2">
                      <div className="flex items-center gap-2 text-evalion-purple">
                        <Zap size={14} />
                        <span className="text-[10px] font-bold tracking-widest uppercase">REACTION_SPEED</span>
                      </div>
                      <p className="text-[10px] text-white/70">OPTIMIZED_42ms</p>
                    </div>
                  </div>

                  <div className="pt-8 border-t border-white/5 flex justify-between items-center">
                    <div className="space-y-1">
                      <p className="text-[8px] text-evalion-textDim uppercase tracking-widest">FINAL_RECOMMENDATION</p>
                      <p className="text-sm font-bold text-evalion-teal tracking-widest">{profile.recommendation}</p>
                    </div>
                    <div className="flex gap-2">
                      <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                        <TrendingUp size={16} className="text-evalion-teal" />
                      </div>
                      <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                        <BarChart3 size={16} className="text-evalion-purple" />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-[10px] text-evalion-textDim italic">Initialize analysis to generate tactical profile.</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom: Methodology */}
        <div className="p-8 rounded-3xl bg-white/[0.02] border border-white/5">
          <h4 className="text-xs font-bold tracking-widest uppercase mb-6 flex items-center gap-2">
            <Activity size={16} className="text-evalion-teal" /> ANALYSIS_METHODOLOGY
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-white">MICRO_EXPRESSIONS</p>
              <p className="text-[9px] text-evalion-textDim leading-relaxed">Analyzing subtle facial cues for stress and confidence markers.</p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-white">SPEECH_CADENCE</p>
              <p className="text-[9px] text-evalion-textDim leading-relaxed">Monitoring verbal flow and pause patterns for cognitive load assessment.</p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-white">LOGIC_CONSISTENCY</p>
              <p className="text-[9px] text-evalion-textDim leading-relaxed">Cross-referencing answers for structural and logical alignment.</p>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-white">REACTION_TIME</p>
              <p className="text-[9px] text-evalion-textDim leading-relaxed">Measuring latency between challenge presentation and initial response.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
