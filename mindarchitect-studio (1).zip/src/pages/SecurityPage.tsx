import React from 'react';

export const SecurityPage = () => (
  <div className="max-w-4xl mx-auto px-6 py-32 text-evalion-textDim">
    <h1 className="text-4xl font-bold text-white mb-8">Security</h1>
    <div className="prose prose-invert prose-sm font-light leading-relaxed tracking-wide">
      <p>Last Updated: October 26, 2023</p>
      <p>MindArchitect Studio is committed to ensuring the security of your data. We employ a range of technologies and policies to protect your information from unauthorized access, use, or disclosure.</p>
      <h2 className="text-white">1. Data Encryption</h2>
      <p>All data transmitted between your browser and our servers is encrypted in transit using TLS 1.2+. Data at rest in our databases is encrypted using AES-256.</p>
      <h2 className="text-white">2. Biometric Security (WebAuthn)</h2>
      <p>We use the FIDO2/WebAuthn standard for biometric authentication. This is a phishing-resistant, passwordless technology. Your biometric data (e.g., fingerprint) never leaves your device. Instead, a unique cryptographic key pair is generated. The private key is stored securely on your device's hardware (like a TPM or Secure Enclave), and we only store the public key.</p>
      <h2 className="text-white">3. Access Control</h2>
      <p>Access to sensitive data is strictly limited to authorized personnel. We use role-based access control (RBAC) to ensure that employees only have access to the information necessary to perform their job functions.</p>
      <h2 className="text-white">4. Responsible Disclosure</h2>
      <p>If you believe you have found a security vulnerability in our platform, please contact us immediately at security@mindarchitect.studio. We will investigate all reports and do our best to quickly resolve any issues.</p>
    </div>
  </div>
);
