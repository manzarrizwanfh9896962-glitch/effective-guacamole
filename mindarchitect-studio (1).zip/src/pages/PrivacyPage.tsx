import React from 'react';

export const PrivacyPage = () => (
  <div className="max-w-4xl mx-auto px-6 py-32 text-evalion-textDim">
    <h1 className="text-4xl font-bold text-white mb-8">Privacy Policy</h1>
    <div className="prose prose-invert prose-sm font-light leading-relaxed tracking-wide">
      <p>Last Updated: October 26, 2023</p>
      <p>Your privacy is important to us. It is MindArchitect Studio's policy to respect your privacy regarding any information we may collect from you across our website, https://mindarchitect.studio, and other sites we own and operate.</p>
      <h2 className="text-white">1. Information We Collect</h2>
      <p>We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used.</p>
      <h3 className="text-white">Biometric & Interview Data (GDPR/CCPA)</h3>
      <p>For our AI-powered interview and security services, we may collect the following sensitive data:</p>
      <ul>
        <li><strong>Biometric Identifiers:</strong> This includes data from facial scans or fingerprints used for our WebAuthn secure login. This data is converted into a secure credential and stored on your device. We only store a cryptographic public key, not the raw biometric data.</li>
        <li><strong>Voice and Video Recordings:</strong> Simulated interviews may be recorded for analysis and feedback. You will be explicitly asked for consent before any recording begins.</li>
      </ul>
      <p>Under GDPR and CCPA, you have the right to access, rectify, or erase this data. Please contact us to make a request.</p>
      <h2 className="text-white">2. How We Use Your Information</h2>
      <p>We use the information we collect in various ways, including to:</p>
      <ul>
        <li>Provide, operate, and maintain our website</li>
        <li>Improve, personalize, and expand our website</li>
        <li>Understand and analyze how you use our website</li>
        <li>Develop new products, services, features, and functionality</li>
        <li>Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the website, and for marketing and promotional purposes</li>
        <li>Send you emails</li>
        <li>Find and prevent fraud</li>
      </ul>
    </div>
  </div>
);
