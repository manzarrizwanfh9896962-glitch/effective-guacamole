import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Users, Activity, Brain, Shield, ArrowLeft, Terminal, Cpu, Clock, CheckCircle2, AlertTriangle } from 'lucide-react';

interface Candidate {
  id: string;
  name: string;
  role: string;
  status: string;
  score: number;
  id_code: string;
  metrics: {
    algorithmic: number;
    systemDesign: number;
    communication: number;
  };
  transcript: {
    time: string;
    speaker: string;
    text: string;
    verification?: string;
  }[];
  biometrics: {
    stressLevel: number;
    cognitiveLoad: number;
    focusScore: number;
  };
  feedback: string;
}

export const CandidateProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [candidate, setCandidate] = useState<Candidate | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCandidate = async () => {
      try {
        const token = localStorage.getItem('mindarchitect_token');
        const response = await fetch(`/api/candidates/${id}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (!response.ok) {
          throw new Error('Candidate not found');
        }

        const data = await response.json();
        setCandidate(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchCandidate();
    }
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-evalion-bg flex items-center justify-center">
        <div className="text-evalion-teal animate-pulse font-mono">LOADING_PROFILE_DATA...</div>
      </div>
    );
  }

  if (error || !candidate) {
    return (
      <div className="min-h-screen bg-evalion-bg flex flex-col items-center justify-center gap-4 text-evalion-danger">
        <AlertTriangle size={48} />
        <div className="font-mono text-xl">ERROR: {error || 'PROFILE_NOT_FOUND'}</div>
        <button 
          onClick={() => navigate('/dashboard')}
          className="px-6 py-2 border border-evalion-danger/30 text-evalion-danger hover:bg-evalion-danger/10 rounded font-mono text-xs tracking-widest"
        >
          RETURN_TO_DASHBOARD
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-evalion-bg text-evalion-text p-6 pt-24 font-mono">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate('/dashboard')}
            className="p-2 rounded-full border border-white/10 hover:bg-white/5 transition-colors text-evalion-textDim hover:text-white"
          >
            <ArrowLeft size={20} />
          </button>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-white tracking-tight uppercase">{candidate.name}</h1>
              <span className={`px-3 py-1 rounded-full text-[10px] font-bold tracking-widest border ${
                candidate.status === 'COMPLETED' ? 'bg-evalion-success/10 text-evalion-success border-evalion-success/30' : 
                candidate.status === 'IN_PROGRESS' ? 'bg-evalion-teal/10 text-evalion-teal border-evalion-teal/30' :
                'bg-evalion-danger/10 text-evalion-danger border-evalion-danger/30'
              }`}>
                {candidate.status}
              </span>
            </div>
            <p className="text-evalion-textDim text-sm mt-1 flex items-center gap-2">
              <span className="text-evalion-purple">{candidate.id_code.toUpperCase()}</span> // {candidate.role}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Metrics & Biometrics */}
          <div className="space-y-6">
            {/* Overall Score */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10">
                <Activity size={100} />
              </div>
              <h3 className="text-xs font-bold text-evalion-textDim tracking-widest uppercase mb-4">SYNTHESIS_INDEX</h3>
              <div className="flex items-end gap-2">
                <span className="text-6xl font-bold text-white">{candidate.score}</span>
                <span className="text-xl text-evalion-textDim mb-2">/100</span>
              </div>
              <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${candidate.score}%` }}
                  className="h-full bg-gradient-to-r from-evalion-teal to-evalion-purple"
                />
              </div>
            </div>

            {/* Technical Metrics */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5">
              <h3 className="text-xs font-bold text-evalion-textDim tracking-widest uppercase mb-6 flex items-center gap-2">
                <Cpu size={14} /> TECHNICAL_BENCHMARKS
              </h3>
              <div className="space-y-4">
                {Object.entries(candidate.metrics).map(([key, value]) => (
                  <div key={key} className="space-y-1">
                    <div className="flex justify-between text-[10px] uppercase tracking-wider">
                      <span>{key}</span>
                      <span className="text-white">{value}%</span>
                    </div>
                    <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${value}%` }}
                        className="h-full bg-evalion-teal"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Biometrics */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5">
              <h3 className="text-xs font-bold text-evalion-textDim tracking-widest uppercase mb-6 flex items-center gap-2">
                <Brain size={14} /> BIOMETRIC_STABILITY
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 bg-white/5 rounded-xl border border-white/5">
                  <div className="text-2xl font-bold text-evalion-purple">{candidate.biometrics.stressLevel}%</div>
                  <div className="text-[8px] text-evalion-textDim mt-1 uppercase">STRESS</div>
                </div>
                <div className="text-center p-3 bg-white/5 rounded-xl border border-white/5">
                  <div className="text-2xl font-bold text-evalion-teal">{candidate.biometrics.cognitiveLoad}%</div>
                  <div className="text-[8px] text-evalion-textDim mt-1 uppercase">LOAD</div>
                </div>
                <div className="text-center p-3 bg-white/5 rounded-xl border border-white/5">
                  <div className="text-2xl font-bold text-white">{candidate.biometrics.focusScore}%</div>
                  <div className="text-[8px] text-evalion-textDim mt-1 uppercase">FOCUS</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Transcript & Feedback */}
          <div className="lg:col-span-2 space-y-6">
            {/* Feedback Summary */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5">
              <h3 className="text-xs font-bold text-evalion-textDim tracking-widest uppercase mb-4 flex items-center gap-2">
                <Shield size={14} /> ARCHITECTURAL_ASSESSMENT
              </h3>
              <p className="text-sm leading-relaxed text-white/80 border-l-2 border-evalion-teal pl-4 italic">
                "{candidate.feedback}"
              </p>
            </div>

            {/* Transcript */}
            <div className="glass-panel p-6 rounded-2xl border border-white/5 flex-grow min-h-[400px]">
              <h3 className="text-xs font-bold text-evalion-textDim tracking-widest uppercase mb-6 flex items-center gap-2">
                <Terminal size={14} /> NEURAL_TRANSCRIPT_LOG
              </h3>
              <div className="space-y-6">
                {candidate.transcript.map((entry, idx) => (
                  <div key={idx} className="flex gap-4 group">
                    <div className="text-[10px] font-mono text-evalion-textDim w-16 shrink-0 pt-1">
                      {entry.time}
                    </div>
                    <div className="space-y-2 flex-grow">
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-bold tracking-wider uppercase ${
                          entry.speaker === 'AI_AGENT' ? 'text-evalion-teal' : 'text-evalion-purple'
                        }`}>
                          {entry.speaker}
                        </span>
                        {entry.verification && (
                          <span className="px-2 py-0.5 rounded bg-evalion-success/10 border border-evalion-success/20 text-[8px] text-evalion-success font-bold flex items-center gap-1">
                            <CheckCircle2 size={8} /> {entry.verification}
                          </span>
                        )}
                      </div>
                      <p className={`text-sm leading-relaxed ${
                        entry.speaker === 'AI_AGENT' ? 'text-evalion-textDim' : 'text-white'
                      }`}>
                        {entry.text}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
