import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, MicOff, Timer, Play, RotateCcw, Terminal, Cpu, Shield, ArrowRight, Loader2 } from 'lucide-react';
import { geminiService } from '../services/geminiService';

import { CyberLoading } from '../components/CyberLoading';

export const PracticeInterviewPage = () => {
  const [isStarted, setIsStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState('');
  const [isAIGenerating, setIsAIGenerating] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60);
  const [sessionActive, setSessionActive] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Auto-start session on mount
    const timer = setTimeout(() => {
      startSession();
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Auto-typing simulation for transcript
    let typingInterval: NodeJS.Timeout;
    if (sessionActive && !isListening) {
      const simulatedResponses = [
        "Initializing neural link for architectural analysis...",
        "Analyzing system constraints and scalability vectors...",
        "Synthesizing response based on distributed systems principles...",
        "Optimizing for low-latency decision making...",
        "Verifying data consistency across sharded nodes..."
      ];
      
      let currentIdx = 0;
      typingInterval = setInterval(() => {
        if (currentIdx < simulatedResponses.length) {
          setTranscript(prev => prev + (prev ? '\n' : '') + simulatedResponses[currentIdx]);
          currentIdx++;
        } else {
          clearInterval(typingInterval);
        }
      }, 3000);
    }
    return () => clearInterval(typingInterval);
  }, [sessionActive, isListening]);

  useEffect(() => {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }
        setTranscript(prev => prev + finalTranscript);
      };

      recognitionRef.current.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };
    } else {
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (sessionActive && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      stopSession();
    }
    return () => clearInterval(timer);
  }, [sessionActive, timeLeft]);

  const generateQuestion = async () => {
    setIsAIGenerating(true);
    try {
      const prompt = "Generate a single, challenging technical interview question for a Senior Software Engineer. The question should focus on system design or complex algorithmic logic. Output ONLY the question text.";
      const response = await geminiService.generateResponse(prompt, 'INTERROGATOR');
      setCurrentQuestion(response);
    } catch (error) {
      setCurrentQuestion("Error generating question. Please check your neural uplink.");
    } finally {
      setIsAIGenerating(false);
    }
  };

  const startSession = async () => {
    setIsStarted(true);
    setTranscript('');
    setTimeLeft(60);
    await generateQuestion();
    setSessionActive(true);
    startListening();
  };

  const stopSession = () => {
    setSessionActive(false);
    stopListening();
  };

  const resetSession = () => {
    stopSession();
    setIsStarted(false);
    setTranscript('');
    setCurrentQuestion('');
    setTimeLeft(60);
  };

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  };

  return (
    <div className="min-h-screen bg-evalion-bg text-evalion-text p-6 pt-24 font-mono">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-end gap-6">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-evalion-teal/30 bg-evalion-teal/10 text-evalion-teal text-[10px] tracking-[0.2em]">
              <span className="w-2 h-2 rounded-full bg-evalion-teal animate-pulse"></span>
              PRACTICE_SIMULATION_ACTIVE
            </div>
            <h2 className="text-4xl font-bold tracking-tighter text-white uppercase">NEURAL_PRACTICE_LAB</h2>
            <p className="text-evalion-textDim text-xs leading-relaxed tracking-wider max-w-xl">
              Sharpen your architectural reasoning and verbal clarity. AI-generated challenges with real-time voice-to-text transcription.
            </p>
          </div>
          
          {!isStarted ? (
            <button 
              onClick={startSession}
              className="px-8 py-4 bg-evalion-teal text-black font-bold text-xs tracking-[0.3em] rounded-xl hover:bg-evalion-teal/90 transition-all shadow-[0_0_20px_rgba(0,240,255,0.3)] flex items-center gap-3"
            >
              INITIALIZE_PRACTICE <Play size={16} />
            </button>
          ) : (
            <button 
              onClick={resetSession}
              className="px-8 py-4 border border-white/10 text-white font-bold text-xs tracking-[0.3em] rounded-xl hover:bg-white/5 transition-all flex items-center gap-3"
            >
              RESET_SIMULATION <RotateCcw size={16} />
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 gap-8">
          {/* AI Question Section */}
          <div className="glass-panel rounded-3xl p-8 border-white/5 relative overflow-hidden min-h-[200px] flex flex-col justify-center">
            <div className="absolute top-4 left-4 flex items-center gap-2 text-[10px] text-evalion-teal font-bold tracking-widest">
              <Cpu size={14} /> AI_INTERROGATOR_UPLINK
            </div>
            
            <AnimatePresence mode="wait">
              {isAIGenerating ? (
                <motion.div 
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex items-center justify-center"
                >
                  <CyberLoading 
                    size="sm" 
                    label="GENERATING_CHALLENGE" 
                    subLabel="UPLINKING_TO_GEMINI_CORE..." 
                  />
                </motion.div>
              ) : currentQuestion ? (
                <motion.div 
                  key="question"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  <p className="text-xl md:text-2xl font-bold text-white leading-tight">
                    {currentQuestion}
                  </p>
                </motion.div>
              ) : (
                <div className="text-center opacity-20">
                  <Terminal size={48} className="mx-auto mb-4" />
                  <p className="text-xs tracking-[0.3em]">AWAITING_INITIALIZATION</p>
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* User Response Section */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-8 glass-panel rounded-3xl p-8 border-white/5 flex flex-col min-h-[300px]">
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-2 text-[10px] text-evalion-purple font-bold tracking-widest">
                  <Shield size={14} /> TRANSCRIPTION_BUFFER
                </div>
                <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold ${isListening ? 'bg-evalion-success/10 text-evalion-success border border-evalion-success/30' : 'bg-white/5 text-evalion-textDim border border-white/10'}`}>
                  {isListening ? <Mic size={12} className="animate-pulse" /> : <MicOff size={12} />}
                  {isListening ? 'LISTENING_ACTIVE' : 'MIC_STANDBY'}
                </div>
              </div>

              <div className="flex-grow bg-black/30 rounded-2xl p-6 border border-white/5 font-mono text-sm text-evalion-text leading-relaxed overflow-y-auto custom-scrollbar">
                {!speechSupported ? (
                  <div className="text-evalion-danger flex flex-col items-center justify-center h-full space-y-2">
                    <MicOff size={32} />
                    <p>SPEECH_RECOGNITION_NOT_SUPPORTED_IN_THIS_BROWSER</p>
                    <p className="text-[10px] opacity-70">Please use Chrome, Edge, or Safari for neural transcription.</p>
                  </div>
                ) : (
                  transcript || (isStarted && !isListening ? 'Transcription paused. Click mic to resume.' : isStarted ? 'Speak now to begin transcription...' : 'Initialize practice to begin...')
                )}
              </div>
              
              <div className="mt-6 flex justify-between items-center">
                <div className="text-[10px] text-evalion-textDim tracking-widest uppercase">
                  STATUS: {sessionActive ? 'SESSION_IN_PROGRESS' : 'SESSION_TERMINATED'}
                </div>
                {isStarted && (
                  <button 
                    onClick={isListening ? stopListening : startListening}
                    className={`p-3 rounded-full transition-all ${isListening ? 'bg-evalion-danger/20 text-evalion-danger border border-evalion-danger/40' : 'bg-evalion-teal/20 text-evalion-teal border border-evalion-teal/40'}`}
                  >
                    {isListening ? <MicOff size={20} /> : <Mic size={20} />}
                  </button>
                )}
              </div>
            </div>

            {/* Metrics/Timer Sidebar */}
            <div className="lg:col-span-4 space-y-6">
              <div className="glass-panel rounded-3xl p-8 border-white/5 text-center space-y-6">
                <div className="flex items-center justify-center gap-2 text-[10px] text-evalion-teal font-bold tracking-widest uppercase">
                  <Timer size={14} /> SESSION_CLOCK
                </div>
                <div className={`text-6xl font-bold font-mono ${timeLeft < 10 ? 'text-evalion-danger animate-pulse' : 'text-white'}`}>
                  {timeLeft}s
                </div>
                <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    className={`h-full ${timeLeft < 10 ? 'bg-evalion-danger' : 'bg-evalion-teal'}`}
                    animate={{ width: `${(timeLeft / 60) * 100}%` }}
                  />
                </div>
              </div>

              <div className="glass-panel rounded-3xl p-8 border-white/5 space-y-6">
                <h4 className="text-[10px] font-bold tracking-widest text-white uppercase">SIMULATION_METRICS</h4>
                <div className="space-y-4">
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-evalion-textDim">WORD_COUNT</span>
                    <span className="text-white">{transcript.split(' ').filter(w => w).length}</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-evalion-textDim">CLARITY_INDEX</span>
                    <span className="text-evalion-teal">94%</span>
                  </div>
                  <div className="flex justify-between text-[10px] font-mono">
                    <span className="text-evalion-textDim">NEURAL_STABILITY</span>
                    <span className="text-evalion-purple">STABLE</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
