import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, 
  Users, 
  MapPin, 
  Hospital, 
  Building2, 
  Settings as SettingsIcon,
  Plus,
  Search,
  Filter,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ChevronRight,
  LayoutDashboard,
  CreditCard,
  History
} from 'lucide-react';
import { toast } from 'sonner';

interface DashboardStats {
  totalReceipts: number;
  totalPassports: number;
  pendingMedical: number;
  completedVisas: number;
}

export const PassportManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'receipts' | 'passports' | 'settings'>('dashboard');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/dashboard', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error fetching dashboard:', error);
      toast.error('FAILED TO SYNC DASHBOARD DATA');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="pb-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-2 h-2 rounded-full bg-evalion-teal animate-pulse" />
              <span className="text-[10px] font-mono tracking-[0.4em] text-evalion-teal uppercase">
                Secure Protocol Active
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold tracking-tighter text-white mb-2">
              PASSPORT <span className="text-evalion-teal">MANAGEMENT</span>
            </h1>
            <p className="text-evalion-textDim font-mono text-xs tracking-widest uppercase">
              Autonomous Talent Logistics & Documentation
            </p>
          </div>

          <div className="flex items-center gap-2 p-1 bg-white/5 rounded-xl border border-white/5">
            {[
              { id: 'dashboard', icon: LayoutDashboard, label: 'CORE' },
              { id: 'receipts', icon: FileText, label: 'RECEIPTS' },
              { id: 'passports', icon: CreditCard, label: 'PASSPORTS' },
              { id: 'settings', icon: SettingsIcon, label: 'CONFIG' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-[10px] font-mono tracking-widest transition-all ${
                  activeTab === tab.id 
                    ? 'bg-evalion-teal text-black shadow-[0_0_20px_rgba(0,240,255,0.3)]' 
                    : 'text-white/50 hover:text-white hover:bg-white/5'
                }`}
              >
                <tab.icon size={14} />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            >
              {/* Stats Cards */}
              {[
                { label: 'TOTAL RECEIPTS', value: stats?.totalReceipts || 0, icon: FileText, color: 'teal' },
                { label: 'ACTIVE PASSPORTS', value: stats?.totalPassports || 0, icon: CreditCard, color: 'purple' },
                { label: 'PENDING MEDICAL', value: stats?.pendingMedical || 0, icon: Hospital, color: 'danger' },
                { label: 'COMPLETED VISAS', value: stats?.completedVisas || 0, icon: CheckCircle2, color: 'success' }
              ].map((stat, i) => (
                <div key={i} className="glass-panel p-8 rounded-3xl relative overflow-hidden group">
                  <div className={`absolute top-0 right-0 w-32 h-32 bg-evalion-${stat.color}/5 rounded-full -mr-16 -mt-16 blur-3xl group-hover:bg-evalion-${stat.color}/10 transition-all`} />
                  <div className="flex items-start justify-between mb-8">
                    <div className={`p-3 rounded-2xl bg-evalion-${stat.color}Dim border border-evalion-${stat.color}/20 text-evalion-${stat.color}`}>
                      <stat.icon size={20} />
                    </div>
                    <div className="text-[10px] font-mono text-evalion-textDim tracking-widest">
                      0{i + 1}
                    </div>
                  </div>
                  <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                  <div className="text-[10px] font-mono text-evalion-textDim tracking-[0.2em] uppercase">
                    {stat.label}
                  </div>
                </div>
              ))}

              {/* Recent Activity / Quick Actions */}
              <div className="md:col-span-2 lg:col-span-3 glass-panel p-8 rounded-3xl">
                <div className="flex items-center justify-between mb-8">
                  <h3 className="text-lg font-bold tracking-tight text-white flex items-center gap-3">
                    <History size={18} className="text-evalion-teal" />
                    RECENT LOGISTICS
                  </h3>
                  <button className="text-[10px] font-mono text-evalion-teal tracking-widest flex items-center gap-2 hover:underline">
                    VIEW ALL <ChevronRight size={12} />
                  </button>
                </div>
                
                <div className="space-y-4">
                  {isLoading ? (
                    <div className="flex flex-col items-center justify-center py-20 gap-4">
                      <Loader2 className="animate-spin text-evalion-teal" size={32} />
                      <span className="text-[10px] font-mono text-evalion-textDim tracking-widest">SYNCHRONIZING...</span>
                    </div>
                  ) : (
                    [1, 2, 3, 4].map((_, i) => (
                      <div key={i} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-white/10 transition-all group cursor-pointer">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-[#0A0A0A] border border-white/5 flex items-center justify-center text-evalion-teal">
                            <FileText size={18} />
                          </div>
                          <div>
                            <div className="text-sm font-bold text-white mb-1">RECEIPT #REC-2024-00{i + 1}</div>
                            <div className="text-[10px] font-mono text-evalion-textDim tracking-wider">PROCESSED BY SYSTEM_ARCHITECT</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right hidden sm:block">
                            <div className="text-[10px] font-mono text-white mb-1">MAR 27, 2026</div>
                            <div className="text-[9px] font-mono text-evalion-success tracking-widest uppercase">VERIFIED</div>
                          </div>
                          <ChevronRight size={16} className="text-white/20 group-hover:text-evalion-teal transition-colors" />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Quick Config */}
              <div className="glass-panel p-8 rounded-3xl flex flex-col">
                <h3 className="text-lg font-bold tracking-tight text-white mb-8 flex items-center gap-3">
                  <Building2 size={18} className="text-evalion-purple" />
                  ENTITIES
                </h3>
                <div className="space-y-3 flex-grow">
                  {[
                    { label: 'PARTIES', icon: Users },
                    { label: 'AGENTS', icon: Users },
                    { label: 'MEDICAL', icon: Hospital },
                    { label: 'EMBASSIES', icon: Building2 },
                    { label: 'CITIES', icon: MapPin }
                  ].map((item, i) => (
                    <button key={i} className="w-full flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 hover:bg-white/10 transition-all group">
                      <div className="flex items-center gap-3">
                        <item.icon size={14} className="text-evalion-textDim group-hover:text-evalion-teal" />
                        <span className="text-[10px] font-mono text-white tracking-widest">{item.label}</span>
                      </div>
                      <Plus size={14} className="text-white/20 group-hover:text-evalion-teal" />
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'receipts' && (
            <motion.div
              key="receipts"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="glass-panel p-8 rounded-3xl"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-10 gap-6">
                <h2 className="text-2xl font-bold text-white tracking-tight">RECEIPT REGISTRY</h2>
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" size={16} />
                    <input 
                      type="text" 
                      placeholder="SEARCH_FILE_NO..." 
                      className="bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 text-[10px] font-mono text-white focus:outline-none focus:border-evalion-teal/50 w-64"
                    />
                  </div>
                  <button className="bg-evalion-teal text-black px-6 py-2 rounded-xl text-[10px] font-mono font-bold tracking-widest flex items-center gap-2 hover:shadow-[0_0_20px_rgba(0,240,255,0.4)] transition-all">
                    <Plus size={16} /> NEW_RECEIPT
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b border-white/5">
                      <th className="text-left py-4 px-4 text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">File No</th>
                      <th className="text-left py-4 px-4 text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">Party</th>
                      <th className="text-left py-4 px-4 text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">Agent</th>
                      <th className="text-left py-4 px-4 text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">Date</th>
                      <th className="text-left py-4 px-4 text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">Status</th>
                      <th className="text-right py-4 px-4 text-[10px] font-mono text-evalion-textDim tracking-widest uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[1, 2, 3, 4, 5].map((_, i) => (
                      <tr key={i} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors group">
                        <td className="py-4 px-4">
                          <span className="text-sm font-bold text-white">REC-2024-00{i + 1}</span>
                        </td>
                        <td className="py-4 px-4">
                          <span className="text-xs text-evalion-textDim">GLOBAL TALENT CORP</span>
                        </td>
                        <td className="py-4 px-4">
                          <span className="text-xs text-evalion-textDim">AGENT_SMITH_0{i}</span>
                        </td>
                        <td className="py-4 px-4">
                          <span className="text-xs text-evalion-textDim">2026-03-27</span>
                        </td>
                        <td className="py-4 px-4">
                          <span className="px-2 py-1 rounded-md bg-evalion-successDim text-evalion-success text-[9px] font-mono tracking-widest uppercase border border-evalion-success/20">
                            ACTIVE
                          </span>
                        </td>
                        <td className="py-4 px-4 text-right">
                          <button className="p-2 rounded-lg hover:bg-white/5 text-white/30 hover:text-evalion-teal transition-all">
                            <ArrowRight size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
