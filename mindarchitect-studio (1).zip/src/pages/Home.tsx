import React from 'react';
import { Hero } from '../components/Hero';
import { Architecture } from '../components/Architecture';
import { SystemDebug } from '../components/SystemDebug';

interface HomeProps {
  onDeploy: () => void;
  onSimulate: () => void;
}

export const Home: React.FC<HomeProps> = ({ onDeploy, onSimulate }) => {
  return (
    <>
      <Hero onDeploy={onDeploy} onSimulate={onSimulate} />
      <SystemDebug />
    </>
  );
};
