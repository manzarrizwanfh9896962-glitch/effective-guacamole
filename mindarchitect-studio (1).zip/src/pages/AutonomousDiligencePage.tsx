import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Terminal, Search, Shield, Code, AlertTriangle, CheckCircle2, Loader2, Cpu, Layers, FileCode } from 'lucide-react';

export const AutonomousDiligencePage = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResults, setScanResults] = useState<any[]>([]);

  const startAudit = () => {
    setIsScanning(true);
    setScanProgress(0);
    setScanResults([]);

    const steps = [
      { label: 'INITIALIZING_HEURISTIC_CORE', duration: 1000 },
      { label: 'MAPPING_STRUCTURAL_DEPENDENCIES', duration: 1500 },
      { label: 'VERIFYING_LOGIC_FLOW_INTEGRITY', duration: 2000 },
      { label: 'SCANNING_FOR_RACE_CONDITIONS', duration: 1500 },
      { label: 'AUDITING_MEMORY_ALLOCATION', duration: 1200 },
      { label: 'DETECTING_SECURITY_LEAKS', duration: 1800 },
      { label: 'CALCULATING_COMPLEXITY_INDEX', duration: 1000 }
    ];

    let currentStep = 0;
    const totalDuration = steps.reduce((acc, s) => acc + s.duration, 0);
    let elapsed = 0;

    const runStep = () => {
      if (currentStep < steps.length) {
        const step = steps[currentStep];
        setScanResults(prev => [...prev, { id: Date.now(), type: 'SUCCESS', msg: `[${new Date().toLocaleTimeString()}] ${step.label}...` }]);
        
        setTimeout(() => {
          elapsed += step.duration;
          setScanProgress(Math.min(Math.round((elapsed / totalDuration) * 100), 100));
          currentStep++;
          runStep();
        }, step.duration);
      } else {
        setIsScanning(false);
        setScanResults(prev => [
          ...prev,
          { id: 'f1', type: 'SUCCESS', msg: 'STRUCTURAL_MAPPING_COMPLETE: 1,242 nodes identified.' },
          { id: 'f2', type: 'WARNING', msg: 'LOGIC_FLOW_INCONSISTENCY: Potential race condition in node_0x42.' },
          { id: 'f3', type: 'SUCCESS', msg: 'VERIFICATION_ENGINE: All critical paths secured.' },
          { id: 'f4', type: 'ERROR', msg: 'SECURITY_LEAK: Unencrypted credential found in legacy_module.ts' },
          { id: 'f5', type: 'WARNING', msg: 'COMPLEXITY_INDEX: High cyclomatic complexity in neural_uplink.rs' }
        ]);
      }
    };

    runStep();
  };

  return (
    <div className="min-h-screen bg-evalion-bg text-evalion-text p-6 pt-24 font-mono">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-end gap-8">
          <div className="space-y-4">
            <h3 className="text-evalion-teal font-mono text-[10px] tracking-[0.5em] uppercase opacity-60">
              [ HEURISTIC_CORE_AUDIT ]
            </h3>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tighter text-white uppercase">
              AUTONOMOUS_DILIGENCE
            </h2>
            <p className="max-w-xl text-evalion-textDim text-xs leading-relaxed tracking-wider">
              Automated Structural Mapping and Logic Flow Verification. Our engine parses codebases to detect architectural flaws and logic inconsistencies before they reach production.
            </p>
          </div>
          <button 
            onClick={startAudit}
            disabled={isScanning}
            className="px-10 py-4 bg-evalion-teal text-black font-bold text-xs tracking-[0.3em] rounded-xl hover:bg-evalion-teal/90 transition-all shadow-[0_0_30px_rgba(0,240,255,0.3)] disabled:opacity-50"
          >
            {isScanning ? 'AUDIT_IN_PROGRESS' : 'INITIALIZE_CORE_AUDIT'}
          </button>
        </div>

        {/* Main Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left: Visualization */}
          <div className="lg:col-span-7 glass-panel rounded-3xl p-8 border-white/5 relative overflow-hidden min-h-[500px]">
            <div className="absolute top-4 left-4 flex items-center gap-2 text-[10px] text-evalion-teal font-bold tracking-widest">
              <Cpu size={14} /> STRUCTURAL_MAP_V2
            </div>
            
            <div className="h-full flex items-center justify-center">
              {isScanning ? (
                <div className="relative w-64 h-64">
                  <motion.div 
                    className="absolute inset-0 border-2 border-evalion-teal/20 rounded-full"
                    animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.5, 0.2] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <motion.div 
                    className="absolute inset-4 border-2 border-evalion-purple/20 rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center space-y-2">
                    <span className="text-2xl font-bold text-white">{scanProgress}%</span>
                    <span className="text-[8px] text-evalion-teal tracking-[0.3em]">SCANNING...</span>
                  </div>
                </div>
              ) : scanResults.length > 0 ? (
                <div className="grid grid-cols-4 gap-4 w-full">
                  {Array.from({ length: 16 }).map((_, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.05 }}
                      className={`aspect-square rounded-lg border flex items-center justify-center ${
                        i % 5 === 0 ? 'border-evalion-danger/30 bg-evalion-danger/5' :
                        i % 3 === 0 ? 'border-evalion-purple/30 bg-evalion-purple/5' :
                        'border-evalion-teal/30 bg-evalion-teal/5'
                      }`}
                    >
                      <Layers size={20} className={i % 5 === 0 ? 'text-evalion-danger' : i % 3 === 0 ? 'text-evalion-purple' : 'text-evalion-teal'} />
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center space-y-4 opacity-20">
                  <Search size={64} className="mx-auto" />
                  <p className="text-xs tracking-[0.3em]">AWAITING_INITIALIZATION</p>
                </div>
              )}
            </div>

            {/* Scanline Overlay */}
            <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.05)_50%)] bg-[length:100%_4px] opacity-20"></div>
          </div>

          {/* Right: Results Terminal */}
          <div className="lg:col-span-5 space-y-6">
            <div className="glass-panel rounded-3xl p-6 border-white/5 h-full flex flex-col">
              <div className="flex items-center gap-3 mb-6">
                <Terminal size={18} className="text-evalion-teal" />
                <h3 className="text-sm font-bold tracking-widest text-white">AUDIT_RESULTS</h3>
              </div>
              
              <div className="flex-grow space-y-4 overflow-y-auto custom-scrollbar pr-2">
                {scanResults.length === 0 && !isScanning && (
                  <p className="text-[10px] text-evalion-textDim italic">No audit data available. Please initialize core audit.</p>
                )}
                {isScanning && (
                  <div className="space-y-2">
                    <p className="text-[10px] text-evalion-teal animate-pulse">Parsing structural nodes...</p>
                    <p className="text-[10px] text-evalion-textDim">Verifying logic flow paths...</p>
                    <p className="text-[10px] text-evalion-textDim">Checking security dependencies...</p>
                  </div>
                )}
                {scanResults.map((res) => (
                  <motion.div 
                    key={res.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className={`p-4 rounded-xl border flex gap-3 ${
                      res.type === 'SUCCESS' ? 'border-evalion-success/20 bg-evalion-success/5 text-evalion-success' :
                      res.type === 'WARNING' ? 'border-evalion-purple/20 bg-evalion-purple/5 text-evalion-purple' :
                      'border-evalion-danger/20 bg-evalion-danger/5 text-evalion-danger'
                    }`}
                  >
                    {res.type === 'SUCCESS' ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
                    <p className="text-[10px] font-mono leading-relaxed">{res.msg}</p>
                  </motion.div>
                ))}
              </div>

              {scanResults.length > 0 && (
                <div className="mt-6 pt-6 border-t border-white/5">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-evalion-textDim uppercase tracking-widest">DILIGENCE_SCORE</span>
                    <span className="text-evalion-teal font-bold">84/100</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom: Technical Specs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4">
            <div className="flex items-center gap-3 text-evalion-teal">
              <FileCode size={20} />
              <h4 className="text-xs font-bold tracking-widest uppercase">CODE_PARSING</h4>
            </div>
            <p className="text-[10px] text-evalion-textDim leading-relaxed">
              Multi-language support for C++, Rust, Go, and TypeScript. Deep AST analysis for structural integrity.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4">
            <div className="flex items-center gap-3 text-evalion-purple">
              <Shield size={20} />
              <h4 className="text-xs font-bold tracking-widest uppercase">LOGIC_VERIFICATION</h4>
            </div>
            <p className="text-[10px] text-evalion-textDim leading-relaxed">
              Formal verification engine to detect deadlocks, race conditions, and memory leaks in real-time.
            </p>
          </div>
          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5 space-y-4">
            <div className="flex items-center gap-3 text-evalion-danger">
              <AlertTriangle size={20} />
              <h4 className="text-xs font-bold tracking-widest uppercase">THREAT_DETECTION</h4>
            </div>
            <p className="text-[10px] text-evalion-textDim leading-relaxed">
              Heuristic analysis for common security vulnerabilities and unencrypted sensitive data.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
