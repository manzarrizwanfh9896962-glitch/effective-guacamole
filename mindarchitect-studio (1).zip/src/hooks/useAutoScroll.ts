import { useEffect, useRef, RefObject } from 'react';

/**
 * Custom hook to automatically scroll a container to the bottom when its content changes.
 * @param ref - The ref of the container to scroll.
 * @param dependency - The dependency that triggers the scroll (e.g., messages array).
 * @param enabled - Whether auto-scrolling is enabled.
 */
export function useAutoScroll(
  ref: RefObject<HTMLElement | null>,
  dependency: any,
  enabled: boolean = true
) {
  const isAtBottom = useRef(true);

  const handleScroll = () => {
    if (!ref.current) return;
    const { scrollTop, scrollHeight, clientHeight } = ref.current;
    // Check if user is near the bottom (within 50px)
    isAtBottom.current = scrollHeight - scrollTop - clientHeight < 50;
  };

  useEffect(() => {
    const container = ref.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, [ref]);

  useEffect(() => {
    if (enabled && isAtBottom.current && ref.current) {
      ref.current.scrollTo({
        top: ref.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [dependency, enabled, ref]);
}
