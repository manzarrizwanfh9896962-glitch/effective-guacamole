/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { SimulationModal } from './components/SimulationModal';
import { SyncingOverlay } from './components/SyncingOverlay';
import { Dashboard } from './components/Dashboard';
import { LoadingScreen } from './components/LoadingScreen';
import { OnboardingTutorial } from './components/OnboardingTutorial';
import { Chatbot } from './components/Chatbot';
import { HighContrastToggle } from './components/HighContrastToggle';
import { Toaster } from 'sonner';

// Individual Page Components for Routing
import { Architecture } from './components/Architecture';
import { PlatformCore } from './components/PlatformCore';
import { Workflows } from './components/Workflows';
import { Enterprise } from './components/Enterprise';
import { Deployment } from './components/Deployment';
import { ApiDocs } from './components/ApiDocs';
import { KernelStatus } from './components/KernelStatus';
import { Contact } from './components/Contact';
import { BackButton } from './components/BackButton';

import { InterviewPage } from './pages/InterviewPage';
import { AutonomousDiligencePage } from './pages/AutonomousDiligencePage';
import { NeuralProfilingPage } from './pages/NeuralProfilingPage';
import { LoginPage } from './pages/LoginPage';
import { PracticeInterviewPage } from './pages/PracticeInterviewPage';
import { TermsPage } from './pages/TermsPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { SecurityPage } from './pages/SecurityPage';
import { CandidateProfilePage } from './pages/CandidateProfilePage';
import { PassportManagement } from './pages/PassportManagement';

import { authService } from './services/authService';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { CollaborationProvider } from './context/CollaborationContext';

function AppContent() {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isSimOpen, setIsSimOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isTutorialOpen, setIsTutorialOpen] = useState(false);
  const { theme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();

  React.useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('hasSeenOnboardingTutorial');
    if (!hasSeenTutorial) {
      setIsTutorialOpen(true);
    }
    // Check for active session on load
    if (authService.isAuthenticated()) {
      setIsLoggedIn(true);
    }
    // Removed setIsLoading(false) from here to let LoadingScreen handle it
  }, []);

  const handleLogin = () => {
    setIsAuthOpen(false);
    setIsSyncing(true);
  };

  const handleBiometricLoginSuccess = () => {
    setIsLoggedIn(true);
    navigate('/dashboard');
  };

  const handleSyncComplete = () => {
    setIsSyncing(false);
    setIsLoggedIn(true);
  };

  const handleTutorialComplete = () => {
    localStorage.setItem('hasSeenOnboardingTutorial', 'true');
    setIsTutorialOpen(false);
  };

  const handleLogout = async () => {
    await authService.logout();
    setIsLoggedIn(false);
    navigate('/login');
  };

  return (
    <AnimatePresence mode="wait">
      {isLoading ? (
        <LoadingScreen key="loading" onFinished={() => setIsLoading(false)} />
      ) : (
        <motion.div 
          key="app-content"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className={`min-h-screen bg-evalion-bg text-evalion-text font-sans selection:bg-evalion-teal/30 selection:text-evalion-teal theme-${theme}`}
        >
          {location.pathname !== '/login' && (
            <Navbar 
              onAuthClick={() => setIsAuthOpen(true)} 
              isLoggedIn={isLoggedIn}
              onLogout={handleLogout}
            />
          )}
          
          <main>
              <AnimatePresence mode="wait">
                <Routes location={location} key={location.pathname}>
                  <Route 
                    path="/"
                    element={isLoggedIn ? <Navigate to="/dashboard" replace /> : <Home onDeploy={() => setIsAuthOpen(true)} onSimulate={() => navigate('/practice')} />}
                  />
                  <Route 
                    path="/practice" 
                    element={isLoggedIn ? <motion.div><BackButton /><PracticeInterviewPage /></motion.div> : <Navigate to="/login" replace />} 
                  />
                  <Route path="/login" element={isLoggedIn ? <Navigate to="/dashboard" /> : <LoginPage onLoginSuccess={handleBiometricLoginSuccess} />} />
                  
                  {/* Protected Route */}
                  <Route 
                    path="/dashboard"
                    element={isLoggedIn ? <Dashboard onLogout={handleLogout} onShowTutorial={() => setIsTutorialOpen(true)} /> : <Navigate to="/login" replace />}
                  />
                  <Route 
                    path="/candidates/:id" 
                    element={isLoggedIn ? <motion.div><BackButton /><CandidateProfilePage /></motion.div> : <Navigate to="/login" replace />} 
                  />
                  <Route 
                    path="/passport" 
                    element={isLoggedIn ? <motion.div><BackButton /><PassportManagement /></motion.div> : <Navigate to="/login" replace />} 
                  />

                  {/* Other existing routes */}
                  <Route path="/architecture" element={<motion.div><BackButton /><Architecture /></motion.div>} />
                  <Route path="/platform" element={<motion.div><BackButton /><PlatformCore /></motion.div>} />
                  <Route path="/workflows" element={<motion.div><BackButton /><Workflows /></motion.div>} />
                  <Route path="/enterprise" element={<motion.div><BackButton /><Enterprise /></motion.div>} />
                  <Route path="/deployment" element={<motion.div><BackButton /><Deployment /></motion.div>} />
                  <Route path="/api" element={<motion.div><BackButton /><ApiDocs /></motion.div>} />
                  <Route path="/status" element={<motion.div><BackButton /><KernelStatus /></motion.div>} />
                  <Route path="/contact" element={<motion.div><BackButton /><Contact /></motion.div>} />
                  <Route 
                    path="/interview" 
                    element={isLoggedIn ? <motion.div><BackButton /><InterviewPage /></motion.div> : <Navigate to="/login" replace />} 
                  />
                  <Route 
                    path="/diligence" 
                    element={isLoggedIn ? <motion.div><BackButton /><AutonomousDiligencePage /></motion.div> : <Navigate to="/login" replace />} 
                  />
                  <Route 
                    path="/profiling" 
                    element={isLoggedIn ? <motion.div><BackButton /><NeuralProfilingPage /></motion.div> : <Navigate to="/login" replace />} 
                  />
                  <Route path="/terms" element={<motion.div><BackButton /><TermsPage /></motion.div>} />
                  <Route path="/privacy" element={<motion.div><BackButton /><PrivacyPage /></motion.div>} />
                  <Route path="/security" element={<motion.div><BackButton /><SecurityPage /></motion.div>} />
                </Routes>
              </AnimatePresence>
            </main>

            {!isLoggedIn && location.pathname !== '/login' && <Footer />}

            <AuthModal 
              isOpen={isAuthOpen} 
              onClose={() => setIsAuthOpen(false)} 
              onLogin={handleLogin}
            />
            
            <SimulationModal 
              isOpen={isSimOpen} 
              onClose={() => setIsSimOpen(false)} 
            />

            <SyncingOverlay 
              isVisible={isSyncing} 
              onComplete={handleSyncComplete} 
            />

            <OnboardingTutorial
              isOpen={isTutorialOpen}
              onClose={() => setIsTutorialOpen(false)}
              onComplete={handleTutorialComplete}
            />

            {/* Global Chatbot Assistant */}
            <Chatbot />
            
            {/* Global High Contrast Toggle */}
            <HighContrastToggle />
            
            {/* Global Toast Notifications */}
            <Toaster 
              position="top-right" 
              toastOptions={{
                style: {
                  background: 'rgba(5, 5, 5, 0.8)',
                  backdropFilter: 'blur(16px)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  color: '#fff',
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: '10px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                },
              }}
            />
          </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <CollaborationProvider>
        <AppContent />
      </CollaborationProvider>
    </ThemeProvider>
  );
}
