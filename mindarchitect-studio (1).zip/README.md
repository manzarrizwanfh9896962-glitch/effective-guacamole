<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/drive/1Vs0jdjLBD2bdCxuTiAAzBGii7arZrQ_l

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`
# MindArchitect Studio - Neural Hiring Platform

## Overview
MindArchitect Studio is an AI-powered interview and hiring platform with a futuristic cyberpunk-themed UI. The platform offers real-time AI interviews, candidate tracking (ATS), and comprehensive hiring analytics.

## Architecture

### Frontend (React + TypeScript + Vite)
- **Framework**: React 19 with TypeScript
- **Styling**: Tailwind CSS with custom neon theme (teal, purple, danger colors)
- **Animations**: Framer Motion for all UI transitions
- **3D Graphics**: React Three Fiber for visual effects
- **Charts**: Recharts for analytics visualization

### Backend (Express + TypeScript)
- **Server**: Express.js with TypeScript (tsx runtime)
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OpenID Connect)
- **Session**: PostgreSQL-backed sessions with express-session

### AI Engine
- **Provider**: Google Gemini AI (gemini-2.0-flash)
- **Features**: Resume parsing, candidate ranking, interview question generation, final report synthesis
- **Resiliency**: Circuit breaker pattern with automatic retry

## Project Structure
```
/
├── server.ts               # Express server entry and API routes
├── src/
│   ├── App.tsx             # Main React app with routing
│   ├── main.tsx            # React entry point
│   ├── index.css           # Global styles & Tailwind
│   ├── components/         # React components
│   │   ├── AuthModal.tsx   # Authentication UI
│   │   ├── Dashboard.tsx   # Main dashboard
│   │   └── ...
│   └── pages/              # Page components
└── package.json            # Dependencies and scripts
```

## Database Schema
- **users**: User accounts (id, email, password, biometric credentials)
- **nodes**: System nodes for health monitoring

## Running the Project

### Development
```bash
# Start full-stack dev server (port 3000)
npm run dev
```

### Build & Production
```bash
npm run build      # Build frontend for production
npm run start      # Start production server
```

## Authentication
Uses JWT-based authentication with support for WebAuthn biometric login (Touch ID, Face ID, Windows Hello).

## Theme Colors
- `evalion-teal`: #00F0FF (primary accent)
- `evalion-purple`: #8B5CF6 (secondary accent)
- `evalion-danger`: #FF2A6D (alerts/errors)
- `evalion-success`: #05FF00 (success states)
- `evalion-bg`: #010409 (dark background)

## Key Features
1. **AI Interview Room**: Real-time AI-powered technical interviews
2. **Resume Analysis**: AI parsing and candidate ranking
3. **ATS Pipeline**: Kanban-style candidate tracking
4. **Proctoring Metrics**: Simulated monitoring during interviews
5. **Final Reports**: Comprehensive AI-generated evaluation reports

## Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Session encryption key
- `GEMINI_API_KEY`: Google AI API key (for AI features)