import fs from 'fs';

const swaggerSpec = {
  openapi: '3.0.0',
  info: {
    title: 'MindArchitect Studio API',
    version: '1.0.0',
    description: 'API for the MindArchitect Studio, an AI-powered recruitment platform.',
  },
  servers: [
    {
      url: 'http://localhost:3000',
      description: 'Development server',
    },
  ],
  paths: {
    '/api/health': {
      get: {
        summary: 'Get system health',
        responses: {
          '200': {
            description: 'System health status',
          },
        },
      },
    },
    '/api/auth/signup': {
      post: {
        summary: 'Register a new user',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  email: { type: 'string', format: 'email', description: 'User email address' },
                  password: { type: 'string', minLength: 8, description: 'User password (min 8 chars)' },
                },
                required: ['email', 'password']
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'User created successfully',
          },
          '400': {
            description: 'Invalid input data',
          },
          '409': {
            description: 'User already exists',
          },
          '500': {
            description: 'Internal server error',
          }
        },
      },
    },
    '/api/auth/login': {
      post: {
        summary: 'Login a user',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  email: { type: 'string' },
                  password: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          '200': {
            description: 'Login successful',
          },
          '401': {
            description: 'Invalid credentials',
          },
        },
      },
    },
    '/api/auth/biometric/register/start': {
      post: {
        summary: 'Start biometric registration',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  email: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          '200': {
            description: 'Registration options',
          },
        },
      },
    },
    '/api/nodes': {
        get: {
            summary: 'Get all nodes',
            responses: {
                '200': {
                    description: 'A list of nodes',
                },
            },
        },
    },
  },
};

fs.writeFileSync('./public/openapi.json', JSON.stringify(swaggerSpec, null, 2));
console.log('openapi.json generated successfully');
