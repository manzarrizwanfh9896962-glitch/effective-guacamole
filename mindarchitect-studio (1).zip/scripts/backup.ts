import postgres from 'postgres';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const { DATABASE_URL } = process.env;

if (!DATABASE_URL) {
  console.error('DATABASE_URL is not defined in .env file');
  process.exit(1);
}

const sql = postgres(DATABASE_URL);

async function backup() {
  try {
    console.log('Starting database backup...');

    const tables = ['users', 'nodes'];
    let backupSql = '';

    for (const table of tables) {
      const records = await sql`SELECT * FROM ${sql(table)}`;
      if (records.length > 0) {
        const columns = Object.keys(records[0]).join(', ');
        const values = records.map(row => `(${Object.values(row).map(val => `'${String(val).replace(/'/g, "''")}''`).join(', ')})`).join(',\n');
        backupSql += `INSERT INTO ${table} (${columns}) VALUES\n${values};\n\n`;
      }
    }

    const backupDir = './backups';
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir);
    }

    const fileName = `${backupDir}/backup-${new Date().toISOString().replace(/:/g, '-')}.sql`;
    fs.writeFileSync(fileName, backupSql);

    console.log(`Backup successful! File created at ${fileName}`);
  } catch (error) {
    console.error('Backup failed:', error);
  } finally {
    await sql.end();
  }
}

backup();
