# Product Ready Deployment Guide

## 1. Environment Configuration
Ensure all variables in `.env.example` are set in your production environment.
- `DATABASE_URL`: A persistent PostgreSQL instance.
- `JWT_SECRET`: A long, random string.
- `SESSION_SECRET`: A long, random string.
- `GEMINI_API_KEY`: Your Google AI API key.

## 2. Secure Context (HTTPS)
WebAuthn (Biometrics) **requires** a secure context.
- Ensure your app is served over HTTPS.
- If using a proxy (like Nginx), ensure `X-Forwarded-Proto: https` is set.

## 3. Database Initialization
The server automatically attempts to create the `users` and `nodes` tables on startup.
Ensure the database user has `CREATE` permissions.

## 4. Scaling
- The current session store is in-memory. For multi-node deployments, use a Redis or Postgres-backed session store.
- The `mockDb` fallback is intended for development only.

## 5. Security Checklist
- [ ] `NODE_ENV` set to `production`.
- [ ] `JWT_SECRET` and `SESSION_SECRET` are unique and rotated.
- [ ] Database is protected by SSL/TLS.
- [ ] API keys are not exposed in client-side code (prefixed with `VITE_` only if absolutely necessary).
